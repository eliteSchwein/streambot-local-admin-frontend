<template>
  <v-card class="overflow-auto mx-auto" max-height="100%" elevation="0" color="transparent" max-width="100%">
    <v-card-title class="d-flex align-center justify-space-between px-3 pt-3">
      <div class="d-flex align-center ga-2 min-width-0">
        <v-icon icon="mdi-lightning-bolt" />
        <div class="min-width-0">
          <div class="text-truncate">{{ $t('events.title') }}</div>
        </div>
      </div>

    </v-card-title>

    <v-card-text>
      <v-text-field
        v-model="searchQuery"
        :label="$t('events.search')"
        prepend-inner-icon="mdi-magnify"
        clearable
        variant="outlined"
        density="comfortable"
        hide-details
        class="mb-3"
      />

      <v-alert v-if="errorMessage" type="error" color="red-darken-3" class="mb-4" :text="errorMessage" />
      <v-alert v-if="totalEvents === 0" type="error" color="red-darken-3" :text="$t('events.none')" />

      <v-expansion-panels
        v-else
        v-model="expandedChannels"
        variant="accordion"
        multiple
        class="event-channel-list"
      >
        <v-expansion-panel
          v-for="channelGroup in filteredNestedEvents"
          :key="channelGroup.name"
          :value="channelGroup.name"
          bg-color="grey-darken-4"
        >
          <v-expansion-panel-title>
            <div class="d-flex align-center ga-2 min-width-0 w-100">
              <v-icon :icon="channelIcon(channelGroup.name)" />
              <span class="text-truncate">{{ channelLabel(channelGroup.name) }}</span>
              <v-chip size="x-small" variant="tonal">{{ channelGroup.count }}</v-chip>
            </div>
          </v-expansion-panel-title>

          <v-expansion-panel-text>
            <v-expansion-panels
              v-if="channelGroup.hasSubchannels"
              v-model="expandedSubchannels[channelGroup.name]"
              variant="accordion"
              multiple
              class="event-subchannel-list"
            >
              <v-expansion-panel
                v-for="subchannelGroup in channelGroup.subchannels"
                :key="`${channelGroup.name}_${subchannelGroup.name}`"
                :value="subchannelGroup.name"
                bg-color="grey-darken-3"
              >
                <v-expansion-panel-title>
                  <div class="d-flex align-center ga-2 min-width-0 w-100">
                    <v-icon icon="mdi-folder-outline" />
                    <span class="text-truncate text-capitalize">{{ subchannelGroup.name }}</span>
                    <v-chip size="x-small" variant="tonal">{{ subchannelGroup.events.length }}</v-chip>
                  </div>
                </v-expansion-panel-title>

                <v-expansion-panel-text>
                  <v-list class="event-entry-list" bg-color="transparent">
                    <EventEntry
                      v-for="(eventEntry, eventIndex) in subchannelGroup.events"
                      :key="eventEntry.configName"
                      :class="eventIndex % 2 === 0 ? 'event-entry-row--even' : 'event-entry-row--odd'"
                      :event-entry="eventEntry"
                      :disabled="workingAction !== null"
                      @edit="openEditDialog"
                    />
                  </v-list>
                </v-expansion-panel-text>
              </v-expansion-panel>
            </v-expansion-panels>

            <v-list v-else class="event-entry-list" bg-color="transparent">
              <EventEntry
                v-for="(eventEntry, eventIndex) in channelGroup.events"
                :key="eventEntry.configName"
                :class="eventIndex % 2 === 0 ? 'event-entry-row--even' : 'event-entry-row--odd'"
                :event-entry="eventEntry"
                :disabled="workingAction !== null"
                @edit="openEditDialog"
              />
            </v-list>
          </v-expansion-panel-text>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-card-text>

    <EventEditorDialog
      ref="editorDialog"
      v-model="editorDialog"
      :event-entry="selectedEvent"
      :loading="workingAction === 'save'"
      :error="editorError"
      @save="saveEvent"
    />
  </v-card>
</template>

<script lang="ts">
import { getWebsocketClient } from '@/plugins/websocketInstance'
import EventEntry from '@/components/EventEntry.vue'
import EventEditorDialog from '@/components/dialogs/EventEditorDialog.vue'
import { mapState } from "pinia";
import { useAppStore } from "@/stores/app";

type SimulationField = {
  name: string
  type: 'text' | 'number' | 'boolean' | 'textarea' | 'select'
  localeKey?: string
  default?: string | number | boolean
  required?: boolean
  min?: number
  max?: number
  step?: number
  options?: Array<{
    title: string
    value: string | number | boolean
  }>
}

type EventEntryData = {
  name: string
  channel: string
  subchannel?: string
  configName: string
  macro?: boolean
  asset?: boolean
  configured?: boolean
  bypass_interaction_queue?: boolean
  localeKey?: string
  channelLocaleKey?: string
  subchannelLocaleKey?: string
  simulationFields?: SimulationField[]
  raw?: any
}

type EventSubchannelGroup = {
  name: string
  events: EventEntryData[]
}

type EventChannelGroup = {
  name: string
  count: number
  events: EventEntryData[]
  subchannels: EventSubchannelGroup[]
  hasSubchannels: boolean
}

export default {
  name: 'Events',

  components: {
    EventEntry,
    EventEditorDialog,
  },

  data() {
    return {
      errorMessage: '',
      editorError: '',
      searchQuery: '',
      expandedChannels: [] as string[],
      expandedSubchannels: {} as Record<string, string[]>,
      selectedEvent: null as EventEntryData | null,
      editorDialog: false,
      workingAction: null as null | 'save',
    }
  },

  computed: {
    ...mapState(useAppStore, ['getEvents']),

    eventList(): EventEntryData[] {
      // The backend owns the event ordering. Keep it intact so channel/event
      // groups appear exactly in the order returned by the event index.
      return this.normalizeEvents(this.getEvents)
    },

    totalEvents(): number {
      return this.filteredEventList.length
    },

    filteredEventList(): EventEntryData[] {
      const query = String(this.searchQuery ?? '').trim().toLowerCase()
      if (!query) return this.eventList

      return this.eventList.filter((eventEntry) =>
        [
          eventEntry.name,
          eventEntry.channel,
          eventEntry.subchannel,
          eventEntry.configName,
          this.eventDisplayName(eventEntry),
        ]
          .filter(Boolean)
          .some((value) => String(value).toLowerCase().includes(query)),
      )
    },

    filteredNestedEvents(): EventChannelGroup[] {
      const channels = new Map<string, Map<string, EventEntryData[]>>()

      for (const eventEntry of this.filteredEventList) {
        const channel = String(eventEntry.channel || 'system')
        const subchannel = String(eventEntry.subchannel || '').trim()

        if (!channels.has(channel)) channels.set(channel, new Map())
        if (!channels.get(channel)!.has(subchannel)) channels.get(channel)!.set(subchannel, [])

        channels.get(channel)!.get(subchannel)!.push(eventEntry)
      }

      return [...channels.entries()].map(([name, subchannels]) => {
        const groups = [...subchannels.entries()].map(([subchannelName, events]) => ({
          name: subchannelName,
          events,
        }))

        const realSubchannels = groups
          .filter((group) => group.name && group.name !== name)

        const directEvents = groups
          .filter((group) => !group.name || group.name === name)
          .flatMap((group) => group.events)

        return {
          name,
          count: groups.reduce((count, group) => count + group.events.length, 0),
          events: directEvents,
          subchannels: realSubchannels,
          hasSubchannels: realSubchannels.length > 0,
        }
      })
    },
  },

  watch: {
    searchQuery() {
      this.$nextTick(() => this.syncSearchExpansion())
    },

    filteredNestedEvents() {
      if (!String(this.searchQuery ?? '').trim()) return
      this.$nextTick(() => this.syncSearchExpansion())
    },
  },


  methods: {
    syncSearchExpansion() {
      const searching = Boolean(String(this.searchQuery ?? '').trim())

      if (!searching) {
        this.expandedChannels = []
        this.expandedSubchannels = {}
        return
      }

      const visibleGroups = this.filteredNestedEvents

      if (visibleGroups.length > 3) {
        this.expandedChannels = []
        this.expandedSubchannels = {}
        return
      }

      const channels = visibleGroups.map(group => group.name)
      const subchannels: Record<string, string[]> = {}

      for (const group of visibleGroups) {
        if (!group.hasSubchannels) continue
        subchannels[group.name] = group.subchannels.map(subchannel => subchannel.name)
      }

      this.expandedChannels = channels
      this.expandedSubchannels = subchannels
    },

    async requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      const client = getWebsocketClient()

      if (!client) {
        return undefined
      }

      const response = await client.request(method, params, timeout)
      return response?.params ?? response
    },

    getWebsocketResultKey(method: string) {
      return `result_${String(method ?? '').replace(/[^a-zA-Z0-9_]/g, '_')}`
    },

    unwrapWebsocketResponse(response: any, method = ''): any {
      const resultKey = method ? this.getWebsocketResultKey(method) : ''
      const containers = [response, response?.data, response?.payload, response?.result].filter(Boolean)

      if (resultKey) {
        for (const container of containers) {
          if (container && typeof container === 'object' && Object.prototype.hasOwnProperty.call(container, resultKey)) {
            return container[resultKey]
          }
        }
      }

      for (const container of containers) {
        if (container && typeof container === 'object') {
          if (Object.prototype.hasOwnProperty.call(container, 'result')) return container.result
          if (Object.prototype.hasOwnProperty.call(container, 'data')) return container.data
          if (Object.prototype.hasOwnProperty.call(container, 'payload')) return container.payload
        }
      }

      return response
    },

    assertWebsocketResponse(data: any, fallbackMessage: string) {
      if (data?.error) {
        throw new Error(data.error)
      }

      if (data?.success === false) {
        throw new Error(data?.message ?? fallbackMessage)
      }

      return data
    },

    async requestEventEndpoint(method: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      const response = await this.requestWebsocket(method, params, timeout)
      const data = this.unwrapWebsocketResponse(response, method)
      return this.assertWebsocketResponse(data, `${method} failed`)
    },

    isTimeoutError(error: any) {
      const message = String(error?.message ?? error ?? '').toLowerCase()
      return message.includes('timeout') || message.includes('timed out') || message.includes('request timed out')
    },

    async requestEventMutation(method: string, params: Record<string, any> = {}, timeout = 30_000): Promise<any> {
      try {
        return await this.requestEventEndpoint(method, params, timeout)
      } catch (error: any) {
        if (this.isTimeoutError(error)) {
          console.warn(`${method} timed out, refreshing state because the mutation may still have completed`, error)
          return { status: 'timeout_ignored' }
        }

        throw error
      }
    },

    normalizeEvents(value: any): EventEntryData[] {
      if (Array.isArray(value)) {
        return value.map(this.normalizeEventEntry).filter(Boolean) as EventEntryData[]
      }

      if (value && typeof value === 'object') {
        return Object.entries(value).flatMap(([channel, entries]: [string, any]) => {
          const list = Array.isArray(entries) ? entries : []
          return list.map((entry: any) => this.normalizeEventEntry({ channel, ...entry })).filter(Boolean) as EventEntryData[]
        })
      }

      return []
    },

    normalizeEventEntry(raw: any): EventEntryData | null {
      const configName = String(raw?.configName ?? raw?.config_name ?? raw?.name ?? '').trim()
      if (!configName) return null

      const parsed = this.parseConfigName(configName)

      return {
        name: String(raw?.name ?? parsed.name),
        channel: String(raw?.channel ?? parsed.channel),
        subchannel: String(raw?.subchannel ?? raw?.subChannel ?? parsed.subchannel ?? ''),
        configName,
        macro: raw?.macro === true,
        asset: raw?.asset === true,
        configured: raw?.configured === true || raw?.macro === true || raw?.asset === true,
        bypass_interaction_queue: raw?.bypass_interaction_queue === true || raw?.bypassInteractionQueue === true,
        localeKey: typeof raw?.localeKey === 'string' ? raw.localeKey : undefined,
        channelLocaleKey: typeof raw?.channelLocaleKey === 'string' ? raw.channelLocaleKey : undefined,
        subchannelLocaleKey: typeof raw?.subchannelLocaleKey === 'string' ? raw.subchannelLocaleKey : undefined,
        simulationFields: Array.isArray(raw?.simulationFields) ? raw.simulationFields : [],
        raw,
      }
    },

    parseConfigName(configName: string) {
      const parts = String(configName ?? '').split('_').filter(Boolean)
      if (parts[0] === 'event') parts.shift()

      const channel = parts.shift() || 'system'
      return {
        channel,
        subchannel: '',
        name: parts.join('_') || channel,
      }
    },


    async openEditDialog(eventEntry: EventEntryData) {
      this.selectedEvent = eventEntry
      this.editorError = ''
      this.editorDialog = true
      await this.$nextTick()
      await (this.$refs.editorDialog as any)?.open?.()
    },

    async saveEvent(payload: any) {
      const name = String(payload?.name ?? '').trim()
      if (!name || this.workingAction) return

      this.workingAction = 'save'
      this.editorError = ''

      try {
        if (!payload.skipAsset) {
          await this.requestEventMutation('assets_edit', {
            path: `${name}.yaml`,
            name,
            asset: payload.asset ?? {},
          }, 30_000)
        }

        await this.requestEventMutation('macro_edit', {
          path: `${name}.yaml`,
          name,
          content: payload.macroContent ?? this.defaultMacroContent(name),
        }, 30_000)

        this.editorDialog = false
      } catch (error: any) {
        this.editorError = error?.message ?? 'saving event failed'
      } finally {
        this.workingAction = null
      }
    },

    defaultMacroContent(name: string) {
      return `name: ${name}\napis: []\ntasks: []\n`
    },


    eventDisplayName(eventEntry: EventEntryData) {
      const explicitLocaleKey = String(eventEntry?.localeKey ?? '').trim()
      if (explicitLocaleKey && (this as any).$te?.(explicitLocaleKey)) {
        return String((this as any).$t(explicitLocaleKey))
      }

      const configName = String(eventEntry?.configName ?? '').trim()
      const configLocaleKey = configName ? `events.items.${configName}` : ''
      if (configLocaleKey && (this as any).$te?.(configLocaleKey)) {
        return String((this as any).$t(configLocaleKey))
      }

      return String(eventEntry?.name ?? configName)
        .replace(/^event_/, '')
        .split('_')
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ')
    },

    channelLabel(channel: string) {
      const localeKey = `events.channels.${channel}`

      if ((this as any).$te?.(localeKey)) {
        return String((this as any).$t(localeKey))
      }

      return String(channel || '')
        .split('_')
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ')
    },

    channelIcon(channel: string) {
      if (channel === 'twitch') return 'mdi-twitch'
      if (channel === 'system') return 'mdi-power'
      if (channel === 'music') return 'mdi-music'
      if (channel === 'giveaway') return 'mdi-gift'
      if (channel === 'audio') return 'mdi-volume-high'
      if (channel === 'obs') return 'mdi-video-outline'
      if (channel === 'yolobox') return 'mdi-video-wireless-outline'
      if (channel === 'kofi') return 'mdi-coffee-outline'
      return 'mdi-lightning-bolt'
    },
  },
}
</script>

<style scoped lang="scss">
.min-width-0 {
  min-width: 0;
}

.w-100 {
  width: 100%;
}

.event-entry-list {
  padding: 4px 0;
}

.event-entry-list :deep(.event-entry-row--even) {
  background: rgba(var(--v-theme-surface), 0.18) !important;
}

.event-entry-list :deep(.event-entry-row--odd) {
  background: rgba(var(--v-theme-primary), 0.10) !important;
}

</style>
