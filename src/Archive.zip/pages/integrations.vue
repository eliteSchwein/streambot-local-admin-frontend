<template>
  <v-card class="overflow-auto mx-auto" max-height="100%" elevation="0" color="transparent" max-width="100%">
    <v-card-title class="d-flex align-center justify-space-between px-3 pt-3">
      <div class="d-flex align-center ga-2">
        <v-icon icon="mdi-connection" />
        <span>{{ $t('integrations.ui.title') }}</span>
      </div>
    </v-card-title>

    <v-card-text class="px-3 pb-3">
      <v-row density="comfortable" align="stretch">
        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center ga-2">
              <v-icon icon="mdi-twitch" />
              <span>Twitch</span>
            </v-card-title>

            <v-card-text class="pt-2">
              <v-row density="comfortable" class="integration-form">
                <v-col cols="12" md="6">
                  <v-card variant="tonal">
                    <v-card-title class="d-flex align-center justify-space-between text-subtitle-1">
                      <span>{{ $t('integrations.ui.twitch.controlAuth') }}</span>
                      <v-chip
                        size="x-small"
                        :color="twitchStatus.control ? 'success' : 'warning'"
                        variant="tonal"
                      >
                        {{ twitchStatus.control ? $t('integrations.ui.status.loggedIn') : $t('integrations.ui.status.missing') }}
                      </v-chip>
                    </v-card-title>

                    <v-card-text>
                      {{ $t('integrations.ui.twitch.controlDescription') }}
                    </v-card-text>

                    <v-card-actions>
                      <v-btn
                        color="primary"
                        variant="flat"
                        prepend-icon="mdi-login"
                        @click="openTwitchAuth('control')"
                        :disabled="reloadInProgress"
                      >
                        {{ $t('integrations.ui.twitch.authControl') }}
                      </v-btn>
                    </v-card-actions>
                  </v-card>
                </v-col>

                <v-col cols="12" md="6">
                  <v-card variant="tonal">
                    <v-card-title class="d-flex align-center justify-space-between text-subtitle-1">
                      <span>{{ $t('integrations.ui.twitch.messageAuth') }}</span>
                      <v-chip
                        size="x-small"
                        :color="twitchStatus.message ? 'success' : 'grey'"
                        variant="tonal"
                      >
                        {{ twitchStatus.message ? $t('integrations.ui.status.loggedIn') : $t('integrations.ui.status.optional') }}
                      </v-chip>
                    </v-card-title>

                    <v-card-text>
                      {{ $t('integrations.ui.twitch.messageDescription') }}
                    </v-card-text>

                    <v-card-actions>
                      <v-btn
                        color="secondary"
                        variant="flat"
                        prepend-icon="mdi-message-text-outline"
                        @click="openTwitchAuth('message')"
                        :disabled="reloadInProgress"
                      >
                        {{ $t('integrations.ui.twitch.authMessage') }}
                      </v-btn>
                    </v-card-actions>
                  </v-card>
                </v-col>
              </v-row>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-cloud-outline" />
                <span>{{ $t('integrations.ui.cloud.title') }}</span>
              </div>

              <v-chip
                size="x-small"
                :color="cloudStatus.connected ? 'success' : (cloudStatus.registered && cloudStatus.enabled ? 'warning' : 'grey')"
                variant="tonal"
              >
                {{ cloudStatus.connected
                  ? $t('integrations.ui.status.connected')
                  : (cloudStatus.registered
                    ? (cloudStatus.enabled ? $t('integrations.ui.status.offline') : $t('integrations.ui.status.disabled'))
                    : $t('integrations.ui.status.optional')) }}
              </v-chip>
            </v-card-title>

            <v-card-text class="pt-2">
              <div class="text-body-2 text-medium-emphasis mb-4">
                {{ $t('integrations.ui.cloud.description') }}
              </div>

              <v-alert
                v-if="cloudStatus.error"
                type="error"
                variant="tonal"
                density="compact"
                class="mb-4"
              >
                {{ cloudStatus.error }}
              </v-alert>

              <template v-if="cloudStatus.registered">
                <v-list bg-color="transparent" density="compact" class="pa-0 mb-3">
                  <v-list-item rounded class="bg-grey-darken-3">
                    <template #prepend>
                      <v-avatar color="primary" variant="tonal">
                        <v-icon icon="mdi-server-network" />
                      </v-avatar>
                    </template>
                    <v-list-item-title>
                      {{ cloudStatus.instanceName || $t('integrations.ui.cloud.registered') }}
                    </v-list-item-title>
                    <v-list-item-subtitle v-if="cloudStatus.instanceId">
                      {{ $t('integrations.ui.cloud.instanceId') }}: {{ cloudStatus.instanceId }}
                    </v-list-item-subtitle>
                    <v-list-item-subtitle
                      v-if="cloudStatus.enabled && (cloudStatus.connectionState !== 'connected' || (cloudStatus.connectionMessage && cloudStatus.connectionMessage !== 'connected'))"
                    >
                      <template v-if="cloudStatus.connectionState !== 'connected'">
                        {{ cloudStatus.connectionState }}
                      </template>
                      <template v-if="cloudStatus.connectionMessage && cloudStatus.connectionMessage !== 'connected' && cloudStatus.connectionMessage !== cloudStatus.connectionState">
                        <template v-if="cloudStatus.connectionState !== 'connected'"> · </template>{{ cloudStatus.connectionMessage }}
                      </template>
                    </v-list-item-subtitle>
                  </v-list-item>
                </v-list>

                <v-switch
                  :model-value="cloudStatus.enabled"
                  :label="$t('integrations.ui.cloud.enabled')"
                  color="primary"
                  density="compact"
                  hide-details
                  class="mb-3"
                  :loading="loading.cloudToggle"
                  :disabled="reloadInProgress || loading.cloudToggle || loading.cloudRemove"
                  @update:model-value="toggleCloud"
                />

                <div class="d-flex ga-2 flex-wrap">
                  <v-btn
                    v-if="cloudStatus.enabled && !cloudStatus.connected"
                    color="primary"
                    variant="tonal"
                    prepend-icon="mdi-refresh"
                    :loading="loading.cloudReconnect"
                    :disabled="reloadInProgress || loading.cloudToggle || loading.cloudRemove"
                    @click="reconnectCloud"
                  >
                    {{ $t('integrations.ui.cloud.reconnect') }}
                  </v-btn>

                  <v-btn
                    color="error"
                    variant="text"
                    prepend-icon="mdi-link-off"
                    :loading="loading.cloudRemove"
                    :disabled="reloadInProgress || loading.cloudToggle || loading.cloudReconnect"
                    @click="removeCloud"
                  >
                    {{ $t('integrations.ui.cloud.unlink') }}
                  </v-btn>
                </div>
              </template>

              <template v-else-if="cloudStatus.registering">
                <v-alert type="info" variant="tonal" density="compact" class="mb-4">
                  <div>{{ $t('integrations.ui.cloud.pendingDescription') }}</div>
                  <div v-if="cloudStatus.pairingId" class="text-caption mt-1">
                    {{ $t('integrations.ui.cloud.pairingId') }}: {{ cloudStatus.pairingId }}
                  </div>
                  <div v-if="cloudStatus.registrationStatus" class="text-caption mt-1">
                    {{ $t('integrations.ui.cloud.registrationStatus') }}: {{ cloudStatus.registrationStatus }}
                  </div>
                </v-alert>

                <v-text-field
                  :model-value="cloudRegistrationPin"
                  :label="$t('integrations.ui.cloud.verificationPin')"
                  :hint="$t('integrations.ui.cloud.verificationPinHint')"
                  persistent-hint
                  variant="outlined"
                  density="compact"
                  inputmode="numeric"
                  autocomplete="one-time-code"
                  maxlength="6"
                  class="mb-3"
                  :disabled="reloadInProgress || loading.cloudVerify"
                  @update:model-value="onCloudPinInput"
                  @keydown.enter="verifyCloudRegistration"
                />

                <div class="d-flex ga-2 flex-wrap">
                  <v-btn
                    color="primary"
                    variant="flat"
                    prepend-icon="mdi-shield-check"
                    :loading="loading.cloudVerify"
                    :disabled="reloadInProgress || loading.cloudVerify || cloudRegistrationPin.length !== 6"
                    @click="verifyCloudRegistration"
                  >
                    {{ $t('integrations.ui.cloud.verifyPin') }}
                  </v-btn>

                  <v-btn
                    color="secondary"
                    variant="text"
                    prepend-icon="mdi-refresh"
                    :loading="loading.cloudStatus"
                    :disabled="reloadInProgress || loading.cloudStatus"
                    @click="refreshCloudStatus"
                  >
                    {{ $t('integrations.ui.cloud.refreshStatus') }}
                  </v-btn>
                </div>
              </template>

              <template v-else>
                <v-alert type="info" variant="tonal" density="compact" class="mb-4">
                  {{ $t('integrations.ui.cloud.pairingDescription') }}
                </v-alert>

                <v-text-field
                  v-model="cloudInstanceName"
                  :label="$t('integrations.ui.cloud.instanceName')"
                  :placeholder="$t('integrations.ui.cloud.instanceNamePlaceholder')"
                  variant="outlined"
                  density="compact"
                  hide-details
                  class="mb-4"
                  :disabled="reloadInProgress || loading.cloudRegister"
                  @keydown.enter="registerCloud"
                />

                <v-btn
                  color="primary"
                  variant="flat"
                  prepend-icon="mdi-link-variant-plus"
                  :loading="loading.cloudRegister"
                  :disabled="reloadInProgress || loading.cloudRegister"
                  @click="registerCloud"
                >
                  {{ $t('integrations.ui.cloud.register') }}
                </v-btn>
              </template>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-steam" />
                <span>Steam</span>
              </div>

              <v-chip
                size="x-small"
                :color="steamHasApiKey ? 'success' : 'warning'"
                variant="tonal"
              >
                {{ steamHasApiKey ? $t('integrations.ui.status.configured') : $t('integrations.ui.status.missing') }}
              </v-chip>
            </v-card-title>

            <v-card-text class="pt-2">
              <div class="text-body-2 text-medium-emphasis mb-4">
                {{ $t('integrations.ui.steam.description') }}
              </div>

              <v-text-field
                v-model="steamApiKey"
                :label="$t('integrations.ui.steam.apiKey')"
                :placeholder="steamHasApiKey ? $t('integrations.ui.steam.apiKeyConfigured') : ''"
                type="password"
                autocomplete="new-password"
                variant="outlined"
                density="compact"
                hide-details
                :disabled="reloadInProgress || loading.steam"
                @keydown.enter="saveSteamApiKey"
              />

              <div class="d-flex ga-2 mt-4">
                <v-btn
                  color="primary"
                  variant="flat"
                  prepend-icon="mdi-content-save-outline"
                  :loading="loading.steam"
                  :disabled="reloadInProgress || loading.steam || !steamApiKey.trim()"
                  @click="saveSteamApiKey"
                >
                  {{ $t('common.save') }}
                </v-btn>

                <v-btn
                  v-if="steamHasApiKey"
                  color="error"
                  variant="text"
                  prepend-icon="mdi-delete-outline"
                  :disabled="reloadInProgress || loading.steam"
                  @click="clearSteamApiKey"
                >
                  {{ $t('integrations.ui.steam.clear') }}
                </v-btn>
              </div>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-led-strip-variant" />
                <span>WLED</span>
              </div>
            </v-card-title>

            <v-card-text class="pt-2">
              <v-row density="comfortable" class="integration-form">
                <v-col cols="12" sm="6" md="5">
                  <v-text-field
                    v-model="wledForm.name"
                    :label="$t('integrations.ui.fields.name')"
                    placeholder="desk"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="5">
                  <v-text-field
                    v-model="wledForm.ip"
                    :label="$t('integrations.ui.fields.ipHost')"
                    placeholder="192.168.178.50"
                    density="compact"
                    variant="outlined"
                    hide-details
                    @keydown.enter="addWled"
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="12" md="2">
                  <v-btn
                    block
                    class="integration-action-btn"
                    color="primary"
                    variant="flat"
                    prepend-icon="mdi-plus"
                    :loading="loading.wledAdd"
                    :disabled="reloadInProgress || (!canAddWled)"
                    @click="addWled"
                  >
                    {{ $t('common.add') }}
                  </v-btn>
                </v-col>
              </v-row>

              <v-divider class="my-4" />

              <v-alert
                v-if="!wledEntries.length"
                type="info"
                variant="tonal"
                density="compact"
              >
                {{ $t('integrations.ui.wled.noneConfigured') }}
              </v-alert>

              <v-list v-else bg-color="transparent" density="compact">
                <v-list-item
                  v-for="entry in wledEntries"
                  :key="entry.name"
                  rounded
                  class="mb-2 bg-grey-darken-3"
                >
                  <template #prepend>
                    <v-avatar color="primary" variant="tonal">
                      <v-icon icon="mdi-led-strip-variant" />
                    </v-avatar>
                  </template>

                  <v-list-item-title>
                    {{ entry.name }}
                  </v-list-item-title>

                  <v-list-item-subtitle>
                    {{ entry.ip }}
                  </v-list-item-subtitle>

                  <template #append>
                    <v-btn
                      icon="mdi-delete-outline"
                      color="error"
                      variant="text"
                      :loading="loading.wledRemove === entry.name"
                      @click="removeWled(entry.name)"
                      :disabled="reloadInProgress"
                    />
                  </template>
                </v-list-item>
              </v-list>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-video-box" />
                <span>Yolobox</span>
              </div>
            </v-card-title>

            <v-card-text class="pt-2">
              <v-card variant="tonal" class="integration-inner-card">
                <v-card-title class="d-flex align-center justify-space-between text-subtitle-1">
                  <span>{{ $t('integrations.ui.yolobox.autoDiscovery') }}</span>
                  <v-switch
                    :model-value="yoloboxStatus.enabled"
                    color="primary"
                    density="compact"
                    hide-details
                    :loading="loading.yoloboxToggle"
                    @update:model-value="toggleYolobox"
                    :disabled="reloadInProgress"
                  />
                </v-card-title>

                <v-card-text>
                  <div class="mb-2">
                    {{ $t('integrations.ui.yolobox.discoveryDescription') }}
                  </div>

                  <div class="d-flex ga-2 flex-wrap">
                    <v-chip
                      size="x-small"
                      :color="yoloboxStatus.enabled ? 'success' : 'grey'"
                      variant="tonal"
                    >
                      {{ yoloboxStatus.enabled ? $t('common.enabled') : $t('integrations.ui.status.disabled') }}
                    </v-chip>

                    <v-chip
                      size="x-small"
                      :color="yoloboxStatus.connected ? 'success' : 'grey'"
                      variant="tonal"
                    >
                      {{ yoloboxStatus.connected ? $t('integrations.ui.status.connected') : $t('integrations.ui.status.offline') }}
                    </v-chip>
                  </div>
                </v-card-text>
              </v-card>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-led-on" />
                <span>Neopixel</span>
              </div>
            </v-card-title>

            <v-card-text class="pt-2">
              <v-row density="comfortable" class="integration-form">
                <v-col cols="12" sm="6" md="3">
                  <v-text-field
                    v-model="neopixelForm.name"
                    :label="$t('integrations.ui.fields.name')"
                    placeholder="tablet_leds"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="2">
                  <v-text-field
                    v-model.number="neopixelForm.gpio"
                    :label="$t('integrations.ui.fields.gpio')"
                    type="number"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="2">
                  <v-text-field
                    v-model.number="neopixelForm.amount"
                    :label="$t('integrations.ui.fields.amount')"
                    type="number"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="3">
                  <v-text-field
                    v-model.number="neopixelForm.heartbeat_index"
                    :label="$t('integrations.ui.fields.heartbeatIndex')"
                    type="number"
                    density="compact"
                    variant="outlined"
                    hide-details
                    @keydown.enter="saveNeopixel"
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="12" md="2">
                  <v-btn
                    block
                    class="integration-action-btn"
                    color="primary"
                    variant="flat"
                    prepend-icon="mdi-content-save-outline"
                    :loading="loading.neopixelSave"
                    :disabled="reloadInProgress || (!canSaveNeopixel)"
                    @click="saveNeopixel"
                  >
                    {{ $t('common.save') }}
                  </v-btn>
                </v-col>
              </v-row>

              <v-divider class="my-4" />

              <v-alert
                v-if="!neopixelEntries.length"
                type="info"
                variant="tonal"
                density="compact"
              >
                {{ $t('integrations.ui.neopixel.noneConfigured') }}
              </v-alert>

              <v-list v-else bg-color="transparent" density="compact">
                <v-list-item
                  v-for="entry in neopixelEntries"
                  :key="entry.name"
                  rounded
                  class="mb-2 bg-grey-darken-3"
                >
                  <template #prepend>
                    <v-avatar color="primary" variant="tonal">
                      <v-icon icon="mdi-led-on" />
                    </v-avatar>
                  </template>

                  <v-list-item-title>
                    {{ entry.name }}
                  </v-list-item-title>

                  <v-list-item-subtitle>
                    {{ $t('integrations.ui.neopixel.summary', { gpio: entry.gpio, amount: entry.amount, heartbeat: entry.heartbeat_index ?? $t('integrations.ui.status.none') }) }}
                  </v-list-item-subtitle>

                  <template #append>
                    <div class="d-flex align-center ga-2">
                      <v-btn
                        icon="mdi-delete-outline"
                        color="error"
                        variant="text"
                        :loading="loading.neopixelRemove === entry.name"
                        @click="removeNeopixel(entry.name)"
                        :disabled="reloadInProgress"
                      />
                    </div>
                  </template>
                </v-list-item>
              </v-list>
            </v-card-text>
          </v-card>
        </v-col>

        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-video-box" />
                <span>OBS</span>
              </div>
            </v-card-title>

            <v-card-text class="pt-2">
              <v-row density="comfortable" class="integration-form">
                <v-col cols="12" sm="6" md="3">
                  <v-text-field
                    v-model="obsForm.name"
                    :label="$t('integrations.ui.fields.name')"
                    placeholder="default"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="3">
                  <v-text-field
                    v-model="obsForm.ip"
                    :label="$t('integrations.ui.fields.ipHost')"
                    placeholder="127.0.0.1"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="2">
                  <v-text-field
                    v-model.number="obsForm.port"
                    :label="$t('integrations.ui.fields.port')"
                    type="number"
                    density="compact"
                    variant="outlined"
                    hide-details
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="6" md="2">
                  <v-text-field
                    v-model="obsForm.password"
                    :label="$t('integrations.ui.fields.password')"
                    type="password"
                    density="compact"
                    variant="outlined"
                    hide-details
                    @keydown.enter="addObs"
                    :disabled="reloadInProgress"
                  />
                </v-col>

                <v-col cols="12" sm="12" md="2">
                  <v-btn
                    block
                    class="integration-action-btn"
                    color="primary"
                    variant="flat"
                    prepend-icon="mdi-plus"
                    :loading="loading.obsAdd"
                    :disabled="reloadInProgress || (!canAddObs)"
                    @click="addObs"
                  >
                    {{ $t('common.add') }}
                  </v-btn>
                </v-col>
              </v-row>

              <v-divider class="my-4" />

              <v-alert
                v-if="!obsEntries.length"
                type="info"
                variant="tonal"
                density="compact"
              >
                {{ $t('integrations.ui.obs.noneConfigured') }}
              </v-alert>

              <v-list v-else bg-color="transparent" density="compact">
                <v-list-item
                  v-for="entry in obsEntries"
                  :key="entry.name"
                  rounded
                  class="mb-2 bg-grey-darken-3"
                >
                  <template #prepend>
                    <v-avatar :color="entry.connected ? 'success' : 'grey'" variant="tonal">
                      <v-icon icon="mdi-monitor" />
                    </v-avatar>
                  </template>

                  <v-list-item-title>
                    {{ entry.name }}
                  </v-list-item-title>

                  <v-list-item-subtitle>
                    {{ entry.ip }}:{{ entry.port }}
                  </v-list-item-subtitle>

                  <template #append>
                    <div class="d-flex align-center ga-2">
                      <v-chip
                        size="x-small"
                        :color="entry.connected ? 'success' : 'grey'"
                        variant="tonal"
                      >
                        {{ entry.connected ? $t('integrations.ui.status.connected') : $t('integrations.ui.status.offline') }}
                      </v-chip>

                      <v-btn
                        icon="mdi-delete-outline"
                        color="error"
                        variant="text"
                        :loading="loading.obsRemove === entry.name"
                        @click="removeObs(entry.name)"
                        :disabled="reloadInProgress"
                      />
                    </div>
                  </template>
                </v-list-item>
              </v-list>
            </v-card-text>
          </v-card>
        </v-col>





        <v-col cols="12" lg="6">
          <v-card class="integration-card" color="grey-darken-4" elevation="0">
            <v-card-title class="d-flex align-center justify-space-between">
              <div class="d-flex align-center ga-2">
                <v-icon icon="mdi-robot-outline" />
                <span>{{ $t('integrations.ui.ollama.title') }}</span>
              </div>

              <v-switch
                :model-value="ollamaStatus.enabled"
                color="primary"
                density="compact"
                hide-details
                :loading="loading.ollamaToggle || ollamaStatus.installing"
                :disabled="reloadInProgress || ollamaStatus.installing || ollamaStatus.changing_model"
                @update:model-value="toggleOllama"
              />
            </v-card-title>

            <v-card-text class="pt-2">
              <div class="d-flex ga-2 flex-wrap mb-4">
                <v-chip
                  size="x-small"
                  :color="ollamaStatus.enabled ? 'success' : 'grey'"
                  variant="tonal"
                >
                  {{ ollamaStatus.enabled ? $t('common.enabled') : $t('integrations.ui.status.disabled') }}
                </v-chip>

                <v-chip
                  size="x-small"
                  :color="ollamaStatus.running ? 'success' : 'grey'"
                  variant="tonal"
                >
                  {{ ollamaStatus.running ? $t('integrations.ui.status.connected') : $t('integrations.ui.status.offline') }}
                </v-chip>

                <v-chip
                  size="x-small"
                  color="info"
                  variant="tonal"
                >
                  {{
                    ollamaStatus.external
                      ? (ollamaStatus.external_provider === 'openai'
                        ? $t('integrations.ui.ollama.providers.openai')
                        : $t('integrations.ui.ollama.providers.ollama'))
                      : $t('integrations.ui.ollama.providers.internal')
                  }}
                </v-chip>
              </div>

              <v-alert
                v-if="ollamaStatus.error"
                type="error"
                variant="tonal"
                density="compact"
                class="mb-4"
              >
                {{ ollamaStatus.error }}
              </v-alert>

              <v-alert
                type="info"
                variant="tonal"
                density="compact"
                icon="mdi-robot-happy-outline"
                class="mb-4"
              >
                <div class="font-weight-medium mb-1">
                  {{ $t('integrations.ui.ollama.descriptionTitle') }}
                </div>
                <div>
                  {{ $t('integrations.ui.ollama.description') }}
                </div>
              </v-alert>

              <div class="text-caption text-medium-emphasis mb-2">
                {{ $t('integrations.ui.ollama.mode') }}
              </div>

              <v-btn-toggle
                :model-value="ollamaExternalEnabled ? 'external' : 'internal'"
                mandatory
                color="primary"
                variant="outlined"
                divided
                class="mb-4"
                :disabled="reloadInProgress || loading.ollamaExternal"
                @update:model-value="setAiMode"
              >
                <v-btn value="internal" prepend-icon="mdi-chip">
                  {{ $t('integrations.ui.ollama.modes.internal') }}
                </v-btn>
                <v-btn value="external" prepend-icon="mdi-server-network">
                  {{ $t('integrations.ui.ollama.modes.external') }}
                </v-btn>
              </v-btn-toggle>

              <template v-if="!ollamaExternalEnabled">
                <v-alert
                  v-if="ollamaStatus.installing"
                  type="info"
                  variant="tonal"
                  density="compact"
                  class="mb-4"
                >
                  {{ $t('integrations.ui.ollama.installing') }}
                </v-alert>

                <v-alert
                  v-if="ollamaStatus.changing_model"
                  type="info"
                  variant="tonal"
                  density="compact"
                  class="mb-4"
                >
                  {{ $t('integrations.ui.ollama.changingModel') }}
                </v-alert>

                <div class="text-body-2 text-medium-emphasis mb-4">
                  {{ $t('integrations.ui.ollama.internalDescription') }}
                </div>

                <v-row density="comfortable" class="integration-form">
                  <v-col cols="12" md="8">
                    <v-combobox
                      :model-value="ollamaSelectedModel"
                      :items="ollamaStatus.models"
                      :label="$t('integrations.ui.ollama.model')"
                      :hint="$t('integrations.ui.ollama.modelHint')"
                      persistent-hint
                      density="compact"
                      variant="outlined"
                      clearable
                      :disabled="
                        reloadInProgress
                        || !ollamaStatus.enabled
                        || ollamaStatus.installing
                        || ollamaStatus.changing_model
                      "
                      @update:model-value="setOllamaSelectedModel"
                    />
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-btn
                      block
                      class="integration-action-btn"
                      color="primary"
                      variant="flat"
                      prepend-icon="mdi-download"
                      :loading="loading.ollamaModel || ollamaStatus.changing_model"
                      :disabled="
                        reloadInProgress
                        || !ollamaStatus.enabled
                        || ollamaStatus.installing
                        || ollamaStatus.changing_model
                        || !ollamaSelectedModel
                        || ollamaSelectedModel === ollamaStatus.model
                      "
                      @click="changeOllamaModel"
                    >
                      {{ $t('integrations.ui.ollama.changeModel') }}
                    </v-btn>
                  </v-col>
                </v-row>

                <v-divider class="my-4" />

                <div class="d-flex align-center justify-space-between ga-3 flex-wrap">
                  <div>
                    <div class="text-body-2">
                      {{ $t('integrations.ui.ollama.currentModel') }}
                    </div>
                    <div class="text-medium-emphasis text-caption">
                      {{ ollamaStatus.model || $t('integrations.ui.status.none') }}
                    </div>
                  </div>

                  <v-btn
                    color="secondary"
                    variant="tonal"
                    prepend-icon="mdi-restart"
                    :loading="loading.ollamaRestart"
                    :disabled="
                      reloadInProgress
                      || !ollamaStatus.enabled
                      || !ollamaStatus.installed
                      || ollamaStatus.installing
                      || ollamaStatus.changing_model
                    "
                    @click="restartOllama"
                  >
                    {{ $t('integrations.ui.ollama.restart') }}
                  </v-btn>
                </div>
              </template>

              <template v-else>
                <div class="text-body-2 text-medium-emphasis mb-4">
                  {{ $t('integrations.ui.ollama.external.description') }}
                </div>

                <div class="text-caption text-medium-emphasis mb-2">
                  {{ $t('integrations.ui.ollama.external.provider') }}
                </div>

                <v-btn-toggle
                  :model-value="ollamaExternalProvider"
                  mandatory
                  color="primary"
                  variant="outlined"
                  divided
                  class="mb-4"
                  :disabled="reloadInProgress || loading.ollamaExternal"
                  @update:model-value="setOllamaExternalProvider"
                >
                  <v-btn value="ollama">
                    {{ $t('integrations.ui.ollama.providers.ollama') }}
                  </v-btn>
                  <v-btn value="openai">
                    {{ $t('integrations.ui.ollama.providers.openai') }}
                  </v-btn>
                </v-btn-toggle>

                <v-alert
                  v-if="ollamaExternalProvider === 'openai'"
                  type="info"
                  variant="tonal"
                  density="compact"
                  class="mb-4"
                >
                  {{ $t('integrations.ui.ollama.external.openaiHint') }}
                </v-alert>

                <v-text-field
                  :model-value="ollamaExternalUrl"
                  :label="$t('integrations.ui.ollama.external.url')"
                  :placeholder="
                    ollamaExternalProvider === 'openai'
                      ? $t('integrations.ui.ollama.external.openaiUrlPlaceholder')
                      : $t('integrations.ui.ollama.external.ollamaUrlPlaceholder')
                  "
                  density="compact"
                  variant="outlined"
                  hide-details
                  :disabled="reloadInProgress || loading.ollamaExternal"
                  @update:model-value="setOllamaExternalUrl"
                />

                <v-text-field
                  v-model="ollamaExternalApiKey"
                  class="mt-4"
                  :label="$t('integrations.ui.ollama.external.apiKey')"
                  :placeholder="ollamaExternalHasApiKey ? $t('integrations.ui.ollama.external.apiKeyConfigured') : ''"
                  type="password"
                  density="compact"
                  variant="outlined"
                  hide-details
                  autocomplete="new-password"
                  :disabled="reloadInProgress || loading.ollamaExternal"
                />

                <div
                  v-if="ollamaExternalHasApiKey"
                  class="d-flex align-center ga-2 mt-2"
                >
                  <v-chip size="x-small" color="success" variant="tonal">
                    {{ $t('integrations.ui.ollama.external.apiKeySaved') }}
                  </v-chip>
                  <v-btn
                    size="small"
                    color="error"
                    variant="text"
                    :disabled="reloadInProgress || loading.ollamaExternal"
                    @click="clearOllamaExternalApiKey"
                  >
                    {{ $t('integrations.ui.ollama.external.clearApiKey') }}
                  </v-btn>
                </div>

                <v-btn
                  block
                  class="mt-4"
                  color="primary"
                  variant="flat"
                  prepend-icon="mdi-content-save-outline"
                  :loading="loading.ollamaExternal"
                  :disabled="
                    reloadInProgress
                    || loading.ollamaExternal
                    || !ollamaExternalUrl.trim()
                  "
                  @click="saveOllamaExternal"
                >
                  {{ $t('integrations.ui.ollama.external.connect') }}
                </v-btn>

                <v-divider class="my-4" />

                <v-row density="comfortable" class="integration-form">
                  <v-col cols="12" md="8">
                    <v-combobox
                      :model-value="ollamaSelectedModel"
                      :items="ollamaStatus.models"
                      :label="$t('integrations.ui.ollama.model')"
                      :hint="$t('integrations.ui.ollama.external.modelHint')"
                      persistent-hint
                      density="compact"
                      variant="outlined"
                      clearable
                      :disabled="
                        reloadInProgress
                        || !ollamaStatus.enabled
                        || loading.ollamaExternal
                        || ollamaStatus.changing_model
                      "
                      @update:model-value="setOllamaSelectedModel"
                    />
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-btn
                      block
                      class="integration-action-btn"
                      color="primary"
                      variant="flat"
                      prepend-icon="mdi-check"
                      :loading="loading.ollamaModel"
                      :disabled="
                        reloadInProgress
                        || !ollamaStatus.enabled
                        || !ollamaSelectedModel
                        || ollamaSelectedModel === ollamaStatus.model
                      "
                      @click="changeOllamaModel"
                    >
                      {{ $t('integrations.ui.ollama.external.useModel') }}
                    </v-btn>
                  </v-col>
                </v-row>

                <div class="mt-2">
                  <div class="text-body-2">
                    {{ $t('integrations.ui.ollama.currentModel') }}
                  </div>
                  <div class="text-medium-emphasis text-caption">
                    {{ ollamaStatus.model || $t('integrations.ui.status.none') }}
                  </div>
                </div>
              </template>
            </v-card-text>
          </v-card>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script lang="ts">
import { useAppStore } from '@/stores/app'
import { getWebsocketClient } from '@/plugins/websocketInstance'

type TwitchAuthType = 'control' | 'message'

type ObsEntry = {
  name: string
  ip: string
  port: number
  connected: boolean
}

type NeopixelEntry = {
  name: string
  gpio: number
  amount: number
  heartbeat_index?: number
}

export default {
  name: 'IntegrationsPage',

  data() {
    return {
      appStore: useAppStore(),

      wledForm: {
        name: '',
        ip: '',
      },

      obsForm: {
        name: 'default',
        ip: '127.0.0.1',
        port: 4455,
        password: '',
      },

      neopixelForm: {
        name: 'tablet_leds',
        gpio: 17,
        amount: 2,
        heartbeat_index: 1 as number | null,
      },

      ollamaModel: '',
      ollamaExternalEnabledOverride: null as boolean | null,
      ollamaExternalProviderOverride: null as 'ollama' | 'openai' | null,
      ollamaExternalUrlOverride: null as string | null,
      ollamaExternalApiKey: '',
      steamApiKey: '',
      cloudInstanceName: '',
      cloudRuntimeState: null as any,
      cloudRegistrationPin: '',
      cloudStatusPollTimer: null as ReturnType<typeof setInterval> | null,

      loading: {
        wledAdd: false,
        wledRemove: '',
        obsAdd: false,
        obsRemove: '',
        yoloboxToggle: false,
        ollamaToggle: false,
        ollamaModel: false,
        ollamaRestart: false,
        ollamaExternal: false,
        neopixelSave: false,
        neopixelRemove: '',
        steam: false,
        cloudRegister: false,
        cloudVerify: false,
        cloudToggle: false,
        cloudRemove: false,
        cloudReconnect: false,
        cloudStatus: false,
      },

    }
  },

  computed: {
    integrations(): any {
      return this.appStore.getIntegrations ?? {}
    },

    reloadInProgress(): boolean {
      return this.appStore.getReloadUpdate?.finished !== true
    },


    wledIntegrations(): Record<string, any> {
      return this.integrations?.wled ?? {}
    },

    obsIntegrations(): Record<string, any> {
      return this.integrations?.obs ?? {}
    },

    neopixelIntegrations(): Record<string, any> {
      return this.integrations?.neopixel ?? {}
    },

    wledEntries(): any[] {
      return Object.entries(this.wledIntegrations)
        .map(([name, data]: any) => ({
          name,
          ip: data?.ip ?? '',
        }))
        .sort((a, b) => a.name.localeCompare(b.name))
    },

    obsEntries(): ObsEntry[] {
      return Object.entries(this.obsIntegrations)
        .map(([name, data]: any) => ({
          name,
          ip: data?.ip ?? '',
          port: Number(data?.port ?? 4455),
          connected: Boolean(data?.connected),
        }))
        .sort((a, b) => a.name.localeCompare(b.name))
    },

    neopixelEntries(): NeopixelEntry[] {
      return Object.entries(this.neopixelIntegrations)
        .map(([name, data]: any) => ({
          name,
          gpio: Number(data?.gpio ?? 0),
          amount: Number(data?.amount ?? 0),
          heartbeat_index: data?.heartbeat_index === undefined || data?.heartbeat_index === null
            ? undefined
            : Number(data.heartbeat_index),
        }))
        .sort((a, b) => a.name.localeCompare(b.name))
    },

    yoloboxStatus(): { enabled: boolean; connected: boolean } {
      return {
        enabled: Boolean(this.integrations?.yolobox?.enabled),
        connected: Boolean(this.integrations?.yolobox?.connected),
      }
    },

    ollamaStatus(): {
      enabled: boolean
      installed: boolean
      running: boolean
      installing: boolean
      changing_model: boolean
      model: string
      models: string[]
      external: boolean
      external_provider: 'ollama' | 'openai'
      external_url: string
      has_api_key: boolean
      external_ollama: { url: string; model: string; has_api_key: boolean }
      external_openai: { url: string; model: string; has_api_key: boolean }
      error: string
    } {
      const ollama = this.integrations?.ollama ?? {}

      return {
        enabled: Boolean(ollama.enabled),
        installed: Boolean(ollama.installed),
        running: Boolean(ollama.running),
        installing: Boolean(ollama.installing),
        changing_model: Boolean(ollama.changing_model),
        model: String(ollama.model ?? ''),
        models: Array.isArray(ollama.models) ? ollama.models.map(String) : [],
        external: Boolean(ollama.external),
        external_provider: ollama.external_provider === 'openai' ? 'openai' : 'ollama',
        external_url: String(ollama.external_url ?? ''),
        has_api_key: Boolean(ollama.has_api_key),
        external_ollama: {
          url: String(ollama.external_ollama?.url ?? ''),
          model: String(ollama.external_ollama?.model ?? ''),
          has_api_key: Boolean(ollama.external_ollama?.has_api_key),
        },
        external_openai: {
          url: String(ollama.external_openai?.url ?? ''),
          model: String(ollama.external_openai?.model ?? ''),
          has_api_key: Boolean(ollama.external_openai?.has_api_key),
        },
        error: String(ollama.error ?? ''),
      }
    },

    ollamaExternalEnabled(): boolean {
      return this.ollamaExternalEnabledOverride ?? this.ollamaStatus.external
    },

    ollamaExternalProvider(): 'ollama' | 'openai' {
      return this.ollamaExternalProviderOverride ?? this.ollamaStatus.external_provider
    },

    ollamaExternalProviderConfig(): any {
      return this.ollamaExternalProvider === 'openai'
        ? this.ollamaStatus.external_openai
        : this.ollamaStatus.external_ollama
    },

    ollamaExternalUrl(): string {
      return this.ollamaExternalUrlOverride
        ?? String(this.ollamaExternalProviderConfig?.url ?? '')
    },

    ollamaExternalHasApiKey(): boolean {
      return Boolean(this.ollamaExternalProviderConfig?.has_api_key)
    },

    ollamaSelectedModel(): string {
      return this.ollamaModel || this.ollamaStatus.model
    },

    canAddWled(): boolean {
      return Boolean(this.wledForm.name.trim() && this.wledForm.ip.trim())
    },

    canAddObs(): boolean {
      return Boolean(
        this.obsForm.name.trim()
        && this.obsForm.ip.trim()
        && Number(this.obsForm.port) > 0,
      )
    },

    canSaveNeopixel(): boolean {
      return Boolean(
        this.neopixelForm.name.trim()
        && Number.isInteger(Number(this.neopixelForm.gpio))
        && Number(this.neopixelForm.gpio) >= 0
        && Number.isInteger(Number(this.neopixelForm.amount))
        && Number(this.neopixelForm.amount) > 0,
      )
    },

    cloudStatus(): {
      enabled: boolean
      registered: boolean
      connected: boolean
      registering: boolean
      instanceId: string
      instanceName: string
      pairingId: string
      pinRequired: boolean
      registrationStatus: string
      expiresAt: number | null
      connectionState: string
      connectionMessage: string
      error: string
    } {
      const cloud = this.integrations?.cloud ?? {}
      const runtime = this.cloudRuntimeState ?? {}
      // cloud_status.connection is the backend-managed Cloud websocket state.
      // appStore.getConnections is the list of Commander websocket clients and must
      // not be used to determine whether the Cloud integration itself is online.
      const connection = runtime.connection ?? {}
      const instanceId = String(runtime.instance_id ?? cloud.instance_id ?? '')

      return {
        enabled: Boolean(runtime.enabled ?? cloud.enabled ?? connection.enabled),
        registered: Boolean(runtime.registered ?? cloud.registered ?? instanceId),
        connected: Boolean(connection.connected ?? runtime.connected ?? false),
        registering: Boolean(runtime.pending_registration ?? runtime.registering ?? false),
        instanceId,
        instanceName: String(runtime.name ?? cloud.name ?? ''),
        pairingId: String(runtime.pairing_id ?? ''),
        pinRequired: Boolean(runtime.pin_required ?? runtime.pending_registration ?? false),
        registrationStatus: String(runtime.registration_status ?? runtime.status ?? ''),
        expiresAt: runtime.expires_at == null ? null : Number(runtime.expires_at),
        connectionState: String(connection.state ?? (connection.connected ? 'connected' : 'disconnected')),
        connectionMessage: String(connection.message ?? ''),
        error: String(runtime.error ?? connection.error ?? ''),
      }
    },

    steamHasApiKey(): boolean {
      return Boolean(this.integrations?.steam?.has_api_key)
    },

    twitchStatus(): { control: boolean; message: boolean } {
      return {
        control: Boolean(this.integrations?.twitch?.control),
        message: Boolean(this.integrations?.twitch?.message),
      }
    },
  },

  mounted() {
    void this.refreshCloudStatus()
    this.cloudStatusPollTimer = setInterval(() => {
      void this.refreshCloudStatus(true)
    }, 2500)
  },

  beforeUnmount() {
    if (this.cloudStatusPollTimer) {
      clearInterval(this.cloudStatusPollTimer)
      this.cloudStatusPollTimer = null
    }
  },

  methods: {
    async sendWebsocket(method: string, params: any = {}) {
      const websocketClient = getWebsocketClient()

      if (!websocketClient) {
        this.showError(String(this.$t('integrations.ui.errors.websocketDisconnected')))
        return false
      }

      try {
        const response = await websocketClient.request(method, params)

        if (response?.error) {
          this.showError(response.error?.message ?? response.error ?? String(this.$t('integrations.ui.errors.requestFailed')))
          return false
        }

        return true
      } catch (error) {
        this.showError(error instanceof Error ? error.message : String(error))
        return false
      }
    },

    unwrapCloudResponse(response: any, method: string): any {
      const resultKey = `result_${String(method ?? '').replace(/[^a-zA-Z0-9_]/g, '_')}`
      const queue: any[] = [response]
      const seen = new Set<any>()

      while (queue.length > 0) {
        const current = queue.shift()
        if (!current || typeof current !== 'object' || seen.has(current)) continue
        seen.add(current)

        if (Object.prototype.hasOwnProperty.call(current, resultKey)) {
          return current[resultKey]
        }

        for (const key of ['params', 'result', 'data', 'payload']) {
          const value = current[key]
          if (value && typeof value === 'object') queue.push(value)
        }
      }

      // Fallback for non-standard / older responses. Prefer params because the
      // Streambot websocket API normally wraps method results there.
      return response?.params ?? response?.result ?? response?.data ?? response?.payload ?? response ?? {}
    },

    async requestCloud(method: string, params: any = {}) {
      const websocketClient = getWebsocketClient()

      if (!websocketClient) {
        this.showError(String(this.$t('integrations.ui.errors.websocketDisconnected')))
        return null
      }

      try {
        const response = await websocketClient.request(method, params)
        const payload = this.unwrapCloudResponse(response, method)

        if (payload?.error) {
          this.showError(String(payload.error?.message ?? payload.error))
          return null
        }

        return payload
      } catch (error: any) {
        const raw = error?.params ?? error?.result ?? error?.data ?? error
        const message = raw?.error?.message ?? raw?.error ?? error?.message ?? String(error)
        this.showError(String(message))
        return null
      }
    },

    async refreshCloudStatus(silent = false) {
      if (!silent) this.loading.cloudStatus = true
      try {
        const state = await this.requestCloud('cloud_status')
        if (state) {
          this.cloudRuntimeState = state
          if (!Boolean(state.pending_registration ?? state.pin_required ?? state.registering)) {
            this.cloudRegistrationPin = ''
          }
        }
      } finally {
        if (!silent) this.loading.cloudStatus = false
      }
    },

    async registerCloud() {
      this.loading.cloudRegister = true
      try {
        const state = await this.requestCloud('cloud_registration_start', {
          name: this.cloudInstanceName.trim(),
        })
        if (!state) return

        this.cloudRegistrationPin = ''
        this.cloudRuntimeState = {
          ...(this.cloudRuntimeState ?? {}),
          pending_registration: true,
          pin_required: Boolean(state.pin_required ?? true),
          pairing_id: state.pairing_id ?? '',
          registration_status: state.status ?? 'pin_required',
          expires_at: state.expires_at ?? null,
        }
      } finally {
        this.loading.cloudRegister = false
      }
    },

    onCloudPinInput(value: any) {
      this.cloudRegistrationPin = String(value ?? '').replace(/\D/g, '').slice(0, 6)
    },

    async verifyCloudRegistration() {
      const pin = this.cloudRegistrationPin.trim()
      if (!/^\d{6}$/.test(pin)) return

      this.loading.cloudVerify = true
      try {
        const state = await this.requestCloud('cloud_registration_verify', { pin })
        if (!state) return

        if (state.status === 'connected' || state.pin_required === false) {
          this.cloudRegistrationPin = ''
          await this.refreshCloudStatus()
          return
        }

        this.cloudRuntimeState = {
          ...(this.cloudRuntimeState ?? {}),
          ...state,
        }
      } finally {
        this.loading.cloudVerify = false
      }
    },

    async toggleCloud(enabled: boolean | null) {
      this.loading.cloudToggle = true
      try {
        const state = await this.requestCloud('cloud_toggle', { enabled: Boolean(enabled) })
        if (state) this.cloudRuntimeState = state
      } finally {
        this.loading.cloudToggle = false
      }
    },

    async reconnectCloud() {
      this.loading.cloudReconnect = true
      try {
        const state = await this.requestCloud('cloud_reconnect')
        if (state) this.cloudRuntimeState = state
      } finally {
        this.loading.cloudReconnect = false
      }
    },

    async removeCloud() {
      this.loading.cloudRemove = true
      try {
        const state = await this.requestCloud('cloud_remove')
        if (state) this.cloudRuntimeState = state
        this.cloudInstanceName = ''
        this.cloudRegistrationPin = ''
      } finally {
        this.loading.cloudRemove = false
      }
    },

    async saveSteamApiKey() {
      const apiKey = this.steamApiKey.trim()
      if (!apiKey) return

      this.loading.steam = true
      try {
        const sent = await this.sendWebsocket('integrations_steam_api_key', {
          api_key: apiKey,
        })
        if (sent) this.steamApiKey = ''
      } finally {
        this.loading.steam = false
      }
    },

    async clearSteamApiKey() {
      this.loading.steam = true
      try {
        const sent = await this.sendWebsocket('integrations_steam_api_key', {
          api_key: '',
        })
        if (sent) this.steamApiKey = ''
      } finally {
        this.loading.steam = false
      }
    },

    async addWled() {
      const name = this.wledForm.name.trim()
      const ip = this.wledForm.ip.trim()

      if (!name || !ip) {
        this.showError(String(this.$t('integrations.ui.errors.nameIpRequired')))
        return
      }

      this.loading.wledAdd = true

      const sent = await this.sendWebsocket('wled_add', {
        name,
        ip,
      })

      this.loading.wledAdd = false

      if (!sent) return

      this.wledForm.name = ''
      this.wledForm.ip = ''

    },

    async removeWled(name: string) {
      if (!name) return

      this.loading.wledRemove = name

      const sent = await this.sendWebsocket('wled_remove', {
        name,
      })

      this.loading.wledRemove = ''

      if (!sent) return

    },

    async addObs() {
      const name = this.obsForm.name.trim()
      const ip = this.obsForm.ip.trim()
      const port = Number(this.obsForm.port)
      const password = this.obsForm.password.trim()

      if (!name || !ip || !port) {
        this.showError(String(this.$t('integrations.ui.errors.nameIpPortRequired')))
        return
      }

      this.loading.obsAdd = true

      const sent = await this.sendWebsocket('obs_add', {
        name,
        ip,
        port,
        password,
      })

      this.loading.obsAdd = false

      if (!sent) return

      this.obsForm.password = ''

    },

    async removeObs(name: string) {
      if (!name) return

      this.loading.obsRemove = name

      const sent = await this.sendWebsocket('obs_remove', {
        name,
      })

      this.loading.obsRemove = ''

      if (!sent) return

    },

    async toggleYolobox(enabled: boolean | null) {
      const nextEnabled = Boolean(enabled)

      this.loading.yoloboxToggle = true

      const sent = await this.sendWebsocket('yolobox_toggle', {
        enabled: nextEnabled,
      })

      this.loading.yoloboxToggle = false

      if (!sent) return

    },

    async setAiMode(mode: 'internal' | 'external' | null) {
      const external = mode === 'external'
      this.ollamaModel = ''

      if (!external) {
        this.loading.ollamaExternal = true

        try {
          const sent = await this.sendWebsocket('ollama_external', {
            external: false,
            provider: this.ollamaExternalProvider,
            external_url: this.ollamaExternalUrl.trim(),
          })

          if (sent) {
            this.ollamaExternalEnabledOverride = null
            this.ollamaExternalProviderOverride = null
            this.ollamaExternalUrlOverride = null
          }
        } finally {
          this.loading.ollamaExternal = false
        }

        return
      }

      // If this provider is already configured, switching to external can happen
      // immediately. Otherwise reveal the external form and let Save & connect
      // finish the transition once a URL has been entered.
      if (this.ollamaExternalUrl.trim()) {
        this.loading.ollamaExternal = true

        try {
          const sent = await this.sendWebsocket('ollama_external', {
            external: true,
            provider: this.ollamaExternalProvider,
            external_url: this.ollamaExternalUrl.trim(),
          })

          if (sent) {
            this.ollamaExternalEnabledOverride = null
            this.ollamaExternalProviderOverride = null
            this.ollamaExternalUrlOverride = null
          }
        } finally {
          this.loading.ollamaExternal = false
        }

        return
      }

      this.ollamaExternalEnabledOverride = true
    },

    setOllamaExternalProvider(provider: 'ollama' | 'openai' | null) {
      this.ollamaExternalProviderOverride = provider === 'openai' ? 'openai' : 'ollama'
      this.ollamaExternalUrlOverride = null
      this.ollamaExternalApiKey = ''
      this.ollamaModel = ''
    },

    setOllamaExternalUrl(url: string | null) {
      this.ollamaExternalUrlOverride = String(url ?? '')
    },

    async saveOllamaExternal() {
      const external = this.ollamaExternalEnabled
      const externalUrl = this.ollamaExternalUrl.trim()

      if (external && !externalUrl) {
        this.showError(String(this.$t('integrations.ui.ollama.external.urlRequired')))
        return
      }

      this.loading.ollamaExternal = true

      try {
        const sent = await this.sendWebsocket('ollama_external', {
          external,
          provider: this.ollamaExternalProvider,
          external_url: externalUrl,
          api_key: this.ollamaExternalApiKey.trim() || undefined,
        })

        if (sent) {
          this.ollamaExternalEnabledOverride = null
          this.ollamaExternalProviderOverride = null
          this.ollamaExternalUrlOverride = null
          this.ollamaExternalApiKey = ''
          this.ollamaModel = ''
        }
      } finally {
        this.loading.ollamaExternal = false
      }
    },

    async clearOllamaExternalApiKey() {
      this.loading.ollamaExternal = true

      try {
        const sent = await this.sendWebsocket('ollama_external', {
          external: this.ollamaExternalEnabled,
          provider: this.ollamaExternalProvider,
          external_url: this.ollamaExternalUrl.trim(),
          clear_api_key: true,
        })

        if (sent) {
          this.ollamaExternalApiKey = ''
          this.ollamaExternalEnabledOverride = null
          this.ollamaExternalProviderOverride = null
          this.ollamaExternalUrlOverride = null
        }
      } finally {
        this.loading.ollamaExternal = false
      }
    },

    setOllamaSelectedModel(model: string | null) {
      this.ollamaModel = String(model ?? '')
    },

    async toggleOllama(enabled: boolean | null) {
      this.loading.ollamaToggle = true

      try {
        await this.sendWebsocket('ollama_toggle', {
          enabled: Boolean(enabled),
        })
      } finally {
        this.loading.ollamaToggle = false
      }
    },

    async changeOllamaModel() {
      const model = this.ollamaSelectedModel.trim()

      if (!model || model === this.ollamaStatus.model) return

      this.loading.ollamaModel = true

      try {
        const sent = await this.sendWebsocket('ollama_change_model', {
          model,
        })

        if (sent) {
          this.ollamaModel = ''
        }
      } finally {
        this.loading.ollamaModel = false
      }
    },

    async restartOllama() {
      this.loading.ollamaRestart = true

      try {
        await this.sendWebsocket('ollama_restart')
      } finally {
        this.loading.ollamaRestart = false
      }
    },

    async saveNeopixel() {
      const name = this.neopixelForm.name.trim()
      const gpio = Number(this.neopixelForm.gpio)
      const amount = Number(this.neopixelForm.amount)
      const heartbeatIndex = this.neopixelForm.heartbeat_index === null || this.neopixelForm.heartbeat_index === undefined
        ? undefined
        : Number(this.neopixelForm.heartbeat_index)

      if (!name || !Number.isInteger(gpio) || gpio < 0 || !Number.isInteger(amount) || amount <= 0) {
        this.showError(String(this.$t('integrations.ui.errors.nameGpioAmountRequired')))
        return
      }

      if (heartbeatIndex !== undefined && (!Number.isInteger(heartbeatIndex) || heartbeatIndex < 0 || heartbeatIndex >= amount)) {
        this.showError(String(this.$t('integrations.ui.errors.heartbeatOutOfRange')))
        return
      }

      this.loading.neopixelSave = true

      const sent = await this.sendWebsocket('neopixel_add', {
        name,
        gpio,
        amount,
        heartbeat_index: heartbeatIndex,
      })

      this.loading.neopixelSave = false

      if (!sent) return

    },

    async removeNeopixel(name: string) {
      if (!name) return

      this.loading.neopixelRemove = name

      const sent = await this.sendWebsocket('neopixel_remove', {
        name,
      })

      this.loading.neopixelRemove = ''

      if (!sent) return

      if (this.neopixelForm.name === name) {
        this.neopixelForm = {
          name: 'tablet_leds',
          gpio: 17,
          amount: 2,
          heartbeat_index: 1,
        }
      }

    },

    openTwitchAuth(type: TwitchAuthType) {
      const returnTo = encodeURIComponent(window.location.href)

      window.location.href = `${this.appStore.getRestApi}/api/auth/twitch?type=${type}&returnTo=${returnTo}`
    },

    showError(text: string) {
      console.error(text)
    },
  },
}
</script>


<style scoped>
.integration-card {
  height: 100%;
}

.integration-card :deep(.v-card-title) {
  min-height: 56px;
  padding-bottom: 8px;
}

.integration-card :deep(.v-card-text) {
  padding-top: 8px;
}

.integration-form {
  align-items: center;
}

.integration-action-btn {
  min-height: 40px;
}

.integration-inner-card {
  min-height: 118px;
}

.integration-card :deep(.v-list) {
  padding-top: 0;
}
</style>
