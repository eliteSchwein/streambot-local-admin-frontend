<template>
  <MacroTaskAccordionTemplate
    :item="item"
    :index="index"
    icon="mdi-shuffle-variant"
    :title="$t('macro.music.shuffle.title')"
    :detail="modeTitle"
    export-prefix="macro_music_shuffle"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-select
      v-model="mode"
      :items="modes"
      item-title="title"
      item-value="value"
      :label="$t('macro.music.fields.action')"
      variant="outlined"
      density="comfortable"
    />
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'

export default {
  name: 'MacroMusicShuffleTaskAccordion',
  components: { MacroTaskAccordionTemplate },
  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },
  emits: ['remove', 'move-up', 'move-down'],
computed: {
    modeTitle(): string {
      const value = String(this.mode ?? 'toggle')
      return String(this.$t(`macro.music.actions.${value}`))
    },
    task(): any { return (this.item as any).task },
    mode: {
      get(): string {
        if (this.task.data.enabled === true) return 'enable'
        if (this.task.data.enabled === false) return 'disable'
        return 'toggle'
      },
      set(value: string) {
        if (value === 'toggle') {
          delete this.task.data.enabled
          return
        }
        this.task.data.enabled = value === 'enable'
      },
    },
  },
  created() {
    this.task.channel = 'music'
    this.task.method = 'shuffle'
    this.task.data = this.task.data && typeof this.task.data === 'object' ? this.task.data : {}
  },
}
</script>
