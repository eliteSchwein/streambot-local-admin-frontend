<template>
  <MacroTaskAccordionTemplate
    class="macro-obs-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-folder-cog"
    :title="title"
    :detail="data.sceneCollectionName || ''"
    export-prefix="macro_obs_set_scene_collection"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-row density="comfortable">
      <v-col cols="12">
        <v-text-field
          v-model="data.sceneCollectionName"
          :label="$t('macro.obs.fields.sceneCollectionName')"
          prepend-inner-icon="mdi-folder-cog"
          variant="outlined"
          hide-details="auto"
        />
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'

export default {
  name: 'MacroObsSetSceneCollectionTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  computed: {
    task(): any {
      return (this.item as any).task
    },

    data(): any {
      return this.task.data
    },

    title(): string {
      return String(this.$t('macro.presets.obs.tools.setSceneCollection'))
    },
  },

  created() {
    this.task.channel = 'obs'
    this.task.method = 'SetCurrentSceneCollection'
    this.task.data = this.task.data && typeof this.task.data === 'object'
      ? this.task.data
      : {}

    if (this.data.sceneCollectionName === undefined) {
      this.data.sceneCollectionName = ''
    }
  },
}
</script>
