<template>
  <MacroTaskAccordionTemplate
    class="macro-obs-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-lock-open"
    :title="$t('macro.obs.unlockSceneItem.title')"
    :detail="obsSceneItemTitleDetail"
    export-prefix="macro_obs_unlock_scene_item"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-row density="comfortable">
      <v-col cols="12" md="6">
        <v-autocomplete
          v-model="data.sceneUuid"
          :items="sceneOptions"
          item-title="title"
          item-value="value"
          :label="$t('macro.obs.fields.scene')"
          prepend-inner-icon="mdi-view-dashboard"
          variant="outlined"
          hide-details="auto"
          clearable
          auto-select-first
          @update:model-value="onSceneChanged"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-autocomplete
          v-model="data.sceneItemId"
          :items="sceneItemOptions"
          item-title="title"
          item-value="value"
          :label="$t('macro.obs.fields.sceneItem')"
          prepend-inner-icon="mdi-layers-outline"
          variant="outlined"
          hide-details="auto"
          clearable
          auto-select-first
        />
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import { useAppStore } from '@/stores/app'
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'
import { getSceneItemOptions, getSceneOptions, migrateSceneNameToSceneUuid, getObsSceneDataForTask } from './obsTaskHelpers'

export default {
  name: 'MacroObsUnlockSceneItemTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  data() {
    return {
      appStore: useAppStore(),
    }
  },

  computed: {
    obsSceneItemTitleDetail(): string {
      const scene = String((this as any).data?.sceneName ?? (this as any).data?.sceneUuid ?? '').trim()
      const itemId = String((this as any).data?.sceneItemId ?? '').trim()
      if (!scene && !itemId) return ''
      return scene && itemId ? `${scene} · #${itemId}` : (scene || `#${itemId}`)
    },
    task(): any {
      const task = (this.item as any).task

      task.channel = 'obs'
      task.method = 'SetSceneItemLocked'
      task.data = task.data && typeof task.data === 'object' ? task.data : {}

      if (task.data.sceneUuid === undefined) task.data.sceneUuid = ''
      if (task.data.sceneItemId === undefined) task.data.sceneItemId = null

      task.data.sceneItemLocked = false

      migrateSceneNameToSceneUuid(task.data, getObsSceneDataForTask(this.appStore, this.item))

      return task
    },

    data(): any {
      return this.task.data
    },

    sceneOptions(): any[] {
      return getSceneOptions(getObsSceneDataForTask(this.appStore, this.item))
    },

    sceneItemOptions(): any[] {
      return getSceneItemOptions(getObsSceneDataForTask(this.appStore, this.item), this.data.sceneUuid)
    },
  },

  watch: {
    'appStore.getObsSceneDataByConnection': {
      handler() {
        migrateSceneNameToSceneUuid(this.data, getObsSceneDataForTask(this.appStore, this.item))
      },
      deep: true,
    },
  },

  created() {
    this.task
  },

  methods: {
    onSceneChanged() {
      this.data.sceneItemId = null
    },
  },
}
</script>
