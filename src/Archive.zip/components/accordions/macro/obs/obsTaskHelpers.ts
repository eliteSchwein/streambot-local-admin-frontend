import { useAppStore } from '@/stores/app'



export function getObsTaskConnection(itemOrTask: any): string {
  const task = itemOrTask?.task ?? itemOrTask ?? {}
  return String(task?.data?.connection ?? 'default').trim() || 'default'
}

export function getObsSceneDataForTask(store: any, itemOrTask: any): any[] {
  const connection = getObsTaskConnection(itemOrTask)
  const byConnection = store?.getObsSceneDataByConnection ?? store?.obsSceneDataByConnection ?? {}

  if (Object.prototype.hasOwnProperty.call(byConnection, connection)) {
    return asArray(byConnection[connection])
  }

  // Compatibility with older backends that only publish one global OBS index.
  if (Object.keys(byConnection).length === 0) {
    return asArray(store?.getObsSceneData ?? store?.obsSceneData)
  }

  return []
}

export function getObsAudioDataForTask(store: any, itemOrTask: any): any {
  const connection = getObsTaskConnection(itemOrTask)
  const byConnection = store?.getObsAudioDataByConnection ?? store?.obsAudioDataByConnection ?? {}

  if (Object.prototype.hasOwnProperty.call(byConnection, connection)) {
    return byConnection[connection] ?? {}
  }

  // Compatibility with older backends that only publish one global OBS index.
  if (Object.keys(byConnection).length === 0) {
    return store?.getObsAudioData ?? store?.obsAudioData ?? {}
  }

  return {}
}

export function cloneObsValue<T>(value: T): T {
  if (value === undefined || value === null) return value

  try {
    return JSON.parse(JSON.stringify(value)) as T
  } catch (_) {
    return value
  }
}

export function getObsBooleanItems(t: (key: string) => unknown) {
  return [
    { title: String(t('common.yes')), value: true },
    { title: String(t('common.no')), value: false },
  ]
}

export function asArray(value: any): any[] {
  return Array.isArray(value) ? value : []
}

export function uniqSorted(values: any[]): string[] {
  return [...new Set(values.filter(Boolean).map(String))].sort((a, b) => a.localeCompare(b))
}

export function getCanvasName(canvas: any): string {
  return String(canvas?.canvasName ?? canvas?.name ?? canvas?.canvas_name ?? '')
}

export function getCanvasUuid(canvas: any): string {
  return String(canvas?.canvasUuid ?? canvas?.canvasUUID ?? canvas?.uuid ?? canvas?.id ?? canvas?.canvasId ?? canvas?.canvas_id ?? '')
}

export function getCanvasScenes(canvas: any): any[] {
  return asArray(canvas?.scenes ?? canvas?.sceneData ?? canvas?.scene_data ?? canvas?.sceneList ?? canvas?.scene_list)
}

export function hasCanvasShape(entry: any): boolean {
  return getCanvasScenes(entry).length > 0 || Boolean(entry?.canvasUuid || entry?.canvasName || entry?.canvasId)
}

export function getScenesFromObsSceneData(obsSceneData: any): any[] {
  const scenes: any[] = []

  for (const entry of asArray(obsSceneData)) {
    const canvasScenes = getCanvasScenes(entry)

    if (canvasScenes.length > 0) {
      const canvasName = getCanvasName(entry)
      const canvasUuid = getCanvasUuid(entry)

      for (const scene of canvasScenes) {
        scenes.push({
          ...scene,
          canvasName: scene?.canvasName ?? canvasName,
          canvasUuid: scene?.canvasUuid ?? canvasUuid,
          canvas: scene?.canvas ?? entry,
        })
      }

      continue
    }

    scenes.push(entry)
  }

  return scenes
}

export function getSceneName(scene: any): string {
  return String(scene?.sceneName ?? scene?.name ?? scene?.scene_name ?? '')
}

export function getSceneUuid(scene: any): string {
  return String(scene?.sceneUuid ?? scene?.sceneUUID ?? scene?.uuid ?? scene?.id ?? scene?.sceneId ?? scene?.scene_id ?? '')
}

export function getSceneItems(scene: any): any[] {
  return asArray(scene?.sceneItems ?? scene?.items ?? scene?.sources ?? scene?.scene_items)
}

export function getSourceName(item: any): string {
  return String(item?.sourceName ?? item?.name ?? item?.inputName ?? item?.source_name ?? '')
}

export function getSceneItemId(item: any): any {
  return item?.sceneItemId ?? item?.id ?? item?.scene_item_id ?? null
}

export function getSceneOptions(obsSceneData: any): any[] {
  return getScenesFromObsSceneData(obsSceneData)
    .map((scene: any) => {
      const title = getSceneName(scene)
      const uuid = getSceneUuid(scene)
      const canvasName = getCanvasName(scene?.canvas) || scene?.canvasName

      if (!title || !uuid) return null

      return {
        title: canvasName ? `${canvasName} / ${title}` : title,
        value: uuid,
        props: {},
      }
    })
    .filter(Boolean)
    .sort((a: any, b: any) => a.title.localeCompare(b.title))
}

export function getSceneNames(obsSceneData: any): string[] {
  return uniqSorted(getScenesFromObsSceneData(obsSceneData).map(getSceneName))
}

export function getSceneUuids(obsSceneData: any): string[] {
  return uniqSorted(getScenesFromObsSceneData(obsSceneData).map(getSceneUuid))
}

export function findSceneUuidByName(obsSceneData: any, sceneName: string): string {
  if (!sceneName) return ''

  const scene = getScenesFromObsSceneData(obsSceneData).find((entry: any) => getSceneName(entry) === sceneName)
  return scene ? getSceneUuid(scene) : ''
}

export function getSceneItemOptions(obsSceneData: any, sceneUuid: string): any[] {
  const scene = getScenesFromObsSceneData(obsSceneData).find((entry: any) => getSceneUuid(entry) === sceneUuid)

  return getSceneItems(scene)
    .map((item: any) => {
      const name = getSourceName(item)
      const id = getSceneItemId(item)

      if (!name || id === null || id === undefined) return null

      return {
        title: `${name} (#${id})`,
        value: id,
      }
    })
    .filter(Boolean)
}

export function collectInputNamesFromObsAudioData(obsAudioData: any): string[] {
  const names: string[] = []

  const walk = (value: any) => {
    if (!value) return

    if (Array.isArray(value)) {
      value.forEach(walk)
      return
    }

    if (typeof value !== 'object') return

    const name = value.inputName ?? value.sourceName ?? value.name ?? value.label
    if (name) names.push(String(name))

    Object.values(value).forEach(walk)
  }

  walk(obsAudioData)
  return names
}

export function getInputNames(obsSceneData: any, obsAudioData: any = null): string[] {
  const names: string[] = []

  for (const scene of getScenesFromObsSceneData(obsSceneData)) {
    for (const item of getSceneItems(scene)) {
      const name = getSourceName(item)
      if (name) names.push(name)
    }
  }

  names.push(...collectInputNamesFromObsAudioData(obsAudioData))

  return uniqSorted(names)
}

export function getSourceFilters(item: any): any[] {
  if (!item || typeof item !== 'object') return []

  const candidates = [
    item.filters,
    item.sourceFilters,
    item.source_filters,
    item.filterList,
    item.filter_list,
  ]

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate
  }

  return []
}

export function getSourceFilter(
  obsSceneData: any,
  sourceName: string,
  filterName: string,
): any | null {
  if (!sourceName || !filterName) return null

  const matchesFilter = (filter: any): boolean => {
    const name = filter?.filterName ?? filter?.name ?? filter?.sourceName
    return String(name ?? '') === filterName
  }

  const inspect = (item: any): any | null => {
    if (getSourceName(item) !== sourceName) return null
    return getSourceFilters(item).find(matchesFilter) ?? null
  }

  for (const scene of getScenesFromObsSceneData(obsSceneData)) {
    const sceneFilter = inspect(scene)
    if (sceneFilter) return sceneFilter

    for (const item of getSceneItems(scene)) {
      const filter = inspect(item)
      if (filter) return filter
    }
  }

  return null
}

export function getFilterSettings(
  obsSceneData: any,
  sourceName: string,
  filterName: string,
): Record<string, any> {
  const filter = getSourceFilter(obsSceneData, sourceName, filterName)
  const settings =
    filter?.filterSettings
    ?? filter?.settings
    ?? filter?.filter_settings
    ?? {}

  if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
    return {}
  }

  return cloneObsValue(settings)
}

export function getFilterNames(obsSceneData: any, sourceName: string): string[] {
  const filters: string[] = []

  const collect = (item: any) => {
    if (!item || typeof item !== 'object') return

    const itemName = getSourceName(item)
    if (sourceName && itemName && itemName !== sourceName) return

    for (const filter of getSourceFilters(item)) {
      const name = filter?.filterName ?? filter?.name ?? filter?.sourceName
      if (name) filters.push(String(name))
    }
  }

  for (const scene of getScenesFromObsSceneData(obsSceneData)) {
    collect(scene)
    getSceneItems(scene).forEach(collect)
  }

  return uniqSorted(filters)
}

export function ensureTaskData(item: any): any {
  if (!item.task || typeof item.task !== 'object') item.task = {}
  if (!item.task.data || typeof item.task.data !== 'object' || Array.isArray(item.task.data)) item.task.data = {}
  return item.task.data
}

export function ensureObsTask(item: any, method: string, defaults: Record<string, any> = {}) {
  if (!item.task || typeof item.task !== 'object') item.task = {}

  item.task.channel = 'obs'
  item.task.method = method

  const data = ensureTaskData(item)

  for (const [key, value] of Object.entries(defaults)) {
    if (data[key] === undefined) data[key] = value
  }

  return data
}

export function migrateSceneNameToSceneUuid(data: any, obsSceneData: any): void {
  if (!data || typeof data !== 'object') return

  if (!data.sceneUuid && data.sceneName) {
    data.sceneUuid = findSceneUuidByName(obsSceneData, String(data.sceneName))
  }

  if ('sceneName' in data) {
    delete data.sceneName
  }
}

export function obsStoreMixin() {
  return {
    computed: {
      appStore(): any {
        return useAppStore()
      },

      obsData(): any {
        return ensureTaskData((this as any).item)
      },

      obsSceneData(): any[] {
        const store = (this as any).appStore
        return getObsSceneDataForTask(store, (this as any).item)
      },

      obsAudioData(): any {
        const store = (this as any).appStore
        return getObsAudioDataForTask(store, (this as any).item)
      },

      sceneOptions(): any[] {
        return getSceneOptions((this as any).obsSceneData)
      },

      sceneNames(): string[] {
        return getSceneNames((this as any).obsSceneData)
      },

      sceneUuids(): string[] {
        return getSceneUuids((this as any).obsSceneData)
      },

      inputNames(): string[] {
        return getInputNames((this as any).obsSceneData, (this as any).obsAudioData)
      },
    },

    methods: {
      sceneItemOptions(sceneUuid: string): any[] {
        return getSceneItemOptions((this as any).obsSceneData, sceneUuid)
      },

      filterNames(sourceName: string): string[] {
        return getFilterNames((this as any).obsSceneData, sourceName)
      },
    },
  }
}
