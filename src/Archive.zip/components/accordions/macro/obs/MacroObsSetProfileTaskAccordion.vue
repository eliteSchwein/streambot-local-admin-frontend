<template>
  <MacroTaskAccordionTemplate
    class="macro-obs-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-account-cog"
    :title="title"
    :detail="data.profileName || ''"
    export-prefix="macro_obs_set_profile"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-row density="comfortable">
      <v-col cols="12">
        <v-text-field
          v-model="data.profileName"
          :label="$t('macro.obs.fields.profileName')"
          prepend-inner-icon="mdi-account-cog"
          variant="outlined"
          hide-details="auto"
        />
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'

export default {
  name: 'MacroObsSetProfileTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  computed: {
    task(): any {
      return (this.item as any).task
    },

    data(): any {
      return this.task.data
    },

    title(): string {
      return String(this.$t('macro.obs.setProfile.title'))
    },
  },

  created() {
    this.task.channel = 'obs'
    this.task.method = 'SetCurrentProfile'
    this.task.data = this.task.data && typeof this.task.data === 'object'
      ? this.task.data
      : {}

    if (this.data.profileName === undefined) {
      this.data.profileName = ''
    }
  },
}
</script>
