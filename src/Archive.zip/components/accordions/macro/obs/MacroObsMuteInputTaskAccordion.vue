<template>
  <MacroTaskAccordionTemplate
    class="macro-obs-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-volume-off"
    :title="$t('macro.obs.muteInput.title')"
    :detail="task.data?.inputName || ''"
    export-prefix="macro_obs_mute_input"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-row density="comfortable">
      <v-col cols="12">
        <v-autocomplete
          v-model="task.data.inputName"
          :items="inputOptions"
          :label="$t('macro.obs.fields.inputSource')"
          prepend-inner-icon="mdi-import"
          variant="outlined"
          hide-details="auto"
          clearable
          auto-select-first
        />
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import { useAppStore } from '@/stores/app'
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'
import { getInputNames, getObsSceneDataForTask, getObsAudioDataForTask } from './obsTaskHelpers'

export default {
  name: 'MacroObsMuteInputTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  data() {
    return {
      appStore: useAppStore(),
    }
  },

  computed: {
    task(): any {
      const task = (this.item as any).task

      task.channel = 'obs'
      task.method = 'SetInputMute'
      task.data = task.data && typeof task.data === 'object' ? task.data : {}

      if (task.data.inputName === undefined) task.data.inputName = ''

      task.data.inputMuted = true

      return task
    },

    inputOptions(): string[] {
      return getInputNames(getObsSceneDataForTask(this.appStore, this.item), getObsAudioDataForTask(this.appStore, this.item))
    },
  },

  created() {
    this.task
  },
}
</script>
