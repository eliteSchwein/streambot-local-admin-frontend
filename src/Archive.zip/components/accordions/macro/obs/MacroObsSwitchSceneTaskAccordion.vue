<template>
  <MacroTaskAccordionTemplate
    class="macro-obs-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-monitor-screenshot"
    :title="title"
    :detail="selectedSceneTitle"
    export-prefix="macro_obs_switch_scene"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <v-row density="comfortable">
      <v-col cols="12">
        <v-autocomplete
          v-model="data.sceneUuid"
          :items="sceneOptions"
          item-title="title"
          item-value="value"
          :label="$t('macro.obs.fields.scene')"
          prepend-inner-icon="mdi-view-dashboard"
          variant="outlined"
          hide-details="auto"
          clearable
          auto-select-first
        />
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import { useAppStore } from '@/stores/app'
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'
import { getSceneOptions, migrateSceneNameToSceneUuid, getObsSceneDataForTask } from './obsTaskHelpers'

export default {
  name: 'MacroObsSwitchSceneTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  data() {
    return {
      appStore: useAppStore(),
    }
  },

  computed: {
    selectedSceneTitle(): string {
      const value = String(this.data?.sceneUuid ?? '').trim()
      if (!value) return ''
      const match = Array.isArray((this as any).sceneOptions) ? (this as any).sceneOptions.find((entry: any) => String(entry?.value ?? '') === value) : undefined
      return String(match?.title ?? value)
    },
    task(): any {
      const task = (this.item as any).task

      task.channel = 'obs'
      task.method = 'SetCurrentProgramScene'
      task.data = task.data && typeof task.data === 'object' ? task.data : {}

      if (task.data.sceneUuid === undefined) task.data.sceneUuid = ''

      migrateSceneNameToSceneUuid(task.data, getObsSceneDataForTask(this.appStore, this.item))

      return task
    },

    data(): any {
      return this.task.data
    },

    title(): string {
      return String(this.$t('macro.obs.switchScene.title'))
    },

    sceneOptions(): any[] {
      return getSceneOptions(getObsSceneDataForTask(this.appStore, this.item))
    },
  },

  watch: {
    'appStore.getObsSceneDataByConnection': {
      handler() {
        migrateSceneNameToSceneUuid(this.data, getObsSceneDataForTask(this.appStore, this.item))
      },
      deep: true,
    },
  },

  created() {
    this.task
  },
}
</script>
