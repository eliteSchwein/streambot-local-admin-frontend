<template>
  <MacroTaskAccordionTemplate
    class="macro-task-accordion macro-task-accordion--animation"
    :item="item"
    :index="index"
    icon="mdi-animation-play"
    :title="$t('macro.core.animation.title')"
    :detail="animationTitleDetail"
    export-prefix="macro_animation"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
    @group:selected="onExpansionChange"
  >
    <v-row density="comfortable">
      <v-col cols="12" md="6">
        <v-combobox
          v-model="task.data.target"
          :items="animationTargetOptions"
          :label="$t('macro.core.animation.target')"
          prepend-inner-icon="mdi-crosshairs-gps"
          clearable
          hide-details="auto"
          variant="outlined"
          density="comfortable"
          auto-select-first
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-autocomplete
          v-model="task.data.src"
          :items="sourceOptions"
          :loading="loadingSources"
          :label="$t('macro.core.animation.source')"
          prepend-inner-icon="mdi-file-code"
          clearable
          hide-details="auto"
          variant="outlined"
          density="comfortable"
          @update:model-value="task.data.src = normalizePath($event)"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-number-input
          v-model="task.data.startFrame"
          :label="$t('macro.core.animation.startFrame')"
          prepend-inner-icon="mdi-ray-start"
          hide-details="auto"
          variant="outlined"
          density="comfortable"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-number-input
          v-model="task.data.stopFrame"
          :label="$t('macro.core.animation.stopFrame')"
          prepend-inner-icon="mdi-ray-end"
          hide-details="auto"
          variant="outlined"
          density="comfortable"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-number-input
          v-model="task.data.speed"
          :label="$t('macro.core.animation.speed')"
          prepend-inner-icon="mdi-speedometer"
          hide-details="auto"
          variant="outlined"
          density="comfortable"
          :step="0.1"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-combobox
          v-model="task.data.frameRate"
          :items="frameRateOptions"
          :label="$t('macro.core.animation.frameRate')"
          prepend-inner-icon="mdi-filmstrip"
          clearable
          hide-details="auto"
          variant="outlined"
          density="comfortable"
          @update:model-value="task.data.frameRate = toNullableNumber($event)"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-switch
          v-model="task.data.loop"
          :label="$t('macro.core.animation.loop')"
          color="primary"
          hide-details="auto"
          density="comfortable"
        />
      </v-col>

      <v-col cols="12" md="6">
        <v-switch
          v-model="task.data.reverse"
          :label="$t('macro.core.animation.reverse')"
          color="primary"
          hide-details="auto"
          density="comfortable"
        />
      </v-col>

      <v-col cols="12">
        <div class="d-flex align-center justify-space-between mb-2">
          <div class="text-subtitle-2">{{ $t('macro.core.animation.variables') }}</div>

          <v-btn
            size="small"
            variant="tonal"
            color="primary"
            prepend-icon="mdi-plus"
            @click="addVariable"
          >{{ $t('macro.core.animation.addVariable') }}</v-btn>
        </div>

        <v-alert
          v-if="!variableRows.length"
          type="info"
          variant="tonal"
          density="compact"
          class="mb-2"
        >{{ $t('macro.core.animation.noVariablesConfigured') }}</v-alert>

        <v-row
          v-for="(variable, variableIndex) in variableRows"
          :key="variable.id"
          density="compact"
          class="align-center mb-1"
        >
          <v-col cols="12" md="5">
            <v-text-field
              v-model="variable.key"
              :label="$t('macro.core.animation.key')"
              prepend-inner-icon="mdi-key-outline"
              hide-details="auto"
              variant="outlined"
              density="comfortable"
              @update:model-value="syncVariablesFromRows"
            />
          </v-col>

          <v-col cols="12" md="6">
            <v-text-field
              v-model="variable.value"
              :label="$t('macro.core.animation.value')"
              prepend-inner-icon="mdi-code-braces"
              hide-details="auto"
              variant="outlined"
              density="comfortable"
              @update:model-value="syncVariablesFromRows"
            />
          </v-col>

          <v-col cols="12" md="1" class="d-flex justify-end">
            <v-btn
              icon="mdi-delete"
              variant="text"
              color="error"
              :aria-label="`Remove variable ${variableIndex + 1}`"
              @click="removeVariable(variableIndex)"
            />
          </v-col>
        </v-row>
      </v-col>
    </v-row>
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import { getWebsocketClient } from '@/plugins/websocketInstance'
import { useAppStore } from '@/stores/app'
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'

type MediaEntry = {
  name?: string
  path?: string
  type?: 'file' | 'folder' | string
  asset?: string | { original?: string; compressed?: string | null } | null
  compressed?: string | null
}

type VariableRow = {
  id: string
  key: string
  value: any
}

const animationSourceRegex = /\.(svg|json|lottie)$/i

export default {
  name: 'MacroAnimationTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
    depth: { type: Number, default: 0 },
  },

  emits: ['remove', 'move-up', 'move-down'],

  data() {
    return {
      appStore: useAppStore(),
      frameRateOptions: [60, 45, 30],
      loadingSources: false,
      mediaEntries: [] as MediaEntry[],
      mediaLoaded: false,
      variableRows: [] as VariableRow[],
    }
  },

  computed: {
    animationTargetOptions(): string[] {
      const dynamicData =
        this.appStore?.getDynamicData ??
        this.appStore?.dynamicData ??
        {}

      const targets = Array.isArray(dynamicData?.animation_targets)
        ? dynamicData.animation_targets
        : []

      const current = String(this.task.data?.target ?? '').trim()

      return [...new Set([
        ...targets
          .map((value: any) => String(value).trim())
          .filter(Boolean),
        ...(current ? [current] : []),
      ])].sort((a, b) => a.localeCompare(b))
    },

    task(): any {
      return (this.item as any).task
    },

    animationTitleDetail(): string {
      return String(this.task.data?.target || this.task.data?.src || '').trim()
    },

    sourceOptions(): string[] {
      return this.mediaOptions(animationSourceRegex, false)
    },
  },

  created() {
    this.ensureData()
    this.variableRows = this.variablesToRows(this.task.data.variables)
  },

  methods: {
    ensureData() {
      this.task.channel = 'animation'
      this.task.method = 'play'

      if (!this.task.data || typeof this.task.data !== 'object') {
        this.task.data = {}
      }

      if (this.task.data.speed === undefined) this.task.data.speed = 1
      if (this.task.data.loop === undefined) this.task.data.loop = false
      if (this.task.data.reverse === undefined) this.task.data.reverse = false
    },

    async requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      const client = getWebsocketClient()

      if (!client) {
        throw new Error('websocket is not connected')
      }

      const response = await client.request(method, params, timeout)
      return response?.params ?? response
    },

    async onExpansionChange(event: any) {
      const expanded = typeof event === 'boolean' ? event : Boolean(event?.value)

      if (!expanded || this.mediaLoaded || this.loadingSources) return

      await this.fetchMediaEntries()
    },

    async requestMediaList(path: string = ''): Promise<any> {
      const appStore = useAppStore()

      try {
        const response = await this.requestWebsocket('media_list', { path })
        return response?.data ?? response
      } catch (websocketError) {
        const response = await fetch(`${appStore.getRestApi}/api/assets/media/list`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path }),
        })

        const data = await response.json().catch(() => ({}))
        const responseData = data?.data ?? data

        if (!response.ok || responseData?.error || data?.error) {
          throw new Error(responseData?.error ?? data?.error ?? 'media list failed')
        }

        return responseData
      }
    },

    async fetchMediaEntries(path: string = ''): Promise<MediaEntry[]> {
      if (!path) this.loadingSources = true

      try {
        const data = await this.requestMediaList(path)
        const files = Array.isArray(data?.files) ? data.files : []
        const result: MediaEntry[] = []

        for (const entry of files) {
          result.push(entry)

          if (entry?.type === 'folder' && entry?.path) {
            result.push(...await this.fetchMediaEntries(entry.path))
          }
        }

        if (!path) {
          this.mediaEntries = result.filter((entry) => entry?.type === 'file')
          this.mediaLoaded = true
        }

        return result
      } catch (error) {
        if (!path) {
          this.mediaEntries = []
          this.mediaLoaded = false
        }

        return []
      } finally {
        if (!path) this.loadingSources = false
      }
    },

    mediaOptions(regex: RegExp, compressedFirst: boolean): string[] {
      const values: string[] = []

      const add = (value: any) => {
        const normalized = this.normalizePath(value)

        if (!normalized || !regex.test(normalized)) return

        regex.lastIndex = 0

        if (!values.includes(normalized)) values.push(normalized)
      }

      for (const entry of this.mediaEntries as MediaEntry[]) {
        if (!entry || entry.type !== 'file') continue

        const original = this.getEntryOriginal(entry)
        const compressed = this.getEntryCompressed(entry)

        if (compressedFirst) {
          add(compressed)
          add(original)
        } else {
          add(original)
          add(compressed)
        }
      }

      const current = this.normalizePath(this.task.data?.src)

      if (current && regex.test(current) && !values.includes(current)) {
        values.unshift(current)
      }

      regex.lastIndex = 0

      return values.sort((a, b) => a.localeCompare(b))
    },

    normalizePath(value: any): string {
      return String(value ?? '')
        .replace(/\\/g, '/')
        .replace(/^\/+/, '')
        .trim()
    },

    getEntryOriginal(entry: MediaEntry): string {
      if (typeof entry.asset === 'object' && entry.asset?.original) {
        return this.normalizePath(entry.asset.original)
      }

      if (typeof entry.asset === 'string') {
        return this.normalizePath(entry.asset)
      }

      return this.normalizePath(entry.path ?? entry.name)
    },

    getEntryCompressed(entry: MediaEntry): string {
      if (typeof entry.compressed === 'string') {
        return this.normalizePath(entry.compressed)
      }

      if (typeof entry.asset === 'object' && typeof entry.asset?.compressed === 'string') {
        return this.normalizePath(entry.asset.compressed)
      }

      return ''
    },

    toNullableNumber(value: any): number | null {
      if (value === undefined || value === null || value === '') return null

      const rawValue = typeof value === 'object'
        ? value.value ?? value.raw?.value ?? value.raw ?? value.title
        : value

      const numberValue = Number(rawValue)
      return Number.isFinite(numberValue) ? numberValue : null
    },

    variablesToRows(value: any): VariableRow[] {
      if (!value || typeof value !== 'object' || Array.isArray(value)) return []

      return Object.entries(value).map(([key, rowValue], index) => ({
        id: `${Date.now()}-${index}-${key}`,
        key,
        value: rowValue,
      }))
    },

    addVariable() {
      this.variableRows.push({
        id: `${Date.now()}-${Math.random()}`,
        key: '',
        value: '',
      })

      this.syncVariablesFromRows()
    },

    removeVariable(index: number) {
      this.variableRows.splice(index, 1)
      this.syncVariablesFromRows()
    },

    syncVariablesFromRows() {
      const variables: Record<string, any> = {}

      for (const row of this.variableRows as VariableRow[]) {
        const key = String(row.key ?? '').trim()

        if (!key) continue

        variables[key] = row.value
      }

      if (Object.keys(variables).length) {
        this.task.data.variables = variables
      } else {
        delete this.task.data.variables
      }
    },
  },
}
</script>
