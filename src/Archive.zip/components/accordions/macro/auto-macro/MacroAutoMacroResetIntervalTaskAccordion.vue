<template>
  <MacroTaskAccordionTemplate
    class="macro-auto-macro-reset-interval-task-accordion"
    :item="item"
    :index="index"
    icon="mdi-timer-refresh-outline"
    :title="$t('macro.core.autoMacroResetInterval.title')"
    :detail="data.name || ''"
    export-prefix="macro_auto_macro_reset_interval"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <AutoMacroSelect v-model="data.name" :label="$t('macro.core.autoMacroResetInterval.autoMacro')" />

    <v-alert
      type="info"
      variant="tonal"
      density="compact"
      class="mt-3"
      :text="$t('macro.core.autoMacroResetInterval.hint')"
    />
  </MacroTaskAccordionTemplate>
</template>

<script lang="ts">
import MacroTaskAccordionTemplate from '../MacroTaskAccordionTemplate.vue'
import AutoMacroSelect from './AutoMacroSelect.vue'

export default {
  name: 'MacroAutoMacroResetIntervalTaskAccordion',

  components: {
    MacroTaskAccordionTemplate,
    AutoMacroSelect,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
  },

  emits: ['remove', 'move-up', 'move-down'],

  computed: {
    task(): any {
      const task = (this.item as any).task
      task.channel = 'auto_macro'
      task.method = 'reset_interval'
      task.data = task.data && typeof task.data === 'object' ? task.data : {}
      if (task.data.name === undefined) task.data.name = task.data.autoMacro ?? ''
      delete task.data.autoMacro
      return task
    },

    data(): any {
      return this.task.data
    },
  },

  created() {
    this.task
  },
}
</script>
