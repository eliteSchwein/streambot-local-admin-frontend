<template>
  <MacroFunctionBaseTaskAccordion
    :item="item"
    :index="index"
    :depth="depth"
    :custom-title="$t('macro.function.sendDm.title')"
    :title-detail="titleDetail"
    icon="mdi-message-lock-outline"
    @remove="$emit('remove')"
    @move-up="$emit('move-up')"
    @move-down="$emit('move-down')"
  >
    <template #default="{ data }">
      <v-col cols="12" md="4">
        <v-text-field v-model="data.user" :label="$t('macro.function.fields.user')" density="compact" variant="outlined" hide-details />
      </v-col>
      <v-col cols="12" md="8">
        <v-text-field v-model="data.content" :label="$t('macro.function.fields.message')" density="compact" variant="outlined" hide-details />
      </v-col>
    </template>
  </MacroFunctionBaseTaskAccordion>
</template>

<script lang="ts">
import MacroFunctionBaseTaskAccordion from './MacroFunctionBaseTaskAccordion.vue'

export default {
  name: 'MacroFunctionSendDmTaskAccordion',

  components: {
    MacroFunctionBaseTaskAccordion,
  },

  props: {
    item: { type: Object, required: true },
    index: { type: Number, required: true },
    depth: { type: Number, default: 0 },
  },

  emits: ['remove', 'move-up', 'move-down'],

  computed: {
    titleDetail(): string {
      const data = this.taskData
      const user = String(data.user ?? '').trim()
      const message = this.preview(String(data.content ?? ''))
      return [user, message].filter(Boolean).join(' · ')
    },

    taskData(): any {
      return (this.item as any).task?.data ?? {}
    },
  },

  methods: {
    preview(value: string): string {
      const normalized = value.replace(/\s+/g, ' ').trim()
      return normalized.length > 64 ? `${normalized.slice(0, 61)}…` : normalized
    },
  },

  created() {
    const task = (this.item as any).task
    task.channel = 'function'
    task.method = 'send_dm'
    if (!task.data || typeof task.data !== 'object') task.data = {}

    task.data.user = String(task.data.user ?? '')
    task.data.content = String(task.data.content ?? '')
    delete task.data.account
  },
}
</script>
