<template>
  <v-dialog
    :model-value="modelValue"
    fullscreen
    scrollable
    @update:model-value="$emit('update:modelValue', $event)"
  >
    <v-card color="grey-darken-4" class="channel-point-dialog">
      <v-toolbar flat density="comfortable">
        <v-toolbar-title class="d-flex align-center min-width-0">
          <v-icon icon="mdi-star-circle" class="mr-2" />
          <span class="text-truncate">{{ title }}</span>
        </v-toolbar-title>

        <v-spacer />

        <YamlImportExportButtons
          class="mr-2"
          :filename="exportFilename"
          :disabled="loading || initializingInternal || savingInternal"
          :export-data="buildExportPayload()"
          @import="importChannelPoint"
          @error="handleImportError"
        />

        <v-btn icon="mdi-close" variant="text" @click="$emit('update:modelValue', false)" />
      </v-toolbar>

      <v-card-text class="py-3 px-0">
        <v-alert
          v-if="error || errorMessage"
          type="error"
          color="red-darken-3"
          density="comfortable"
          class="mb-3"
          :text="error || errorMessage"
        />

        <v-expansion-panels v-model="openPanels" variant="accordion">
          <v-expansion-panel value="options">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-tune" />
                <span class="text-truncate">{{ $t('dialogs.channelPointDialog.options') }}</span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <div class="option-card-grid px-3 mb-4">
                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.channelPointDialog.general') }}</div>
                  <v-text-field v-model="form.name" :label="$t('dialogs.channelPointDialog.name')" density="comfortable" variant="outlined" hide-details="auto" :error-messages="!isEditing && nameExists ? [$t('common.nameAlreadyExists')] : []" />
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.channelPointDialog.options') }}</div>
                  <v-row density="comfortable">
                    <v-col cols="12" sm="6"><v-switch v-model="form.enable_default" :label="$t('dialogs.channelPointDialog.enableDefault')" color="primary" density="comfortable" hide-details inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.auto_accept" :label="$t('dialogs.channelPointDialog.autoAccept')" color="primary" density="comfortable" hide-details inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.strip_emotes" :label="$t('dialogs.channelPointDialog.stripEmotes')" color="primary" density="comfortable" hide-details inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.strip_urls" :label="$t('dialogs.channelPointDialog.stripUrls')" color="primary" density="comfortable" hide-details inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.input_required" :label="$t('dialogs.channelPointDialog.inputRequired')" color="primary" density="comfortable" hide-details inset /></v-col>
                  </v-row>
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.channelPointDialog.interaction') }}</div>
                  <v-switch v-model="form.bypass_interaction_queue" :label="$t('dialogs.channelPointDialog.bypassInteractionQueue')" color="primary" density="comfortable" hide-details inset />
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('twitchAccess.title') }}</div>
                  <TwitchAccessRequirements v-model="form" />
                </v-card>
              </div>
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel value="asset">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-palette" />
                <span class="text-truncate">{{ $t('dialogs.channelPointDialog.asset') }}</span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <v-progress-linear v-if="assetLoading" indeterminate class="mb-3" />
              <ChannelPointAssetAccordion
                v-show="!assetLoading"
                ref="assetAccordion"
                :name="generatedConfigName"
                :auto-load="false"
                :disabled="loading || savingInternal"
              />
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel value="macro">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-code-braces" />
                <span class="text-truncate">{{ $t('dialogs.channelPointDialog.macro') }}</span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <v-progress-linear v-if="macroLoading" indeterminate class="mb-3" />
              <ChannelPointMacroAccordion
                v-show="!macroLoading"
                ref="macroAccordion"
                :name="generatedConfigName"
                :initial-content="macroContent"
                template-context="channel_point"
                :template-name="generatedConfigName"
                :template-macro="generatedConfigName"
                :auto-load="false"
              />
            </v-expansion-panel-text>
          </v-expansion-panel>
        </v-expansion-panels>
      </v-card-text>

      <v-divider />

      <v-card-actions>
        <v-spacer />
        <v-btn
          variant="text"
          prepend-icon="mdi-close"
          :disabled="loading || initializingInternal || savingInternal"
          @click="$emit('update:modelValue', false)"
        >
          {{ $t('common.cancel') }}
        </v-btn>
        <v-btn
          color="primary"
          variant="tonal"
          prepend-icon="mdi-content-save"
          :loading="loading || initializingInternal || savingInternal"
          :disabled="!canSave"
          @click="save"
        >
          {{ $t('common.save') }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script lang="ts">
import TwitchAccessRequirements from '@/components/inputs/TwitchAccessRequirements.vue'
import { getWebsocketClient } from '@/plugins/websocketInstance'
import { useAppStore } from '@/stores/app'
import { checkNameExists } from '@/helper/NameExistsHelper'
import ChannelPointAssetAccordion from '@/components/accordions/ChannelPointAssetAccordion.vue'
import ChannelPointMacroAccordion from '@/components/accordions/ChannelPointMacroAccordion.vue'
import YamlImportExportButtons from '@/components/YamlImportExportButtons.vue'

export default {
  name: 'ChannelPointDialog',

  components: {
    TwitchAccessRequirements,
    ChannelPointAssetAccordion,
    ChannelPointMacroAccordion,
    YamlImportExportButtons,
  },

  props: {
    modelValue: { type: Boolean, default: false },
    channelPoint: { type: Object, default: null },
    loading: { type: Boolean, default: false },
    error: { type: String, default: '' },
  },

  emits: ['update:modelValue', 'save'],

  data() {
    return {
      appStore: useAppStore(),
      openPanels: 'options',
      assetLoading: false,
      macroLoading: false,
      form: {
        name: '',
        enable_default: false,
        auto_accept: false,
        strip_emotes: false,
        strip_urls: false,
        input_required: false,
        bypass_interaction_queue: false,
        require_follower: false,
        minimum_follow_seconds: 0,
        require_subscriber: false,
        minimum_sub_tier: 0,
        minimum_sub_months: 0,
        require_vip: false,
        require_moderator: false,
      },
      originalName: '',
      macroContent: '',
      errorMessage: '',
      savingInternal: false,
      initializingInternal: false,
      nameChecking: false,
      nameExists: false,
      nameCheckTimer: null as ReturnType<typeof setTimeout> | null,
      nameCheckToken: 0,
    }
  },

  computed: {
    title(): string {
      return this.isEditing
        ? (this.channelPoint?.label ? `${this.$t('channelPoints.edit')}: ${this.channelPoint.label}` : this.$t('channelPoints.edit'))
        : this.$t('channelPoints.create')
    },


    isEditing(): boolean {
      return !!this.channelPoint
    },

    normalizedName(): string {
      return this.isEditing && this.originalName ? this.originalName : this.normalizeName(this.form.name)
    },

    generatedConfigName(): string {
      return this.normalizedName ? `channel_point_${this.normalizedName}` : 'channel_point_'
    },

    canSave(): boolean {
      return String(this.form.name ?? '').trim().length > 0 && this.normalizedName.length > 0 && !this.loading && !this.initializingInternal && !this.savingInternal && !this.assetLoading && !this.macroLoading && (this.isEditing || (!this.nameChecking && !this.nameExists))
    },

    exportFilename(): string {
      const name = this.normalizedName || this.normalizeName(this.form.name) || 'new'
      return `channel_point_${name}.yaml`
    },

  },

  watch: {
    normalizedName() {
      if (!this.isEditing) this.scheduleNameCheck()
    },
    isEditing(value: boolean) {
      if (value) { this.nameChecking = false; this.nameExists = false }
      else this.scheduleNameCheck()
    },
  },

  methods: {
    buildConfigPayload() {
      const normalizedName = this.normalizedName || this.normalizeName(this.form.name)
      const generatedName = normalizedName ? `channel_point_${normalizedName}` : 'channel_point_'

      return {
        label: String(this.form.name || normalizedName).trim(),
        name: normalizedName,
        enable_default: this.form.enable_default,
        auto_accept: this.form.auto_accept,
        strip_emotes: this.form.strip_emotes,
        strip_urls: this.form.strip_urls,
        input_required: this.form.input_required,
        bypass_interaction_queue: this.form.bypass_interaction_queue,
        require_follower: this.form.require_follower === true,
        minimum_follow_seconds: Math.max(0, Number(this.form.minimum_follow_seconds ?? 0) || 0),
        require_subscriber: this.form.require_subscriber === true,
        minimum_sub_tier: Math.max(0, Number(this.form.minimum_sub_tier ?? 0) || 0),
        minimum_sub_months: Math.max(0, Number(this.form.minimum_sub_months ?? 0) || 0),
        require_vip: this.form.require_vip === true,
        require_moderator: this.form.require_moderator === true,
        asset: generatedName,
        macro: generatedName,
      }
    },

    buildExportPayload() {
      const config = this.buildConfigPayload()
      const macroContent =
        (this.$refs.macroAccordion as any)?.getContent?.()
        || this.macroContent
        || this.defaultMacroContent(this.generatedConfigName)

      return {
        streambot_export: {
          version: 1,
          kind: 'channel_point',
        },
        config: {
          name: config.name,
          path: `${config.name || 'channel_point'}.yaml`,
          content: config,
        },
        asset: {
          name: this.generatedConfigName,
          content: (this.$refs.assetAccordion as any)?.getAssetPayload?.() ?? {},
        },
        macro: {
          name: this.generatedConfigName,
          content: macroContent,
        },
      }
    },

    scheduleNameCheck() {
      if (this.isEditing) return
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      const name = this.normalizedName
      const token = ++this.nameCheckToken
      this.nameExists = false
      if (!name) { this.nameChecking = false; return }
      this.nameChecking = true
      this.nameCheckTimer = setTimeout(async () => {
        try {
          const exists = await checkNameExists('channel_points_exists', name)
          if (token === this.nameCheckToken && name === this.normalizedName) this.nameExists = exists
        } catch {
          if (token === this.nameCheckToken) this.nameExists = false
        } finally {
          if (token === this.nameCheckToken) this.nameChecking = false
        }
      }, 300)
    },

    async ensureNameAvailable() {
      if (this.isEditing) return true
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      this.nameChecking = true
      try {
        this.nameExists = await checkNameExists('channel_points_exists', this.normalizedName)
        return !this.nameExists
      } finally { this.nameChecking = false }
    },
    async open() {
      this.initializingInternal = true
      this.errorMessage = ''
      this.assetLoading = false
      this.macroLoading = false

      this.resetForm()
      await this.$nextTick()
      this.initializingInternal = false

      this.assetLoading = true
      this.macroLoading = true
      void this.loadExistingGeneratedFiles()
    },

    async requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      const websocketClient = getWebsocketClient()

      if (!websocketClient) {
        throw new Error('websocket is not connected')
      }

      const response = await websocketClient.request(method, params, timeout)
      return response?.params ?? response
    },

    async requestEndpoint(method: string, endpoint: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      try {
        const response = await this.requestWebsocket(method, params, timeout)
        return response?.data ?? response
      } catch (websocketError) {
        const response = await fetch(`${this.appStore.getRestApi}/api/${endpoint}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(params),
        })

        const data = await response.json().catch(() => ({}))
        const responseData = data?.data ?? data

        if (!response.ok || responseData?.error || data?.error) {
          throw new Error(responseData?.error ?? responseData?.message ?? data?.error ?? `${endpoint} failed`)
        }

        return responseData
      }
    },

    normalizeName(value: any): string {
      return String(value ?? '')
        .trim()
        .replace(/^channel_point_/, '')
        .replace(/\s+/g, '_')
        .replace(/[^a-zA-Z0-9_.-]+/g, '_')
        .replace(/^_+|_+$/g, '')
    },

    resetForm() {
      const point: any = this.channelPoint ?? {}
      const label = String(point.label ?? point.name ?? '').trim()
      const fileName = this.normalizeName(point.name ?? point.file ?? point.asset ?? point.macro ?? label)

      this.originalName = this.isEditing ? fileName : ''
      this.form = {
        name: label || fileName,
        enable_default: point.enable_default === true,
        auto_accept: point.auto_accept === true,
        strip_emotes: point.strip_emotes === true,
        strip_urls: point.strip_urls === true,
        input_required: point.input_required === true,
        bypass_interaction_queue: point.bypass_interaction_queue === true,
        require_follower: point.require_follower === true || point.requiresFollower === true,
        minimum_follow_seconds: Number(point.minimum_follow_seconds ?? point.minimumFollowSeconds ?? 0) || 0,
        require_subscriber: point.require_subscriber === true || point.requiresSubscriber === true,
        minimum_sub_tier: Number(point.minimum_sub_tier ?? point.minimumSubTier ?? 0) || 0,
        minimum_sub_months: Number(point.minimum_sub_months ?? point.minimumSubMonths ?? 0) || 0,
        require_vip: point.require_vip === true || point.requiresVip === true,
        require_moderator: point.require_moderator === true || point.requiresModerator === true || point.requiresMod === true,
      }

      this.macroContent = this.defaultMacroContent(fileName ? `channel_point_${fileName}` : 'channel_point_')
    },

    async loadExistingGeneratedFiles() {
      if (!this.normalizedName) {
        await this.$nextTick()
        ;(this.$refs.assetAccordion as any)?.setAsset?.({ channel: 'general', duration: 5 })
        ;(this.$refs.macroAccordion as any)?.setContent?.(this.defaultMacroContent(this.generatedConfigName), this.generatedConfigName)
        this.assetLoading = false
        this.macroLoading = false
        return
      }

      void this.loadExistingAsset().finally(() => {
        this.assetLoading = false
      })
      void this.loadExistingMacro().finally(() => {
        this.macroLoading = false
      })
    },

    async loadExistingAsset() {
      await this.$nextTick()
      try {
        await (this.$refs.assetAccordion as any)?.open?.(this.generatedConfigName)
      } catch (error) {
        ;(this.$refs.assetAccordion as any)?.setAsset?.({ channel: 'general', duration: 5 })
      }
    },

    async loadExistingMacro() {
      try {
        const data = await this.requestEndpoint('macro_read', 'macro/read', {
          name: this.generatedConfigName,
          path: `${this.generatedConfigName}.yaml`,
          file: `${this.generatedConfigName}.yaml`,
        })

        this.macroContent = String(data?.content ?? this.defaultMacroContent(this.generatedConfigName))
      } catch (error) {
        this.macroContent = this.defaultMacroContent(this.generatedConfigName)
      }

      await this.$nextTick()
      ;(this.$refs.macroAccordion as any)?.setContent?.(this.macroContent, this.generatedConfigName)
    },

    defaultMacroContent(name: string) {
      return `name: ${name}\ntasks: []\n`
    },

    async importChannelPoint(payload: any) {
      const data = payload?.data ?? {}

      if (!data || typeof data !== 'object' || Array.isArray(data)) {
        this.errorMessage = 'Imported YAML must be an object'
        return
      }

      const config =
        data?.config?.content && typeof data.config.content === 'object'
          ? data.config.content
          : data

      const currentLabel = String(this.form.name ?? '').trim()
      const importedLabel = String(config.label ?? config.name ?? '').trim()
      const importedName = this.normalizeName(
        data?.config?.name ?? config.name ?? config.asset ?? config.macro ?? importedLabel,
      )

      this.form = {
        name: currentLabel,
        enable_default: config.enable_default === true,
        auto_accept: config.auto_accept === true,
        strip_emotes: config.strip_emotes === true,
        strip_urls: config.strip_urls === true,
        input_required: config.input_required === true,
        bypass_interaction_queue: config.bypass_interaction_queue === true,
        require_follower: config.require_follower === true || config.requiresFollower === true,
        minimum_follow_seconds: Number(config.minimum_follow_seconds ?? config.minimumFollowSeconds ?? 0) || 0,
        require_subscriber: config.require_subscriber === true || config.requiresSubscriber === true,
        minimum_sub_tier: Number(config.minimum_sub_tier ?? config.minimumSubTier ?? 0) || 0,
        minimum_sub_months: Number(config.minimum_sub_months ?? config.minimumSubMonths ?? 0) || 0,
        require_vip: config.require_vip === true || config.requiresVip === true,
        require_moderator: config.require_moderator === true || config.requiresModerator === true || config.requiresMod === true,
      }

      this.errorMessage = ''

      await this.$nextTick()

      const bundledAsset = data?.asset?.content
      const bundledMacro = data?.macro?.content

      if (bundledAsset && typeof bundledAsset === 'object') {
        ;(this.$refs.assetAccordion as any)?.setAsset?.(bundledAsset)
      } else if (this.normalizedName) {
        await this.loadExistingAsset()
      } else {
        ;(this.$refs.assetAccordion as any)?.setAsset?.({ channel: 'general', duration: 5 })
      }

      if (typeof bundledMacro === 'string' && bundledMacro.trim()) {
        this.macroContent = bundledMacro
        ;(this.$refs.macroAccordion as any)?.setContent?.(bundledMacro, this.generatedConfigName)
      } else if (this.normalizedName) {
        await this.loadExistingMacro()
      } else {
        const fallbackMacro = this.defaultMacroContent(this.generatedConfigName)
        this.macroContent = fallbackMacro
        ;(this.$refs.macroAccordion as any)?.setContent?.(fallbackMacro, this.generatedConfigName)
      }
    },

    handleImportError(error: any) {
      this.errorMessage = error?.message ?? String(error ?? 'Failed to import YAML')
    },

    async save() {
      if (!this.canSave) return
      if (!(await this.ensureNameAvailable())) return

      this.$emit('save', {
        name: this.normalizedName,
        label: String(this.form.name || this.normalizedName).trim(),
        enable_default: this.form.enable_default,
        auto_accept: this.form.auto_accept,
        strip_emotes: this.form.strip_emotes,
        strip_urls: this.form.strip_urls,
        input_required: this.form.input_required,
        bypass_interaction_queue: this.form.bypass_interaction_queue,
        require_follower: this.form.require_follower === true,
        minimum_follow_seconds: Math.max(0, Number(this.form.minimum_follow_seconds ?? 0) || 0),
        require_subscriber: this.form.require_subscriber === true,
        minimum_sub_tier: Math.max(0, Number(this.form.minimum_sub_tier ?? 0) || 0),
        minimum_sub_months: Math.max(0, Number(this.form.minimum_sub_months ?? 0) || 0),
        require_vip: this.form.require_vip === true,
        require_moderator: this.form.require_moderator === true,
        asset: (this.$refs.assetAccordion as any)?.getAssetPayload?.() ?? {},
        macroContent: (this.$refs.macroAccordion as any)?.getContent?.() || this.macroContent || this.defaultMacroContent(this.generatedConfigName),
      })
    },
  },
}
</script>

<style scoped lang="scss">
.channel-point-dialog {
}

.min-width-0 {
  min-width: 0;
}

.channel-point-settings {
  width: 100%;
  max-width: none;
}

.option-card-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}

.option-card {
  min-width: 0;
  height: 100%;
}

@media (min-width: 960px) {
  .option-card-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 1920px) {
  .option-card-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
</style>
