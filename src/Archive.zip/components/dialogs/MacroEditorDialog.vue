<template>
  <v-dialog
    :model-value="modelValue"
    fullscreen
    scrollable
    @update:model-value="$emit('update:modelValue', $event)"
  >
    <v-card color="grey-darken-4" class="macro-editor-dialog">
      <v-toolbar flat density="comfortable">
        <v-toolbar-title class="d-flex align-center min-width-0">
          <v-icon icon="mdi-pencil" class="mr-2" />
          <span class="text-truncate">{{ $t('dialogs.macroEditorDialog.editTitle', { name }) }}</span>
        </v-toolbar-title>

        <v-switch
          v-model="rawMode"
          color="primary"
          density="comfortable"
          hide-details
          inset
          :label="$t('macro.code')"
          class="mr-3"
          @update:model-value="toggleRawMode"
        />

        <YamlImportExportButtons
          class="mr-2"
          :filename="`${name || 'macro'}.yaml`"
          :export-content="rawMode ? content : ''"
          :export-data="rawMode ? null : exportMacroData()"
          :disabled="loadingFile || saving"
          @import="importMacroYaml"
          @error="errorMessage = $event?.message ?? $t('macro.errors.importFailed')"
        />

        <v-btn icon="mdi-refresh" variant="text" :loading="loadingFile" @click="loadMacro" />

        <v-btn
          icon="mdi-close"
          variant="text"
          :disabled="loadingFile || saving"
          @click="$emit('update:modelValue', false)"
        />
      </v-toolbar>

      <v-card-text class="pa-0 macro-editor-dialog__body">
        <v-alert
          v-if="errorMessage"
          type="error"
          color="red-darken-3"
          density="comfortable"
          class="mb-3"
          :text="errorMessage"
        />

        <v-card color="grey-darken-4" variant="flat" class="h-100 d-flex flex-column" rounded="0">
          <v-divider />

          <div v-if="rawMode" class="macro-editor-dialog__code">
            <vue-monaco-editor
              v-model:value="content"
              language="yaml"
              theme="vs-dark"
              height="100%"
              :options="editorOptions"
            />
          </div>

          <div v-else class="macro-editor-dialog__visual pa-3">
            <v-row density="comfortable" class="mb-3">
              <v-col cols="12" md="4">
                <v-text-field
                  v-model="visualMacro.name"
                  :label="$t('macro.name')"
                  density="comfortable"
                  variant="outlined"
                  hide-details="auto"
                  :error-messages="nameChanged && nameExists ? [$t('common.nameAlreadyExists')] : []"
                />
              </v-col>

              <v-col cols="12" md="6">
                <v-text-field
                  v-model="visualMacro.description"
                  :label="$t('macro.description')"
                  :hint="$t('macro.descriptionHint')"
                  persistent-hint
                  density="comfortable"
                  variant="outlined"
                  clearable
                />
              </v-col>

              <v-col cols="12" md="2" class="d-flex align-center">
                <v-switch
                  v-model="visualMacro.hide_from_cloud"
                  color="primary"
                  density="comfortable"
                  hide-details="auto"
                  inset
                  :label="$t('macro.hideFromCloud')"
                  :hint="$t('macro.hideFromCloudHint')"
                  persistent-hint
                />
              </v-col>
            </v-row>

            <MacroTaskList
              :items="visualMacro.items"
              template-context="macro"
              :template-name="visualMacro.name || name"
              :template-macro="visualMacro.name || name"
            />
          </div>
        </v-card>
      </v-card-text>

      <v-divider />

      <v-card-actions>
        <v-spacer />
        <v-btn
          variant="text"
          prepend-icon="mdi-close"
          :disabled="loadingFile || saving"
          @click="$emit('update:modelValue', false)"
        >
          {{ $t('common.cancel') }}
        </v-btn>
        <v-btn
          color="primary"
          variant="tonal"
          prepend-icon="mdi-content-save"
          :loading="saving"
          :disabled="!name || !visualMacro.name || loadingFile || saving || hasVisualErrors || (nameChanged && (nameChecking || nameExists))"
          @click="saveMacro"
        >
          {{ $t('common.save') }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script lang="ts">
import { getWebsocketClient } from '@/plugins/websocketInstance'
import { VueMonacoEditor } from '@guolao/vue-monaco-editor'
import MacroTaskList from '@/components/MacroTaskList.vue'
import YamlImportExportButtons from '@/components/YamlImportExportButtons.vue'
import { checkNameExists } from '@/helper/NameExistsHelper'
import YAML from 'yaml'

type VisualTask = {
  id: string
  type: 'task' | 'condition' | 'loop' | 'switch'
  task: any
  children?: VisualTask[]
  branches?: VisualBranch[]
  cases?: VisualBranch[]
  defaultBranch?: VisualBranch
}

type VisualBranch = {
  id: string
  task: any
  children: VisualTask[]
  inputs?: string[]
}

export default {
  name: 'MacroEditorDialog',

  components: {
    VueMonacoEditor,
    MacroTaskList,
    YamlImportExportButtons,
  },

  props: {
    modelValue: { type: Boolean, default: false },
    name: { type: String, default: '' },
    macro: { type: Object, default: null },
    loading: { type: Boolean, default: false },
    filePath: { type: String, default: '' },
  },

  emits: ['update:modelValue', 'saved'],

  data() {
    return {
      content: '',
      rawMode: false,
      visualMacro: {
        name: '',
        description: '',
        hide_from_cloud: false,
        items: [] as VisualTask[],
      },
      macroDocument: {} as Record<string, any>,
      loadingFile: false,
      saving: false,
      errorMessage: '',
      hasVisualErrors: false,
      nameChecking: false,
      nameExists: false,
      nameCheckTimer: null as ReturnType<typeof setTimeout> | null,
      nameCheckToken: 0,
      editorOptions: {
        automaticLayout: true,
        minimap: { enabled: false },
        tabSize: 2,
        insertSpaces: true,
        wordWrap: 'on',
        scrollBeyondLastLine: false,
      },
    }
  },

  computed: {
    nameChanged(): boolean {
      const current = String(this.visualMacro.name ?? '').trim()
      const original = String(this.name ?? '').trim()
      return Boolean(current) && current !== original
    },
  },

  watch: {
    'visualMacro.name'() {
      this.scheduleNameCheck()
    },
  },

  methods: {
    scheduleNameCheck() {
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      const value = String(this.visualMacro.name ?? '').trim()
      const token = ++this.nameCheckToken
      this.nameExists = false

      if (!value || !this.nameChanged) {
        this.nameChecking = false
        return
      }

      this.nameChecking = true
      this.nameCheckTimer = setTimeout(async () => {
        try {
          const exists = await checkNameExists('macro_exists', value)
          if (token === this.nameCheckToken && value === String(this.visualMacro.name ?? '').trim()) {
            this.nameExists = exists
          }
        } catch {
          if (token === this.nameCheckToken) this.nameExists = false
        } finally {
          if (token === this.nameCheckToken) this.nameChecking = false
        }
      }, 300)
    },

    async ensureNameAvailable() {
      if (!this.nameChanged) return true
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      this.nameChecking = true
      try {
        this.nameExists = await checkNameExists('macro_exists', String(this.visualMacro.name ?? '').trim())
        return !this.nameExists
      } finally {
        this.nameChecking = false
      }
    },

    open() {
      return this.loadMacro()
    },

    async requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 30_000): Promise<any> {
      const client = getWebsocketClient()

      if (!client) {
        throw new Error(this.$t('macro.errors.websocketDisconnected'))
      }

      const response = await client.request(method, params, timeout)
      return response?.params ?? response
    },

    uid() {
      return `${Date.now()}_${Math.random().toString(16).slice(2)}`
    },

    async loadMacro() {
      if (!this.name) return

      this.loadingFile = true
      this.errorMessage = ''

      try {
        const response = await this.requestWebsocket('macro_read', {
          name: this.name,
          path: this.filePath || undefined,
          file: this.filePath || undefined,
        })

        const data = response?.data ?? response
        if (data?.error) throw new Error(data.error)

        this.content = String(data?.content ?? this.macroToYaml(this.name, this.macro))
      } catch (error: any) {
        this.content = this.macroToYaml(this.name, this.macro)
        this.errorMessage = error?.message ?? ''
      } finally {
        this.parseContentToVisual()
        this.loadingFile = false
      }
    },

    toggleRawMode(value: boolean) {
      if (value) {
        this.syncVisualToContent()
        return
      }

      this.parseContentToVisual()
    },

    async saveMacro() {
      if (!this.name || !this.visualMacro.name) return
      if (!(await this.ensureNameAvailable())) return

      this.saving = true
      this.errorMessage = ''

      try {
        if (!this.rawMode) this.syncVisualToContent()

        const response = await this.requestWebsocket('macro_edit', {
          name: this.name,
          path: this.filePath || undefined,
          file: this.filePath || undefined,
          content: this.content,
        })

        const data = response?.data ?? response
        if (data?.error) throw new Error(data.error)

        let metadataName = String(this.visualMacro.name || this.name).trim()
        let metadataDescription = String(this.visualMacro.description ?? '').trim()
        let metadataHideFromCloud = this.visualMacro.hide_from_cloud === true

        if (this.rawMode) {
          const rawMacro = YAML.parse(this.content) ?? {}
          if (rawMacro && typeof rawMacro === 'object' && !Array.isArray(rawMacro)) {
            metadataName = String(rawMacro.name ?? metadataName).trim()
            metadataDescription = String(rawMacro.description ?? '').trim()
            metadataHideFromCloud = rawMacro.hide_from_cloud === true
          }
        }

        const metadataResponse = await this.requestWebsocket('macro_metadata', {
          name: metadataName,
          description: metadataDescription,
          hide_from_cloud: metadataHideFromCloud,
        })
        const metadataData = metadataResponse?.data ?? metadataResponse
        if (metadataData?.error) throw new Error(metadataData.error)

        this.$emit('saved')
      } catch (error: any) {
        this.errorMessage = error?.message ?? this.$t('macro.errors.saveFailed')
      } finally {
        this.saving = false
      }
    },

    parseContentToVisual() {
      try {
        const parsed: any = YAML.parse(this.content) ?? {}
        const normalized = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {}
        this.macroDocument = this.cloneTask(normalized)
        const tasks = Array.isArray(normalized.tasks) ? normalized.tasks : []
        const result = this.parseTaskRange(tasks, 0, [])

        this.visualMacro = {
          name: normalized.name ?? this.name,
          description: String(normalized.description ?? ''),
          hide_from_cloud: normalized.hide_from_cloud === true,
          items: result.items,
        }

        this.hasVisualErrors = false
      } catch (error: any) {
        this.hasVisualErrors = true
        this.errorMessage = error?.message ?? this.$t('macro.errors.parseFailed')
      }
    },

    parseTaskRange(tasks: any[], startIndex: number, stopMethods: string[]) {
      const items: VisualTask[] = []
      let index = startIndex
      let stopMethod = ''

      while (index < tasks.length) {
        const task = this.cloneTask(tasks[index])
        const method =
          task?.channel === 'condition' || task?.channel === 'loop' || task?.channel === 'switch'
            ? task.method
            : ''

        if (stopMethods.includes(method)) {
          stopMethod = method
          break
        }

        if (task?.channel === 'condition' && task.method === 'if') {
          const childResult = this.parseTaskRange(tasks, index + 1, ['else_if', 'else', 'end_if'])
          const branches: VisualBranch[] = []
          index = childResult.index

          while (index < tasks.length && tasks[index]?.channel === 'condition' && ['else_if', 'else'].includes(tasks[index].method)) {
            const branchTask = this.cloneTask(tasks[index])
            const branchResult = this.parseTaskRange(tasks, index + 1, ['else_if', 'else', 'end_if'])

            branches.push({
              id: this.uid(),
              task: branchTask,
              children: branchResult.items,
            })

            index = branchResult.index
          }

          if (tasks[index]?.channel === 'condition' && tasks[index].method === 'end_if') {
            index++
          }

          items.push({
            id: this.uid(),
            type: 'condition',
            task,
            children: childResult.items,
            branches,
          })

          continue
        }

        if (task?.channel === 'loop' && task.method === 'for') {
          const childResult = this.parseTaskRange(tasks, index + 1, ['end_for'])
          index = childResult.index

          if (tasks[index]?.channel === 'loop' && tasks[index].method === 'end_for') {
            index++
          }

          items.push({
            id: this.uid(),
            type: 'loop',
            task,
            children: childResult.items,
          })

          continue
        }

        if (task?.channel === 'switch' && task.method === 'switch') {
          const cases: VisualBranch[] = []
          let defaultBranch: VisualBranch | undefined
          index++

          while (index < tasks.length) {
            const marker = tasks[index]

            if (marker?.channel === 'switch' && marker.method === 'end_switch') {
              index++
              break
            }

            if (marker?.channel === 'switch' && marker.method === 'case') {
              const caseInputs: string[] = []
              let firstCaseTask: any = null
              let caseChildren: VisualTask[] = []

              while (index < tasks.length && tasks[index]?.channel === 'switch' && tasks[index]?.method === 'case') {
                const currentCaseTask = this.cloneTask(tasks[index])
                if (!firstCaseTask) firstCaseTask = currentCaseTask

                caseInputs.push(String(currentCaseTask?.data?.input ?? ''))

                const caseResult = this.parseTaskRange(tasks, index + 1, ['case', 'default', 'end_switch'])
                caseChildren = caseResult.items
                index = caseResult.index

                // A case with tasks owns the shared body. Empty cases fall through
                // visually into the next case and are grouped into one branch.
                if (caseChildren.length > 0) break

                if (!(tasks[index]?.channel === 'switch' && tasks[index]?.method === 'case')) {
                  break
                }
              }

              firstCaseTask.data ??= {}
              firstCaseTask.data.input = caseInputs[0] ?? ''

              cases.push({
                id: this.uid(),
                task: firstCaseTask,
                inputs: caseInputs.length > 0 ? caseInputs : [''],
                children: caseChildren,
              })

              continue
            }

            if (marker?.channel === 'switch' && marker.method === 'default') {
              const defaultTask = this.cloneTask(marker)
              const defaultResult = this.parseTaskRange(tasks, index + 1, ['end_switch'])

              defaultBranch = {
                id: this.uid(),
                task: defaultTask,
                children: defaultResult.items,
              }

              index = defaultResult.index
              continue
            }

            // Invalid loose content inside a switch: preserve it as a case body
            // instead of dropping it from the visual editor.
            const looseResult = this.parseTaskRange(tasks, index, ['case', 'default', 'end_switch'])
            cases.push({
              id: this.uid(),
              task: { channel: 'switch', method: 'case', data: { input: '' } },
              children: looseResult.items,
            })
            index = looseResult.index
          }

          items.push({
            id: this.uid(),
            type: 'switch',
            task,
            cases,
            defaultBranch,
          })

          continue
        }

        items.push({
          id: this.uid(),
          type: 'task',
          task,
        })
        index++
      }

      return { items, index, stopMethod }
    },

    exportMacroData() {
      return {
        ...(this.macroDocument ?? {}),
        name: this.visualMacro.name || this.name,
        description: String(this.visualMacro.description ?? '').trim(),
        hide_from_cloud: this.visualMacro.hide_from_cloud === true,
        tasks: this.flattenVisualTasks(this.visualMacro.items),
      }
    },

    importMacroYaml(payload: any) {
      try {
        const imported = YAML.parse(String(payload?.content ?? '')) ?? {}

        if (!imported || typeof imported !== 'object' || Array.isArray(imported)) {
          throw new Error(this.$t('macro.errors.invalidYaml'))
        }

        const currentName = String(this.visualMacro.name || this.name || '').trim()
        const normalizedImport = {
          ...imported,
          name: currentName || imported.name,
        }

        this.macroDocument = this.cloneTask(normalizedImport)
        this.content = YAML.stringify(normalizedImport, { lineWidth: 0 })
        this.parseContentToVisual()
        this.rawMode = false
      } catch (error: any) {
        this.errorMessage = error?.message ?? this.$t('macro.errors.importFailed')
      }
    },

    syncVisualToContent() {
      const macro = this.exportMacroData()
      this.macroDocument = this.cloneTask(macro)
      this.content = YAML.stringify(macro, { lineWidth: 0 })
    },

    flattenVisualTasks(items: VisualTask[]): any[] {
      const tasks: any[] = []

      for (const item of items) {
        if (item.type === 'condition') {
          tasks.push(this.cloneTask(item.task))
          tasks.push(...this.flattenVisualTasks(item.children ?? []))

          for (const branch of item.branches ?? []) {
            tasks.push(this.cloneTask(branch.task))
            tasks.push(...this.flattenVisualTasks(branch.children ?? []))
          }

          tasks.push({ channel: 'condition', method: 'end_if' })
          continue
        }

        if (
          item.type === 'loop' ||
          (item.task?.channel === 'loop' && item.task?.method === 'for')
        ) {
          tasks.push(this.cloneTask(item.task))
          tasks.push(...this.flattenVisualTasks(item.children ?? []))
          tasks.push({ channel: 'loop', method: 'end_for' })
          continue
        }

        if (
          item.type === 'switch' ||
          (item.task?.channel === 'switch' && item.task?.method === 'switch')
        ) {
          tasks.push(this.cloneTask(item.task))

          for (const caseItem of item.cases ?? []) {
            const inputs = Array.isArray(caseItem.inputs) && caseItem.inputs.length > 0
              ? caseItem.inputs
              : [caseItem.task?.data?.input ?? '']

            for (const input of inputs) {
              const caseTask = this.cloneTask(caseItem.task)
              caseTask.channel = 'switch'
              caseTask.method = 'case'
              caseTask.data ??= {}
              caseTask.data.input = input
              tasks.push(caseTask)
            }

            tasks.push(...this.flattenVisualTasks(caseItem.children ?? []))
          }

          if (item.defaultBranch) {
            tasks.push(this.cloneTask(item.defaultBranch.task))
            tasks.push(...this.flattenVisualTasks(item.defaultBranch.children ?? []))
          }

          tasks.push({ channel: 'switch', method: 'end_switch' })
          continue
        }

        tasks.push(this.cloneTask(item.task))
      }

      return tasks
    },


    yamlLoad(input: string) {
      const lines = String(input ?? '')
        .replace(/\t/g, '  ')
        .split(/\r?\n/)
        .map((raw) => ({
          indent: raw.match(/^ */)?.[0].length ?? 0,
          text: raw.trim(),
        }))
        .filter((line) => line.text && !line.text.startsWith('#'))

      const parseScalar = (value: string): any => {
        const trimmed = value.trim()
        if (trimmed === '') return ''
        if (trimmed === '[]') return []
        if (trimmed === '{}') return {}
        if (trimmed === 'true') return true
        if (trimmed === 'false') return false
        if (trimmed === 'null') return null
        if (/^-?\d+(\.\d+)?$/.test(trimmed)) return Number(trimmed)

        if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
          try {
            return trimmed.startsWith('"') ? JSON.parse(trimmed) : trimmed.slice(1, -1).replace(/''/g, "'")
          } catch (error) {
            return trimmed.slice(1, -1)
          }
        }

        return trimmed
      }

      const setPair = (target: any, pair: string, nextIndex: number, parentIndent: number) => {
        const separatorIndex = pair.indexOf(':')
        if (separatorIndex < 0) return nextIndex

        const key = pair.slice(0, separatorIndex).trim()
        const value = pair.slice(separatorIndex + 1).trim()

        if (value) {
          target[key] = parseScalar(value)
          return nextIndex
        }

        if (nextIndex < lines.length && lines[nextIndex].indent > parentIndent) {
          const child = parseBlock(nextIndex, lines[nextIndex].indent)
          target[key] = child.value
          return child.index
        }

        target[key] = null
        return nextIndex
      }

      const parseObject = (index: number, indent: number): any => {
        const object: Record<string, any> = {}

        while (index < lines.length) {
          const line = lines[index]
          if (line.indent < indent) break
          if (line.indent > indent) {
            index++
            continue
          }
          if (line.text.startsWith('- ')) break

          index = setPair(object, line.text, index + 1, indent)
        }

        return { value: object, index }
      }

      const parseArray = (index: number, indent: number): any => {
        const array: any[] = []

        while (index < lines.length) {
          const line = lines[index]
          if (line.indent < indent) break
          if (line.indent > indent) {
            index++
            continue
          }
          if (!line.text.startsWith('- ')) break

          const rest = line.text.slice(2).trim()
          index++

          if (!rest) {
            if (index < lines.length && lines[index].indent > indent) {
              const child = parseBlock(index, lines[index].indent)
              array.push(child.value)
              index = child.index
            } else {
              array.push(null)
            }
            continue
          }

          if (rest.includes(':') && !rest.startsWith('"') && !rest.startsWith("'")) {
            const object: Record<string, any> = {}
            index = setPair(object, rest, index, indent + 2)

            while (index < lines.length && lines[index].indent > indent) {
              const childLine = lines[index]
              if (childLine.indent < indent + 2) break
              if (childLine.indent > indent + 2) {
                index++
                continue
              }
              if (childLine.text.startsWith('- ')) break
              index = setPair(object, childLine.text, index + 1, childLine.indent)
            }

            array.push(object)
            continue
          }

          array.push(parseScalar(rest))
        }

        return { value: array, index }
      }

      const parseBlock = (index: number, indent: number): any => {
        if (lines[index]?.text.startsWith('- ')) return parseArray(index, indent)
        return parseObject(index, indent)
      }

      if (!lines.length) return {}
      return parseBlock(0, lines[0].indent).value
    },

    yamlDump(value: any): string {
      const quoteString = (value: string) => {
        if (value === '') return '""'
        if (
          /^[a-zA-Z0-9_.\/${}!-]+$/.test(value) &&
          !/^[!&*%@`{}[\],#|>?'"%-]/.test(value) &&
          !['true', 'false', 'null'].includes(value.toLowerCase())
        ) return value
        return JSON.stringify(value)
      }

      const scalar = (value: any) => {
        if (value === null || value === undefined) return 'null'
        if (typeof value === 'number' || typeof value === 'boolean') return String(value)
        return quoteString(String(value))
      }

      const dump = (current: any, indent = 0): string[] => {
        const prefix = ' '.repeat(indent)

        if (Array.isArray(current)) {
          if (current.length === 0) return [`${prefix}[]`]

          return current.flatMap((item) => {
            if (item && typeof item === 'object') {
              const entries = Object.entries(item)
              if (entries.length === 0) return [`${prefix}- {}`]

              const [firstKey, firstValue] = entries[0]
              const lines: string[] = []

              if (firstValue && typeof firstValue === 'object') {
                lines.push(`${prefix}- ${firstKey}:`)
                lines.push(...dump(firstValue, indent + 4))
              } else {
                lines.push(`${prefix}- ${firstKey}: ${scalar(firstValue)}`)
              }

              for (const [key, value] of entries.slice(1)) {
                if (value && typeof value === 'object') {
                  lines.push(`${prefix}  ${key}:`)
                  lines.push(...dump(value, indent + 4))
                } else {
                  lines.push(`${prefix}  ${key}: ${scalar(value)}`)
                }
              }

              return lines
            }

            return [`${prefix}- ${scalar(item)}`]
          })
        }

        if (current && typeof current === 'object') {
          const entries = Object.entries(current)
          if (entries.length === 0) return [`${prefix}{}`]

          return entries.flatMap(([key, item]) => {
            if (item && typeof item === 'object') {
              if (Array.isArray(item) && item.length === 0) return [`${prefix}${key}: []`]
              const child = dump(item, indent + 2)
              return [`${prefix}${key}:`, ...child]
            }

            return [`${prefix}${key}: ${scalar(item)}`]
          })
        }

        return [`${prefix}${scalar(current)}`]
      }

      return `${dump(value).join('\n')}\n`
    },

    cloneTask(task: any) {
      return JSON.parse(JSON.stringify(task ?? {}))
    },

    macroToYaml(name: string, macro: any): string {
      return this.yamlDump({
        name,
        tasks: Array.isArray(macro?.tasks) ? macro.tasks : [],
      })
    },
  },
}
</script>

<style scoped>
.macro-editor-dialog__body {
  height: calc(100vh - 48px);
}

.macro-editor-dialog__code,
.macro-editor-dialog__visual {
  flex: 1 1 auto;
  min-height: 0;
  height: 100%;
}

.macro-editor-dialog__visual {
  overflow: auto;
}
</style>
