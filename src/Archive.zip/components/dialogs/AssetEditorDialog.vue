<script lang="ts">
import { filterVisibleMacroNames } from '@/helper/MacroHelper'
import {useAppStore} from '@/stores/app'
import { checkNameExists } from '@/helper/NameExistsHelper'
import {getWebsocketClient} from '@/plugins/websocketInstance.ts'
import YamlImportExportButtons from '@/components/YamlImportExportButtons.vue'
import MacroWledControlEditor from '@/components/MacroWledControlEditor.vue'
import ColorPickerField from '@/components/inputs/ColorPickerField.vue'

type WledControl = {
  name: string;
  red: number | null;
  green: number | null;
  blue: number | null;
  white: number | null;
  effect: number | null;
  brightness: number | null;
};

type MediaEntry = {
  name: string;
  path: string;
  type: "file" | "folder";
  asset?: string | { original?: string; compressed?: string | null } | null;
  compressed?: string | null;
};

const emptyForm = () => ({
  name: "",
  sound: "",
  icon: "",
  message: "",
  duration: null as number | null,
  color: "",
  channel: "",
  volume: null as number | null,
  image: "",
  video: "",
  start_macros: [] as string[],
  idle_macros: [] as string[],
  end_macros: [] as string[],
  wled: [] as WledControl[],
});

const mdiSuggestions = [
  "alert",
  "bell",
  "bell-ring",
  "bullhorn",
  "cash",
  "cash-multiple",
  "charity",
  "chat",
  "chat-alert",
  "crown",
  "emoticon",
  "emoticon-cool",
  "fire",
  "gift",
  "heart",
  "heart-pulse",
  "information",
  "lightning-bolt",
  "party-popper",
  "pistol",
  "rocket",
  "star",
  "star-four-points",
  "trophy",
  "video",
  "volume-high",
  "led-strip-variant",
  "test-tube",
  "account",
  "account-heart",
  "gamepad-variant",
  "sword",
  "shield",
  "skull",
  "ghost",
  "timer",
  "clock",
  "camera",
  "microphone",
  "dice-6",
  "controller-classic",
  "youtube",
  "twitch",
  "discord",
].sort();

export default {
  name: "AssetEditorDialog",

  components: {
    YamlImportExportButtons,
    MacroWledControlEditor,
    ColorPickerField,
  },

  props: {
    modelValue: {type: Boolean, default: false},
    assetName: {type: String, default: ""},
    asset: {type: Object, default: null},
    loading: {type: Boolean, default: false},
    error: {type: String, default: ""},
    macroItems: {type: Array, default: () => []},
    mediaEntries: {type: Array, default: () => []},
    wledItems: {type: Array, default: () => []},
  },

  emits: ["update:modelValue", "save"],

  data() {
    return {
      appStore: useAppStore(),
      form: emptyForm(),
      localMediaEntries: [] as MediaEntry[],
      wledColorMenus: [] as boolean[],
      mdiSuggestions,
      wledEffectsByLamp: {} as Record<string, Array<{ title: string; value: number }>>,
      pendingWledControlIndex: null as number | null,
      importError: "",
      importedMacroDependencies: {} as Record<string, string>,
      nameChecking: false,
      nameExists: false,
      nameCheckTimer: null as ReturnType<typeof setTimeout> | null,
      nameCheckToken: 0,
    };
  },

  computed: {
    volumePercent: {
      get(): number {
        const volume = Number(this.form.volume ?? 1)
        if (!Number.isFinite(volume)) return 100
        return Math.round(Math.min(1, Math.max(0, volume)) * 100)
      },
      set(value: number | string | null) {
        const percent = Math.min(100, Math.max(0, Number(value) || 0))
        this.form.volume = percent / 100
      },
    },

    volumeIcon(): string {
      const volume = Number(this.volumePercent ?? 0)

      if (!Number.isFinite(volume) || volume <= 0) return "mdi-volume-off"
      if (volume <= 33) return "mdi-volume-low"
      if (volume <= 66) return "mdi-volume-medium"
      return "mdi-volume-high"
    },

    title(): string {
      return this.assetName
        ? `${this.$t("assets.editor")}: ${this.assetName}`
        : this.$t("assets.createFile");
    },

    canSave(): boolean {
      return this.form.name.trim().length > 0 && !this.loading && (Boolean(this.assetName) || (!this.nameChecking && !this.nameExists));
    },

    alertChannelOptions(): string[] {
      const dynamicData =
        this.appStore?.getDynamicData ??
        this.appStore?.dynamicData ??
        {}

      const channels = Array.isArray(dynamicData?.alert_channels)
        ? dynamicData.alert_channels
        : []

      const options = [...new Set(
        channels
          .map((value: any) => String(value).trim())
          .filter(Boolean),
      )].sort((a, b) => a.localeCompare(b))

      return options
    },

    macroOptions(): string[] {
      return filterVisibleMacroNames(
        (this.macroItems as any[]).map((item: any) => (typeof item === "string" ? item : item?.name)),
      ).sort((a: string, b: string) => a.localeCompare(b));
    },

    wledOptions(): string[] {
      return this.getWledConfigEntries()
        .map((item: any) => item.name)
        .filter(Boolean)
        .map(String)
        .sort((a: string, b: string) => a.localeCompare(b));
    },

    iconOptions(): string[] {
      const current = this.normalizeIconName(this.form.icon);
      const options = [...this.mdiSuggestions];
      if (current && !options.includes(current)) options.unshift(current);
      return options;
    },

    soundOptions(): string[] {
      return this.mediaOptions(/\.(mp3|flac|wav|ogg|m4a|opus)$/i, false);
    },

    imageOptions(): string[] {
      return this.mediaOptions(/\.(webp|jpe?g|png|gif|svg)$/i, true);
    },

    videoOptions(): string[] {
      return this.mediaOptions(/\.(webm|mp4|mov|mkv)$/i, true);
    },
  },

  watch: {
    'form.name'() {
      if (!this.assetName) this.scheduleNameCheck()
    },
  },

  methods: {
    scheduleNameCheck() {
      if (this.assetName) return
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      const value = String(this.form.name ?? '').trim()
      const token = ++this.nameCheckToken
      this.nameExists = false
      if (!value) { this.nameChecking = false; return }
      this.nameChecking = true
      this.nameCheckTimer = setTimeout(async () => {
        try {
          const exists = await checkNameExists('assets_exists', value)
          if (token === this.nameCheckToken && value === String(this.form.name ?? '').trim()) this.nameExists = exists
        } catch {
          if (token === this.nameCheckToken) this.nameExists = false
        } finally { if (token === this.nameCheckToken) this.nameChecking = false }
      }, 300)
    },

    async ensureNameAvailable() {
      if (this.assetName) return true
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)
      this.nameChecking = true
      try {
        this.nameExists = await checkNameExists('assets_exists', String(this.form.name ?? '').trim())
        return !this.nameExists
      } finally { this.nameChecking = false }
    },

    requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 15_000): Promise<any> {
      const client = getWebsocketClient();

      if (!client) {
        return Promise.reject(new Error("websocket is not connected"));
      }

      return client.request(method, params, timeout);
    },

    unwrapWebsocketResponse(response: any, method: string): any {
      const resultKey = `result_${method}`;
      const params = response?.params ?? response;

      const candidates = [
        params?.[resultKey],
        params?.data?.[resultKey],
        params?.payload?.[resultKey],
        params?.result?.[resultKey],
        response?.[resultKey],
        response?.data?.[resultKey],
        response?.payload?.[resultKey],
        response?.result?.[resultKey],
        params?.data,
        params?.payload,
        params?.result,
        params,
        response?.data,
        response?.payload,
        response?.result,
        response,
      ];

      for (const candidate of candidates) {
        if (candidate !== undefined && candidate !== null) return candidate;
      }

      return {};
    },

    async requestEndpoint(
      method: string,
      params: Record<string, any> = {},
      timeout = 15_000,
    ): Promise<any> {
      const response = await this.requestWebsocket(method, params, timeout);
      const data = this.unwrapWebsocketResponse(response, method);

      if (data?.error) {
        throw new Error(data.error);
      }

      return data;
    },

    async ensureMediaEntries() {
      if ((this.mediaEntries as MediaEntry[]).length || this.localMediaEntries.length) {
        return;
      }

      await this.fetchMediaEntries();
    },

    normalizeMediaEntry(entry: any, fallbackPath = ""): MediaEntry | null {
      if (!entry) return null;

      if (typeof entry === "string") {
        const path = this.normalizePath(entry);
        return path
          ? {
            name: path.split("/").pop() ?? path,
            path,
            type: "file",
          }
          : null;
      }

      const rawPath =
        entry.path ??
        entry.file ??
        entry.filename ??
        entry.name ??
        fallbackPath;

      const path = this.normalizePath(rawPath);
      if (!path) return null;

      return {
        ...entry,
        name: String(entry.name ?? path.split("/").pop() ?? path),
        path,
        type:
          entry.type === "folder" ||
          entry.isDirectory ||
          entry.directory
            ? "folder"
            : "file",
      };
    },

    extractMediaEntries(value: any, basePath = ""): MediaEntry[] {
      const result: MediaEntry[] = [];

      const add = (entry: any, fallbackPath = "") => {
        const normalized = this.normalizeMediaEntry(entry, fallbackPath);
        if (normalized) result.push(normalized);
      };

      if (Array.isArray(value)) {
        for (const item of value) add(item);
        return result;
      }

      if (!value || typeof value !== "object") return result;

      for (const key of ["files", "items", "entries", "children"]) {
        if (Array.isArray(value[key])) {
          for (const item of value[key]) add(item);
        }
      }

      for (const [key, item] of Object.entries(value)) {
        if (
          ["files", "items", "entries", "children", "assets", "wled", "wleds"].includes(key)
        ) {
          continue;
        }

        const fallbackPath = basePath ? `${basePath}/${key}` : key;

        if (typeof item === "string") {
          add(item);
          continue;
        }

        if (!item || typeof item !== "object") continue;

        const mediaItem = item as any;

        if (
          mediaItem.type ||
          mediaItem.path ||
          mediaItem.file ||
          mediaItem.filename ||
          mediaItem.name ||
          mediaItem.asset ||
          mediaItem.original ||
          mediaItem.compressed
        ) {
          add(
            {
              ...mediaItem,
              path:
                mediaItem.path ??
                mediaItem.file ??
                mediaItem.filename ??
                fallbackPath,
            },
            fallbackPath,
          );
        }

        if (mediaItem.asset) {
          if (typeof mediaItem.asset === "string") {
            add(mediaItem.asset);
          } else if (typeof mediaItem.asset === "object") {
            add(mediaItem.asset.original);
            add(mediaItem.asset.compressed);
          }
        }

        add(mediaItem.original);
        add(mediaItem.compressed);
      }

      return result;
    },

    uniqueMediaEntries(entries: MediaEntry[]): MediaEntry[] {
      const unique = new Map<string, MediaEntry>();

      for (const entry of entries) {
        const normalized = this.normalizeMediaEntry(entry);
        if (!normalized?.path) continue;
        if (!unique.has(normalized.path)) {
          unique.set(normalized.path, normalized);
        }
      }

      return [...unique.values()];
    },

    async fetchMediaEntries(path = ""): Promise<MediaEntry[]> {
      try {
        const data = await this.requestEndpoint(
          "media_list",
          { path },
          15_000,
        );

        const files =
          data?.files ??
          data?.items ??
          data?.entries ??
          data?.children ??
          data ??
          [];

        const result: MediaEntry[] = [];

        for (const rawEntry of this.extractMediaEntries(files)) {
          result.push(rawEntry);

          if (rawEntry.type === "folder" && rawEntry.path) {
            result.push(...await this.fetchMediaEntries(rawEntry.path));
          }
        }

        const unique = this.uniqueMediaEntries(result);

        if (!path) {
          this.localMediaEntries = unique.filter(
            (entry) => entry.type === "file",
          );
        }

        return unique;
      } catch {
        if (!path) {
          await this.fetchMediaEntriesFromAssetsList();
        }

        return [];
      }
    },

    async fetchMediaEntriesFromAssetsList() {
      try {
        const data = await this.requestEndpoint("assets_list");
        const entries = this.extractMediaEntries(data?.assets ?? data ?? {});

        this.localMediaEntries = this.uniqueMediaEntries(entries).filter(
          (entry) => entry.type === "file",
        );
      } catch {
        this.localMediaEntries = [];
      }
    },

    async open() {
      this.resetForm();
      await Promise.all([
        this.initializeWledData("open"),
        this.ensureMediaEntries(),
      ]);
    },

    async initializeWledData(reason = "unknown") {
      const appStore = useAppStore();

      try {
        await appStore.fetchConfig();
      } catch (error) {
      }

      await this.loadWledEffectsForAllLamps(`initialize: ${reason}`);
    },

    stripWledPrefix(value: any): string {
      const stripped = String(value ?? "")
        .trim()
        .replace(/^wled[\s_-]*/i, "")
        .replace(/^wled(?=[A-Z0-9])/i, "")
        .trim();

      return stripped || String(value ?? "").trim();
    },

    getWledConfigEntries(): Array<Record<string, any>> {
      const integrations = this.appStore?.getIntegrations ?? useAppStore().getIntegrations ?? {}
      const wled = integrations?.wled ?? {}

      return Object.entries(wled).map(([name, value]: [string, any]) => ({
        name: this.stripWledPrefix(name),
        ip: value?.ip ?? value,
      }))
    },

    getWledBaseUrl(lamp: any): string {
      const ip = String(lamp?.ip ?? '').trim()
      if (!ip) return ''

      return (/^https?:\/\//i.test(ip) ? ip : `http://${ip}`).replace(/\/+$/, '')
    },

    getWledLampEntry(name: any): Record<string, any> | undefined {
      const normalizedName = this.stripWledPrefix(name).toLowerCase();
      return this.getWledConfigEntries().find(
        (entry: any) => String(entry.name).toLowerCase() === normalizedName,
      );
    },

    getWledEffectCacheKey(name: any): string {
      return this.stripWledPrefix(name).toLowerCase();
    },

    wledEffectOptions(name: any): Array<{ title: string; value: number }> {
      const key = this.getWledEffectCacheKey(name);
      return key ? this.wledEffectsByLamp[key] ?? [] : [];
    },

    async loadWledEffectsForAllLamps(reason = "unknown") {
      const entries = this.getWledConfigEntries();

      await Promise.all(entries.map((entry: any) => this.loadWledEffects(entry.name, reason)));
    },

    async loadWledEffects(name: any, reason = "unknown") {
      const lamp = this.getWledLampEntry(name);
      const baseUrl = this.getWledBaseUrl(lamp);
      const cacheKey = this.getWledEffectCacheKey(name);
      const url = baseUrl ? `${baseUrl}/json/eff` : "";

      if (!cacheKey || !url) {
        return;
      }

      try {
        const response = await fetch(url, { cache: "no-store" });

        const effects = await response.json();
        const mappedEffects = Array.isArray(effects)
          ? effects.map((effect: any, index: number) => ({
            title: `${index} - ${String(effect)}`,
            value: index,
          }))
          : [];

        this.wledEffectsByLamp = {
          ...this.wledEffectsByLamp,
          [cacheKey]: mappedEffects,
        };

      } catch (error) {
        this.wledEffectsByLamp = {
          ...this.wledEffectsByLamp,
          [cacheKey]: [],
        };
      }
    },

    setAsset(asset: any = {}) {
      const form = emptyForm();

      form.name = String(this.form.name || this.assetName || asset?.name || "").trim();
      form.sound = String(asset?.sound ?? "");
      form.icon = this.normalizeIconName(asset?.icon ?? "");
      form.message = String(asset?.message ?? "");
      form.duration = this.toNullableNumber(asset?.duration);
      form.color = String(asset?.color ?? "")
        .replace(/^#/, "")
        .toUpperCase();
      form.channel = String(asset?.channel ?? "");
      form.volume = this.toNormalizedVolume(asset?.volume);
      form.image = String(asset?.image ?? "");
      form.video = String(asset?.video ?? "");
      form.start_macros = this.toStringArray(asset?.start_macros);
      form.idle_macros = this.toStringArray(asset?.idle_macros);
      form.end_macros = this.toStringArray(asset?.end_macros);
      form.wled = this.toWledControls(asset?.wled);

      this.form = form;
      this.wledColorMenus = form.wled.map(() => false);
    },

    async readMacroContent(name: string): Promise<string> {
      const cleanName = String(name ?? "").trim();
      if (!cleanName) return "";

      try {
        const response = await this.requestWebsocket("macro_read", {
          name: cleanName,
          path: `${cleanName}.yaml`,
          file: `${cleanName}.yaml`,
        });
        const data = this.unwrapWebsocketResponse(response, "macro_read");
        return String(data?.content ?? "");
      } catch {
        return "";
      }
    },

    async buildAssetExportBundle() {
      const asset = this.buildAssetPayload();
      const macroNames = [
        ...this.toStringArray(asset.start_macros),
        ...this.toStringArray(asset.idle_macros),
        ...this.toStringArray(asset.end_macros),
      ].filter((name, index, all) => name && all.indexOf(name) === index);

      const macros: Record<string, string> = {};

      await Promise.all(macroNames.map(async (name) => {
        const content = await this.readMacroContent(name);
        if (content) macros[name] = content;
      }));

      return {
        streambot_export: {
          version: 1,
          kind: "asset",
        },
        config: {
          name: this.form.name || this.assetName || "",
          content: asset,
        },
        macros,
      };
    },

    async saveImportedMacroDependencies() {
      for (const [name, content] of Object.entries(this.importedMacroDependencies ?? {})) {
        if (!name || !content) continue;

        const response = await this.requestWebsocket("macro_edit", {
          name,
          path: `${name}.yaml`,
          file: `${name}.yaml`,
          content,
        });
        const data = this.unwrapWebsocketResponse(response, "macro_edit");
        if (data?.error) throw new Error(data.error);
      }

      this.importedMacroDependencies = {};
    },

    importAssetYaml(payload: any) {
      const parsed = payload?.data ?? {};
      const asset =
        parsed?.config?.content ??
        parsed?.content ??
        parsed?.asset ??
        parsed;

      this.importedMacroDependencies =
        parsed?.macros && typeof parsed.macros === "object" && !Array.isArray(parsed.macros)
          ? { ...parsed.macros }
          : {};

      if (!asset || typeof asset !== "object" || Array.isArray(asset)) {
        this.importError = "invalid asset yaml";
        return;
      }

      const currentName = String(this.form.name || this.assetName || "").trim();

      this.importError = "";
      this.setAsset({
        ...asset,
        name: currentName,
      });
    },

    resetForm() {
      const asset: any = this.asset ?? {};
      const form = emptyForm();

      form.name = String(this.assetName || asset?.name || "").trim();
      form.sound = String(asset?.sound ?? "");
      form.icon = this.normalizeIconName(asset?.icon ?? "");
      form.message = String(asset?.message ?? "");
      form.duration = this.toNullableNumber(asset?.duration);
      form.color = String(asset?.color ?? "")
        .replace(/^#/, "")
        .toUpperCase();
      form.channel = String(asset?.channel ?? "");
      form.volume = this.toNormalizedVolume(asset?.volume);
      form.image = String(asset?.image ?? "");
      form.video = String(asset?.video ?? "");
      form.start_macros = this.toStringArray(asset?.start_macros);
      form.idle_macros = this.toStringArray(asset?.idle_macros);
      form.end_macros = this.toStringArray(asset?.end_macros);
      form.wled = this.toWledControls(asset?.wled);

      this.form = form;
      this.wledColorMenus = form.wled.map(() => false);
    },

    toNormalizedVolume(value: any): number | null {
      const normalized = this.toNullableNumber(value);
      if (normalized === null) return null;
      return Math.min(1, Math.max(0, normalized));
    },

    normalizeIconName(value: any): string {
      const rawValue =
        typeof value === "object" && value !== null
          ? (value.raw ?? value.title ?? value.value ?? "")
          : value;

      return String(rawValue ?? "")
        .trim()
        .replace(/^mdi:/, "")
        .replace(/^mdi-/, "");
    },

    iconValue(value: string): string {
      const normalized = this.normalizeIconName(value);
      return normalized ? `mdi-${normalized}` : "mdi-palette";
    },

    getEntryOriginal(entry: MediaEntry): string {
      if (typeof entry.asset === "object" && entry.asset?.original)
        return this.normalizePath(entry.asset.original);
      if (typeof entry.asset === "string")
        return this.normalizePath(entry.asset);
      return this.normalizePath(entry.path);
    },

    getEntryCompressed(entry: MediaEntry): string {
      if (typeof entry.compressed === "string")
        return this.normalizePath(entry.compressed);
      if (
        typeof entry.asset === "object" &&
        typeof entry.asset?.compressed === "string"
      )
        return this.normalizePath(entry.asset.compressed);
      return "";
    },

    mediaOptions(regex: RegExp, compressedFirst: boolean): string[] {
      const values: string[] = [];
      const add = (value: string) => {
        const normalized = this.normalizePath(value);
        if (!normalized || !regex.test(normalized)) return;
        regex.lastIndex = 0;
        if (!values.includes(normalized)) values.push(normalized);
      };

      const entries = (this.mediaEntries as MediaEntry[]).length
        ? (this.mediaEntries as MediaEntry[])
        : this.localMediaEntries;

      for (const entry of entries) {
        if (!entry || entry.type !== "file") continue;
        const original = this.getEntryOriginal(entry);
        const compressed = this.getEntryCompressed(entry);

        if (compressedFirst) {
          add(compressed);
          add(original);
        } else {
          add(original);
          add(compressed);
        }
      }

      return values;
    },

    normalizePath(value: any): string {
      return String(value ?? "")
        .replace(/\\/g, "/")
        .replace(/^\/+/, "")
        .trim();
    },

    toNullableNumber(value: any): number | null {
      if (value === undefined || value === null || value === "") return null;
      const numberValue = Number(value);
      return Number.isFinite(numberValue) ? numberValue : null;
    },

    toStringArray(value: any): string[] {
      if (!value) return [];
      if (Array.isArray(value))
        return value.map((item) => String(item)).filter(Boolean);
      return String(value)
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
    },

    toWledControls(value: any): WledControl[] {
      if (!value || typeof value !== "object") return [];

      return Object.entries(value).map(([name, control]: [string, any]) => ({
        name: this.stripWledPrefix(name),
        red: this.toNullableNumber(control?.red),
        green: this.toNullableNumber(control?.green),
        blue: this.toNullableNumber(control?.blue),
        white: this.toNullableNumber(control?.white),
        effect: this.toNullableNumber(control?.effect),
        brightness: this.toNullableNumber(control?.brightness),
      }));
    },

    openCreateWledDialog(index: number | null = null) {
      this.pendingWledControlIndex = index
      this.$refs.wledIntegrationDialog?.open(index !== null ? this.form.wled?.[index]?.name ?? '' : '')
    },

    handleWledCreated(name: string) {
      if (this.pendingWledControlIndex !== null && this.form.wled?.[this.pendingWledControlIndex]) {
        this.form.wled[this.pendingWledControlIndex].name = name
        void this.loadWledEffects(name)
      }

      this.pendingWledControlIndex = null
    },

    addWledControl() {
      this.form.wled.push({
        name: "",
        red: null,
        green: null,
        blue: null,
        white: null,
        effect: null,
      });
      this.wledColorMenus.push(false);
    },

    removeWledControl(index: number) {
      this.form.wled.splice(index, 1);
      this.wledColorMenus.splice(index, 1);
    },

    cleanString(value: any): string | undefined {
      const normalized = String(value ?? "").trim();
      return normalized ? normalized : undefined;
    },

    cleanNumber(value: any): number | undefined {
      if (value === undefined || value === null || value === "")
        return undefined;
      const numberValue = Number(value);
      return Number.isFinite(numberValue) ? numberValue : undefined;
    },

    cleanByte(value: any): number | undefined {
      const numberValue = this.cleanNumber(value);
      if (numberValue === undefined) return undefined;
      return Math.min(255, Math.max(0, Math.round(numberValue)));
    },

    byteToHex(value: any): string {
      const numberValue = this.cleanByte(value) ?? 0;
      return numberValue.toString(16).padStart(2, "0").toUpperCase();
    },

    getWledRgbHex(control: WledControl): string {
      return `#${this.byteToHex(control.red)}${this.byteToHex(control.green)}${this.byteToHex(control.blue)}`;
    },

    setWledRgbHex(control: WledControl, value: any) {
      const rawColor = value && typeof value === "object"
        ? (value.hex ?? value.hexa ?? value.hex8 ?? value.value ?? value.raw?.hex ?? "")
        : value;

      const hex = String(rawColor ?? "")
        .replace(/^#/, "")
        .trim();

      const normalizedHex = hex.length === 8 ? hex.slice(0, 6) : hex;

      if (!/^[0-9a-f]{6}$/i.test(normalizedHex)) return;

      control.red = parseInt(normalizedHex.slice(0, 2), 16);
      control.green = parseInt(normalizedHex.slice(2, 4), 16);
      control.blue = parseInt(normalizedHex.slice(4, 6), 16);
    },

    setWledEffect(control: WledControl, value: any) {
      const rawValue = value && typeof value === "object"
        ? (value.value ?? value.raw?.value ?? value.raw ?? value.title)
        : value;
      control.effect = this.toNullableNumber(rawValue);
    },

    buildAssetPayload() {
      const asset: Record<string, any> = {};

      for (const key of [
        "sound",
        "icon",
        "message",
        "color",
        "channel",
        "image",
        "video",
      ]) {
        let value = this.cleanString((this.form as any)[key]);
        if (key === "icon" && value) value = this.normalizeIconName(value);
        if (key === "color" && value)
          value = value.replace(/^#/, "").toUpperCase();
        if (value !== undefined) asset[key] = value;
      }

      const duration = this.cleanNumber(this.form.duration);
      if (duration !== undefined) asset.duration = duration;

      const volume = this.cleanNumber(this.form.volume);
      if (volume !== undefined) asset.volume = Math.min(1, Math.max(0, volume));

      for (const key of ["start_macros", "idle_macros", "end_macros"]) {
        const values = this.toStringArray((this.form as any)[key]);
        if (values.length) asset[key] = values;
      }

      const wled: Record<string, any> = {};
      for (const control of this.form.wled) {
        const name = this.cleanString(control.name);
        if (!name) continue;
        const normalizedName = this.stripWledPrefix(name);

        const data: Record<string, any> = {};
        for (const key of ["red", "green", "blue", "white", "brightness", "effect"]) {
          const value = this.cleanByte((control as any)[key]);
          if (value !== undefined) data[key] = value;
        }

        if (Object.keys(data).length) wled[normalizedName] = data;
      }

      if (Object.keys(wled).length) asset.wled = wled;

      return asset;
    },

    async submit() {
      if (!this.canSave) return;
      if (!(await this.ensureNameAvailable())) return;
      const name = this.form.name.trim();

      try {
        await this.saveImportedMacroDependencies();

        this.$emit("save", {
          name,
          path: `${
            name
              .replace(/[\\/]+/g, "_")
              .replace(/[^a-zA-Z0-9_.-]+/g, "_")
              .replace(/^\.+/, "") || "asset"
          }.yaml`,
          asset: this.buildAssetPayload(),
        });
      } catch (error: any) {
        this.importError = error?.message ?? String(error ?? "failed to restore related macros");
      }
    },
  },
};
</script>

<template>
  <v-dialog
    :model-value="modelValue"
    max-width="1100"
    @update:model-value="$emit('update:modelValue', $event)"
  >
    <v-card color="grey-darken-4">
      <v-toolbar density="comfortable" flat>
        <v-toolbar-title class="d-flex align-center">{{
            title
          }}
        </v-toolbar-title>

        <YamlImportExportButtons
          class="mr-2"
          :filename="`${form.name || assetName || 'asset'}.yaml`"
          :export-resolver="buildAssetExportBundle"
          :disabled="loading"
          @import="importAssetYaml"
          @error="importError = $event?.message ?? $t('assets.importFailed')"
        />
        <v-btn
          icon="mdi-close"
          variant="text"
          @click="$emit('update:modelValue', false)"
        />
      </v-toolbar>

      <v-card-text>
        <v-alert
          v-if="error || importError"
          type="error"
          color="red-darken-3"
          density="comfortable"
          class="mb-3"
          :text="importError || error"
        />

        <v-form @submit.prevent="submit">
          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.general') }}</div>
            <v-row density="comfortable">
              <v-col cols="12" md="6">
                <v-text-field
                  v-model="form.name"
                  :disabled="Boolean(assetName) || loading"
                  :label="$t('assets.name')"
                  :error-messages="!assetName && nameExists ? [$t('common.nameAlreadyExists')] : []"
                  hide-details="auto"
                  prepend-inner-icon="mdi-palette"
                  variant="outlined"
                />
              </v-col>
              <v-col cols="12" md="6">
                <v-combobox
                  v-model="form.channel"
                  :disabled="loading"
                  :items="alertChannelOptions"
                  :label="$t('assets.channel')"
                  clearable
                  hide-details="auto"
                  prepend-inner-icon="mdi-broadcast"
                  variant="outlined"
                  auto-select-first
                  eager
                />
              </v-col>
            </v-row>
          </div>

          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.message') }}</div>
            <v-row density="comfortable">
              <v-col cols="12">
                <v-text-field
                  v-model="form.message"
                  :disabled="loading"
                  :label="$t('assets.message')"
                  hide-details="auto"
                  prepend-inner-icon="mdi-message-text"
                  variant="outlined"
                />
              </v-col>
            </v-row>
          </div>

          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.media') }}</div>
            <v-row density="comfortable">
              <v-col cols="12" md="4">
                <v-autocomplete
                  v-model="form.sound"
                  :disabled="loading"
                  :items="soundOptions"
                  :label="$t('assets.sound')"
                  clearable
                  hide-details="auto"
                  prepend-inner-icon="mdi-volume-high"
                  variant="outlined"
                  @focus="ensureMediaEntries"
                  @click="ensureMediaEntries"
                />
              </v-col>
              <v-col cols="12" md="4">
                <v-autocomplete
                  v-model="form.image"
                  :disabled="loading"
                  :items="imageOptions"
                  :label="$t('assets.image')"
                  clearable
                  hide-details="auto"
                  prepend-inner-icon="mdi-image"
                  variant="outlined"
                  @focus="ensureMediaEntries"
                  @click="ensureMediaEntries"
                />
              </v-col>
              <v-col cols="12" md="4">
                <v-autocomplete
                  v-model="form.video"
                  :disabled="loading"
                  :items="videoOptions"
                  :label="$t('assets.video')"
                  clearable
                  hide-details="auto"
                  prepend-inner-icon="mdi-video"
                  variant="outlined"
                  @focus="ensureMediaEntries"
                  @click="ensureMediaEntries"
                />
              </v-col>
            </v-row>
          </div>

          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.timing') }}</div>
            <v-row density="comfortable">
              <v-col cols="12" md="6">
                <v-number-input
                  v-model="form.duration"
                  :disabled="loading"
                  :label="$t('assets.duration')"
                  :step="0.1"
                  hide-details="auto"
                  prepend-inner-icon="mdi-timer"
                  suffix="s"
                  variant="outlined"
                  :precision="2"
                />
              </v-col>
              <v-col cols="12" md="6">
                <v-number-input
                  v-model="volumePercent"
                  :disabled="loading"
                  :label="$t('assets.volume')"
                  :max="100"
                  :min="0"
                  :step="1"
                  hide-details="auto"
                  :prepend-inner-icon="volumeIcon"
                  suffix="%"
                  variant="outlined"
                  :precision="0"
                />
              </v-col>
            </v-row>
          </div>

          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.theme') }}</div>
            <v-row density="comfortable">
              <v-col cols="12" md="6">
                <ColorPickerField
                  v-model="form.color"
                  :disabled="loading"
                  :label="$t('assets.color')"
                  omit-hash
                />
              </v-col>
              <v-col cols="12" md="6">
                <v-combobox
                  v-model="form.icon"
                  :disabled="loading"
                  :items="iconOptions"
                  :label="$t('assets.icon')"
                  clearable
                  hide-details="auto"
                  prepend-inner-icon="mdi-emoticon"
                  variant="outlined"
                  @update:model-value="form.icon = normalizeIconName($event)"
                >
                  <template #item="{ props, item }">
                    <v-list-item v-bind="props">
                      <template #prepend>
                        <v-icon :icon="iconValue(item?.raw ?? item?.title ?? item?.value)" />
                      </template>
                      <v-list-item-title>{{ normalizeIconName(item?.raw ?? item?.title ?? item?.value) }}</v-list-item-title>
                    </v-list-item>
                  </template>
                  <template #chip="{ props }">
                    <v-chip :prepend-icon="iconValue(form.icon)" v-bind="props" />
                  </template>
                </v-combobox>
              </v-col>
            </v-row>
          </div>

          <div class="asset-form-section">
            <div class="asset-form-section__label">{{ $t('assets.macros') }}</div>
            <v-row density="comfortable">
              <v-col cols="12" md="4">
                <v-combobox v-model="form.start_macros" :disabled="loading" :items="macroOptions" :label="$t('assets.startMacros')" chips closable-chips hide-details="auto" multiple variant="outlined" />
              </v-col>
              <v-col cols="12" md="4">
                <v-combobox v-model="form.idle_macros" :disabled="loading" :items="macroOptions" :label="$t('assets.idleMacros')" chips closable-chips hide-details="auto" multiple variant="outlined" />
              </v-col>
              <v-col cols="12" md="4">
                <v-combobox v-model="form.end_macros" :disabled="loading" :items="macroOptions" :label="$t('assets.endMacros')" chips closable-chips hide-details="auto" multiple variant="outlined" />
              </v-col>
            </v-row>
          </div>

          <v-divider class="my-4"/>

          <div class="d-flex align-center justify-space-between mb-3">
            <div class="text-subtitle-2">{{ $t("assets.wled") }}</div>
            <v-btn
              :disabled="loading"
              prepend-icon="mdi-plus"
              size="small"
              variant="tonal"
              @click="addWledControl"
            >
              {{ $t("assets.addWled") }}
            </v-btn>
          </div>

          <MacroWledControlEditor
            v-for="(control, index) in form.wled"
            :key="index"
            v-model="form.wled[index]"
            class="mb-3"
            :disabled="loading"
            @remove="removeWledControl(index)"
          />
        </v-form>
      </v-card-text>

      <v-card-actions>
        <v-spacer/>
        <v-btn
          :disabled="loading"
          variant="text"
          @click="$emit('update:modelValue', false)"
        >{{ $t("common.cancel")}}
        </v-btn>
        <v-btn
          :disabled="!canSave"
          :loading="loading"
          color="primary"
          variant="flat"
          @click="submit"
        >{{ $t("common.save")}}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<style lang="scss" scoped>

.min-width-0 {
  min-width: 0;
}

.asset-form-section {
  margin-bottom: 20px;
}

.asset-form-section__label {
  margin-bottom: 8px;
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  opacity: 0.72;
}
</style>
