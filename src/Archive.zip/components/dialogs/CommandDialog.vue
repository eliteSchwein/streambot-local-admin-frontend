<template>
  <v-dialog :model-value="modelValue" fullscreen scrollable @update:model-value="$emit('update:modelValue', $event)">
    <v-card class="command-dialog">
      <v-toolbar flat density="comfortable">
        <v-toolbar-title class="d-flex align-center min-width-0">
          <v-icon icon="mdi-console-line" class="mr-2" />
          <span class="text-truncate">{{ title }}</span>
        </v-toolbar-title>

        <YamlImportExportButtons
          class="mr-2"
          :filename="exportFilename"
          :disabled="loading"
          :export-data="exportPayload"
          @import="importCommand"
          @error="handleImportError"
        />

        <v-btn icon="mdi-close" variant="text" @click="$emit('update:modelValue', false)" />
      </v-toolbar>

      <v-card-text class="px-0 py-3">
        <v-alert v-if="errorMessage" type="error" color="red-darken-3" class="mb-3 mx-3" :text="errorMessage" />

        <v-expansion-panels v-model="openPanels" variant="accordion">
          <v-expansion-panel value="options">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-tune" />
                <span class="text-truncate">{{ $t('dialogs.commandCreateDialog.options') }}</span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <div class="option-card-grid px-3 mb-4">
                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.commandCreateDialog.general') }}</div>
                  <v-row density="comfortable">
                    <v-col cols="12">
                      <v-text-field v-model="form.name" :label="$t('dialogs.commandCreateDialog.command')" prefix="!" variant="outlined" density="comfortable" hide-details="auto" :error-messages="nameExists ? [$t('common.commandNameAlreadyExists', { command: nameExistsCommand ? `!${nameExistsCommand}` : `!${normalizedName}` })] : []" />
                    </v-col>
                    <v-col cols="12">
                      <v-combobox
                        v-model="form.aliases"
                        :label="$t('dialogs.commandCreateDialog.aliases')"
                        variant="outlined"
                        density="comfortable"
                        multiple
                        chips
                        closable-chips
                        hide-details="auto"
                        :error-messages="aliasExistsNames.length ? aliasExistsNames.map(alias => $t('common.commandAliasAlreadyExists', { alias: `!${alias}`, command: aliasExistsCommands[alias] ? `!${aliasExistsCommands[alias]}` : `!${normalizedName}` })) : []"
                      />
                    </v-col>
                  </v-row>
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.commandCreateDialog.cooldowns') }}</div>
                  <v-row density="comfortable">
                    <v-col cols="12" sm="6"><v-text-field v-model.number="form.userCooldown" :label="$t('dialogs.commandCreateDialog.userCooldown')" type="number" variant="outlined" density="comfortable" hide-details /></v-col>
                    <v-col cols="12" sm="6"><v-text-field v-model.number="form.globalCooldown" :label="$t('dialogs.commandCreateDialog.globalCooldown')" type="number" variant="outlined" density="comfortable" hide-details /></v-col>
                  </v-row>
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.commandCreateDialog.behavior') }}</div>
                  <v-row density="comfortable">
                    <v-col cols="12" sm="6"><v-switch v-model="form.enabled" :label="$t('dialogs.commandCreateDialog.enabled')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.bypass_interaction_queue" :label="$t('dialogs.commandCreateDialog.bypassInteractionQueue')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.strip_emotes" :label="$t('dialogs.commandCreateDialog.stripEmotes')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.strip_urls" :label="$t('dialogs.commandCreateDialog.stripUrls')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12"><v-select v-model="form.single_use" :items="singleUseOptions" :label="$t('dialogs.commandCreateDialog.singleUse')" variant="outlined" density="comfortable" hide-details /></v-col>
                  </v-row>
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.commandCreateDialog.permissions') }}</div>
                  <v-row density="comfortable">
                    <v-col cols="12" sm="6"><v-switch v-model="form.enforce_primary" :label="$t('dialogs.commandCreateDialog.primaryOnly')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12" sm="6"><v-switch v-model="form.requiresBroadcaster" :label="$t('dialogs.commandCreateDialog.broadcaster')" color="primary" hide-details density="comfortable" inset /></v-col>
                    <v-col cols="12"><v-divider class="my-2" /></v-col>
                    <v-col cols="12"><TwitchAccessRequirements v-model="form" /></v-col>
                  </v-row>
                </v-card>

                <v-card variant="tonal" class="option-card pa-4">
                  <div class="text-subtitle-2 mb-3">{{ $t('dialogs.commandCreateDialog.userListMode') }}</div>
                  <v-select v-model="form.user_list_mode" :items="userListModeOptions" :label="$t('dialogs.commandCreateDialog.userListMode')" variant="outlined" density="comfortable" hide-details class="mb-3" />
                  <v-combobox v-if="form.user_list_mode !== 'none'" v-model="form.users" :label="$t('dialogs.commandCreateDialog.users')" variant="outlined" density="comfortable" multiple chips closable-chips hide-details />
                </v-card>
              </div>

              <v-card color="grey-darken-4" variant="flat" class="dialog-section pa-3 mb-3">
                <div class="d-flex align-center justify-space-between mb-2">
                  <div class="text-subtitle-2">{{ $t('dialogs.commandCreateDialog.params') }}</div>
                  <v-btn size="small" prepend-icon="mdi-plus" variant="tonal" @click="addParam">{{ $t('dialogs.commandCreateDialog.addParam') }}</v-btn>
                </div>

                <v-alert v-if="safeParams.length === 0" type="info" density="comfortable" variant="tonal" :text="$t('dialogs.commandCreateDialog.noParamsConfigured')" />

                <v-row v-for="(param, index) in safeParams" :key="index" density="comfortable" class="align-center mb-1">
                  <v-col cols="12" md="3">
                    <v-text-field v-model="param.name" :label="$t('dialogs.commandCreateDialog.name')" variant="outlined" density="comfortable" hide-details />
                  </v-col>

                  <v-col cols="12" md="3">
                    <v-select v-model="param.type" :items="paramTypes" :label="$t('dialogs.commandCreateDialog.type')" variant="outlined" density="comfortable" hide-details />
                  </v-col>

                  <v-col cols="12" md="4">
                    <v-combobox
                      v-if="param.type === 'subcommand'"
                      v-model="param.subcommandNames"
                      :label="$t('dialogs.commandCreateDialog.subcommands')"
                      variant="outlined"
                      density="comfortable"
                      multiple
                      chips
                      closable-chips
                      hide-details
                    />
                    <v-switch v-else v-model="param.required" :label="$t('dialogs.commandCreateDialog.required')" color="primary" density="comfortable" hide-details />
                  </v-col>

                  <v-col cols="12" md="2" class="text-right">
                    <v-btn icon="mdi-delete" color="error" variant="text" @click="removeParam(index)" />
                  </v-col>
                </v-row>
              </v-card>
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel value="asset">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-palette" />
                <span class="text-truncate">
                  {{ $t('dialogs.commandCreateDialog.asset') }}
                </span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <v-progress-linear v-if="assetLoading" indeterminate class="mb-3" />
              <CommandAssetAccordion
                v-show="!assetLoading"
                ref="assetAccordion"
                :name="generatedAssetName"
                :auto-load="false"
                :disabled="loading"
              />
            </v-expansion-panel-text>
          </v-expansion-panel>

          <v-expansion-panel value="macro">
            <v-expansion-panel-title>
              <div class="d-flex align-center ga-2 min-width-0">
                <v-icon icon="mdi-code-braces" />
                <span class="text-truncate">
                  {{ $t('dialogs.commandCreateDialog.macro') }}
                </span>
              </div>
            </v-expansion-panel-title>

            <v-expansion-panel-text eager>
              <v-progress-linear v-if="macroLoading" indeterminate class="mb-3" />
              <CommandMacroAccordion
                v-show="!macroLoading"
                ref="macroAccordion"
                :name="generatedMacroName"
                :source-name="normalizedName"
                :initial-content="macroContent"
                :command-params="safeParams"
                disable-macro-read
              />
            </v-expansion-panel-text>
          </v-expansion-panel>
        </v-expansion-panels>

      </v-card-text>

      <v-card-actions>
        <v-spacer />
        <v-btn
          variant="text"
          prepend-icon="mdi-close"
          :disabled="loading || savingInternal"
          @click="$emit('update:modelValue', false)"
        >
          {{ $t('common.cancel') }}
        </v-btn>
        <v-btn
          color="primary"
          variant="tonal"
          prepend-icon="mdi-content-save"
          :loading="loading || savingInternal"
          :disabled="!canSave"
          @click="save"
        >
          {{ $t('common.save') }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script lang="ts">
import TwitchAccessRequirements from '@/components/inputs/TwitchAccessRequirements.vue'
import CommandAssetAccordion from '@/components/accordions/CommandAssetAccordion.vue'
import CommandMacroAccordion from '@/components/accordions/CommandMacroAccordion.vue'
import YamlImportExportButtons from '@/components/YamlImportExportButtons.vue'
import { getWebsocketClient } from '@/plugins/websocketInstance'
import { useAppStore } from '@/stores/app'
import { checkNameExistsResult } from '@/helper/NameExistsHelper'

export default {
  name: 'CommandDialog',

  components: {
    TwitchAccessRequirements, CommandAssetAccordion, CommandMacroAccordion, YamlImportExportButtons },

  props: {
    modelValue: { type: Boolean, default: false },
    commandEntry: { type: Object, default: null },
    loading: { type: Boolean, default: false },
    disabled: { type: Boolean, default: false },
  },

  emits: ['update:modelValue', 'save'],

  data() {
    return {
      appStore: useAppStore(),
      openPanels: 'options',
      assetLoading: false,
      macroLoading: false,
      errorMessage: '',
      paramTypes: ['string', 'number', 'user', 'subcommand', 'all'],
      macroContent: '',
      savingInternal: false,
      nameChecking: false,
      nameExists: false,
      nameExistsCommand: null as string | null,
      aliasChecking: false,
      aliasExistsNames: [] as string[],
      aliasExistsCommands: {} as Record<string, string | null>,
      originalName: '',
      originalAliases: [] as string[],
      nameCheckTimer: null as ReturnType<typeof setTimeout> | null,
      nameCheckToken: 0,
      form: this.defaultForm(),
    }
  },

  computed: {
    isEditing(): boolean {
      return !!this.commandEntry
    },

    title(): string {
      const name = this.commandEntry?.name ?? this.commandEntry?.command?.name
      return this.isEditing
        ? this.$t('dialogs.commandDialog.editTitle', { name: name ? `!${name}` : '' })
        : this.$t('dialogs.commandDialog.createTitle')
    },

    singleUseOptions() {
      return [
        { title: this.$t('dialogs.commandCreateDialog.singleUseNone'), value: 'none' },
        { title: this.$t('dialogs.commandCreateDialog.singleUseUser'), value: 'user' },
        { title: this.$t('dialogs.commandCreateDialog.singleUseGlobal'), value: 'global' },
      ]
    },

    userListModeOptions() {
      return [
        { title: this.$t('dialogs.commandCreateDialog.userListNone'), value: 'none' },
        { title: this.$t('dialogs.commandCreateDialog.userBlacklist'), value: 'blacklist' },
        { title: this.$t('dialogs.commandCreateDialog.userWhitelist'), value: 'whitelist' },
      ]
    },

    safeParams(): any[] {
      if (!Array.isArray((this.form as any).params)) {
        ;(this.form as any).params = []
      }

      return (this.form as any).params
    },

    normalizedName(): string {
      return this.normalizeName((this.form as any).name)
    },

    normalizedAliases(): string[] {
      return Array.from(new Set(
        this.toArray((this.form as any).aliases)
          .map((alias: any) => String(alias ?? '').trim().replace(/^!+/, ''))
          .filter(Boolean),
      ))
    },

    generatedAssetName(): string {
      return this.normalizedName ? `command_${this.normalizedName}` : 'command_'
    },

    generatedMacroName(): string {
      return this.normalizedName ? `command_${this.normalizedName}` : 'command_'
    },

    exportFilename(): string {
      return this.normalizedName ? `command_${this.normalizedName}.yaml` : 'command.yaml'
    },

    exportPayload(): any {
      return this.buildExportPayload()
    },

    originalNormalizedName(): string {
      return this.normalizeName(this.originalName)
    },

    nameChanged(): boolean {
      return this.isEditing && this.normalizedName !== this.originalNormalizedName
    },

    aliasesToValidate(): string[] {
      if (!this.isEditing) return this.normalizedAliases
      const original = new Set(this.originalAliases)
      return this.normalizedAliases.filter(alias => !original.has(alias))
    },

    canSave(): boolean {
      const nameAvailable = !this.nameChecking && !this.nameExists
      return this.normalizedName.length > 0 && !this.loading
        && !this.savingInternal
        && !this.assetLoading
        && !this.macroLoading
        && nameAvailable
        && !this.aliasChecking
        && this.aliasExistsNames.length === 0
    },
  },

  watch: {
    normalizedName() {
      this.scheduleNameCheck()
    },
    normalizedAliases: {
      deep: true,
      handler() {
        this.scheduleNameCheck()
      },
    },
    isEditing(value: boolean) {
      if (value) {
        this.nameChecking = false
        this.aliasChecking = false
        this.nameExists = false
        this.nameExistsCommand = null
        this.aliasExistsNames = []
        this.aliasExistsCommands = {}
      } else {
        this.scheduleNameCheck()
      }
    },
  },

  methods: {
    scheduleNameCheck() {
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)

      const name = (!this.isEditing || this.nameChanged) ? this.normalizedName : ''
      const commandName = this.normalizedName
      const aliases = [...this.aliasesToValidate]
      const token = ++this.nameCheckToken

      this.nameExists = false
      this.nameExistsCommand = null
      this.aliasExistsNames = []
      this.aliasExistsCommands = {}

      if (!name && aliases.length === 0) {
        this.nameChecking = false
        this.aliasChecking = false
        return
      }

      this.nameChecking = Boolean(name)
      this.aliasChecking = aliases.length > 0

      this.nameCheckTimer = setTimeout(async () => {
        try {
          const [nameResult, aliasChecks] = await Promise.all([
            name ? checkNameExistsResult('commands_exists', name) : Promise.resolve({ exists: false, name }),
            Promise.all(aliases.map(async (alias) => {
              if (alias === commandName) {
                return { alias, exists: true, command_name: commandName }
              }
              const result = await checkNameExistsResult('commands_exists', alias)
              return { alias, exists: result.exists, command_name: result.command_name ?? null }
            })),
          ])

          if (token !== this.nameCheckToken) return
          if (name && name !== this.normalizedName) return
          if (JSON.stringify(aliases) !== JSON.stringify(this.aliasesToValidate)) return

          this.nameExists = nameResult.exists
          this.nameExistsCommand = nameResult.command_name ?? null
          this.aliasExistsNames = aliasChecks.filter(item => item.exists).map(item => item.alias)
          this.aliasExistsCommands = Object.fromEntries(
            aliasChecks.filter(item => item.exists).map(item => [item.alias, item.command_name ?? null]),
          )
        } catch {
          if (token === this.nameCheckToken) {
            this.nameExists = false
            this.nameExistsCommand = null
            this.aliasExistsNames = []
            this.aliasExistsCommands = {}
          }
        } finally {
          if (token === this.nameCheckToken) {
            this.nameChecking = false
            this.aliasChecking = false
          }
        }
      }, 300)
    },

    async ensureNameAvailable() {
      if (this.nameCheckTimer) clearTimeout(this.nameCheckTimer)

      const name = (!this.isEditing || this.nameChanged) ? this.normalizedName : ''
      const commandName = this.normalizedName
      const aliases = [...this.aliasesToValidate]
      this.nameChecking = Boolean(name)
      this.aliasChecking = aliases.length > 0

      try {
        const [nameResult, aliasChecks] = await Promise.all([
          name ? checkNameExistsResult('commands_exists', name) : Promise.resolve({ exists: false, name }),
          Promise.all(aliases.map(async (alias) => {
            if (alias === commandName) {
              return { alias, exists: true, command_name: commandName }
            }
            const result = await checkNameExistsResult('commands_exists', alias)
            return { alias, exists: result.exists, command_name: result.command_name ?? null }
          })),
        ])

        this.nameExists = nameResult.exists
        this.nameExistsCommand = nameResult.command_name ?? null
        this.aliasExistsNames = aliasChecks.filter(item => item.exists).map(item => item.alias)
        this.aliasExistsCommands = Object.fromEntries(
          aliasChecks.filter(item => item.exists).map(item => [item.alias, item.command_name ?? null]),
        )
        return !this.nameExists && this.aliasExistsNames.length === 0
      } finally {
        this.nameChecking = false
        this.aliasChecking = false
      }
    },

    async open() {
      this.errorMessage = ''
      this.nameExists = false
      this.nameExistsCommand = null
      this.aliasExistsNames = []
      this.aliasExistsCommands = {}
      this.originalName = ''
      this.originalAliases = []
      this.nameChecking = false
      this.aliasChecking = false
      this.form = this.defaultForm()
      this.macroContent = ''
      this.assetLoading = false
      this.macroLoading = false

      if (!this.isEditing) {
        // The dialog stays mounted between edit/create operations. Do not read the
        // macro accordion here: it may still contain the previously edited command.
        // Start every new command with a genuinely empty macro instead.
        this.macroContent = this.defaultMacroContent(this.generatedMacroName)

        await this.$nextTick()
        ;(this.$refs.macroAccordion as any)?.setContent?.(
          this.macroContent,
          this.generatedMacroName,
        )
        ;(this.$refs.assetAccordion as any)?.setAsset?.({ channel: 'general', duration: 5 })
        return
      }

      const command = this.commandEntry?.command ?? {}
      const name = this.commandEntry?.name ?? command.name ?? ''
      this.originalName = String(name ?? '')
      const generatedName = `command_${String(name).replace(/^command_/, '')}`
      const assetName = command.asset || generatedName
      const macroName = command.macro || generatedName

      this.form = {
        name,
        aliases: this.toArray(command.aliases ?? command.alias),
        params: this.expandImportedParams(command.params),
        enabled: command.enabled !== false,
        bypass_interaction_queue: command.bypass_interaction_queue === true,
        strip_emotes: command.strip_emotes === true,
        strip_urls: command.strip_urls === true,
        single_use: ['user', 'global'].includes(command.single_use ?? command.singleUse) ? (command.single_use ?? command.singleUse) : 'none',
        user_list_mode: ['blacklist', 'whitelist'].includes(command.user_list_mode ?? command.userListMode) ? (command.user_list_mode ?? command.userListMode) : 'none',
        users: this.toArray(command.users ?? command.user_list ?? command.userList).map((user: any) => String(user ?? '').replace(/^@+/, '').trim()).filter(Boolean),
        userCooldown: command.userCooldown,
        globalCooldown: command.globalCooldown,
        enforce_primary: command.enforce_primary === true || command.enforceSame === true,
        requiresBroadcaster: command.requiresBroadcaster === true,
        require_follower: command.require_follower === true || command.requiresFollower === true,
        minimum_follow_seconds: Number(command.minimum_follow_seconds ?? command.minimumFollowSeconds ?? 0) || 0,
        require_subscriber: command.require_subscriber === true || command.requiresSubscriber === true,
        minimum_sub_tier: Number(command.minimum_sub_tier ?? command.minimumSubTier ?? 0) || 0,
        minimum_sub_months: Number(command.minimum_sub_months ?? command.minimumSubMonths ?? 0) || 0,
        require_vip: command.require_vip === true || command.requiresVip === true,
        require_moderator: command.require_moderator === true || command.requiresModerator === true || command.requiresMod === true,
      }
      this.originalAliases = [...this.normalizedAliases]

      this.macroContent = this.defaultMacroContent(macroName)
      await this.$nextTick()
      ;(this.$refs.macroAccordion as any)?.setContent?.(this.macroContent, macroName)

      this.assetLoading = true
      this.macroLoading = true

      void this.loadAsset(assetName).finally(() => {
        this.assetLoading = false
      })

      void this.loadMacro(macroName)
        .then((content: string) => {
          this.macroContent = content
          ;(this.$refs.macroAccordion as any)?.setContent?.(content, macroName)
        })
        .finally(() => {
          this.macroLoading = false
        })
    },

    async requestWebsocket(method: string, params: Record<string, any> = {}, timeout = 4_000): Promise<any> {
      const client = getWebsocketClient()
      if (!client) throw new Error('websocket is not connected')
      const response = await client.request(method, params, timeout)
      return response?.params ?? response
    },

    unwrap(response: any, method: string) {
      const key = `result_${method}`
      const candidates = [response, response?.data, response?.payload, response?.result, response?.data?.result].filter(Boolean)
      for (const candidate of candidates) {
        if (candidate?.[key] !== undefined) return candidate[key]
      }
      return response?.data ?? response
    },

    async loadMacro(name: string) {
      const payload = { name, path: `${name}.yaml`, file: `${name}.yaml` }
      try {
        const response = await this.requestWebsocket('macro_read', payload)
        const data = this.unwrap(response, 'macro_read')
        if (data?.content) return String(data.content)
      } catch (_) {}

      try {
        const response = await fetch(`${this.appStore.getRestApi}/api/macro/read`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
        const data = await response.json().catch(() => ({}))
        const content = data?.content ?? data?.data?.content
        if (content) return String(content)
      } catch (_) {}

      return this.defaultMacroContent(name)
    },

    defaultForm() {
      return {
        name: '',
        aliases: [] as string[],
        params: [] as any[],
        enabled: true,
        bypass_interaction_queue: false,
        strip_emotes: false,
        strip_urls: false,
        single_use: 'none',
        user_list_mode: 'none',
        users: [] as string[],
        userCooldown: undefined as any,
        globalCooldown: undefined as any,
        enforce_primary: false,
        requiresBroadcaster: false,
        require_follower: false,
        minimum_follow_seconds: 0,
        require_subscriber: false,
        minimum_sub_tier: 0,
        minimum_sub_months: 0,
        require_vip: false,
        require_moderator: false,
      }
    },

    toArray(value: any): any[] {
      if (Array.isArray(value)) return value
      if (value === null || value === undefined || value === '') return []
      if (typeof value === 'object') return Object.values(value)
      return [value]
    },

    setForm(value: any = {}) {
      this.form = {
        ...this.defaultForm(),
        ...value,
        aliases: this.toArray(value.aliases),
        params: this.toArray(value.params),
        users: this.toArray(value.users ?? value.user_list ?? value.userList)
          .map((user: any) => String(user ?? '').replace(/^@+/, '').trim())
          .filter(Boolean),
        enabled: value.enabled !== false,
        bypass_interaction_queue: value.bypass_interaction_queue === true,
        strip_emotes: value.strip_emotes === true,
        strip_urls: value.strip_urls === true,
        single_use: ['user', 'global'].includes(value.single_use ?? value.singleUse)
          ? (value.single_use ?? value.singleUse)
          : 'none',
        user_list_mode: ['blacklist', 'whitelist'].includes(value.user_list_mode ?? value.userListMode)
          ? (value.user_list_mode ?? value.userListMode)
          : 'none',
      }
    },

    setMacroContent(content: string, name?: string) {
      this.macroContent = content || this.defaultMacroContent(name || this.generatedMacroName)
      this.$nextTick(() => {
        ;(this.$refs.macroAccordion as any)?.setContent?.(this.macroContent, name || this.generatedMacroName)
      })
    },

    normalizeName(value: any) {
      return String(value ?? '')
        .trim()
        .replace(/^!+/, '')
        .replace(/^command_/, '')
        .replace(/\s+/g, '_')
        .replace(/[^\p{L}\p{N}_.-]+/gu, '_')
        .replace(/^_+|_+$/g, '')
    },

    defaultMacroContent(name: string) {
      return `name: ${name}\ntasks: []\n`
    },

    syncMacro() {
      const currentContent =
        (this.$refs.macroAccordion as any)?.getContent?.() ||
        this.macroContent ||
        this.defaultMacroContent(this.generatedMacroName)

      this.setMacroContent(
        this.withMacroName(currentContent, this.generatedMacroName),
        this.generatedMacroName,
      )
    },

    withMacroName(content: string, name: string) {
      const value = String(content ?? '')
      const nameLine = `name: ${name}`

      if (/^name\s*:/m.test(value)) {
        return value.replace(/^name\s*:.*$/m, nameLine)
      }

      return `${nameLine}\n${value}`
    },

    addParam() {
      if (!Array.isArray((this.form as any).params)) {
        ;(this.form as any).params = []
      }

      ;(this.form as any).params.push({
        name: '',
        type: 'string',
        required: true,
        subcommandNames: [],
      })
    },

    removeParam(index: number) {
      if (!Array.isArray((this.form as any).params)) return
        ;(this.form as any).params.splice(index, 1)
    },

    normalizeParams() {
      return this.toArray((this.form as any).params)
        .map((param: any) => {
          if (!param || typeof param !== 'object') {
            return null
          }

          return {
            name: param.name,
            type: param.type || 'string',
            required: param.required !== false,
            subcommands:
              param.type === 'subcommand'
                ? this.toArray(param.subcommandNames)
                  .filter(Boolean)
                  .map((name: string) => ({ name }))
                : undefined,
          }
        })
        .filter((param: any) => param?.name)
    },

    async loadAsset(name: string) {
      await this.$nextTick()

      try {
        await (this.$refs.assetAccordion as any)?.open?.(name)
      } catch (_) {
        ;(this.$refs.assetAccordion as any)?.setAsset?.({
          channel: 'general',
          duration: 5,
        })
      }
    },

    getAssetPayload() {
      return (this.$refs.assetAccordion as any)?.getAssetPayload?.() ?? {}
    },

    getMacroContent() {
      const content =
        (this.$refs.macroAccordion as any)?.getContent?.() ||
        this.macroContent ||
        this.defaultMacroContent(this.generatedMacroName)

      return this.withMacroName(content, this.generatedMacroName)
    },

    buildCommandPayload() {
      return {
        ...this.form,
        name: this.normalizedName,
        aliases: this.normalizedAliases,
        params: this.normalizeParams(),
        asset: this.generatedAssetName,
        macro: this.generatedMacroName,
      }
    },

    buildExportPayload() {
      const command = this.buildCommandPayload()
      const path = this.isEditing && this.commandEntry?.file
        ? this.commandEntry.file
        : (command.name ? `command_${command.name}.yaml` : 'command.yaml')
      const assetPayload = this.getAssetPayload()
      const macroContent = this.getMacroContent()

      return {
        streambot_export: {
          version: 1,
          kind: 'command',
        },
        config: {
          name: command.name,
          path,
          content: command,
        },
        asset: {
          name: this.generatedAssetName,
          content: assetPayload,
        },
        macro: {
          name: this.generatedMacroName,
          content: macroContent,
        },

        // Legacy aliases for older admin imports.
        name: command.name,
        path,
        command,
        assetPayload,
        macroContent,
      }
    },

    importCommand(payload: any) {
      try {
        const data = payload?.data ?? payload ?? {}
        const command =
          data?.config?.content && typeof data.config.content === 'object'
            ? data.config.content
            : (data.command && typeof data.command === 'object' ? data.command : data)
        const currentName = String(this.form.name ?? '').trim()
        const importedName = data?.config?.name ?? data.name ?? command.name ?? ''
        const normalizedTargetName = this.normalizeName(currentName)
        const macroName = normalizedTargetName ? `command_${normalizedTargetName}` : (data?.macro?.name || command.macro || '')

        this.setForm({
          name: currentName,
          aliases: command.aliases ?? command.alias,
          params: this.expandImportedParams(command.params),
          userCooldown: command.userCooldown,
          globalCooldown: command.globalCooldown,
          bypass_interaction_queue: command.bypass_interaction_queue === true,
          strip_emotes: command.strip_emotes === true,
          strip_urls: command.strip_urls === true,
          enforce_primary: command.enforce_primary === true || command.enforceSame === true,
          requiresBroadcaster: command.requiresBroadcaster === true,
          require_follower: command.require_follower === true || command.requiresFollower === true,
          minimum_follow_seconds: Number(command.minimum_follow_seconds ?? command.minimumFollowSeconds ?? 0) || 0,
          require_subscriber: command.require_subscriber === true || command.requiresSubscriber === true,
          minimum_sub_tier: Number(command.minimum_sub_tier ?? command.minimumSubTier ?? 0) || 0,
          minimum_sub_months: Number(command.minimum_sub_months ?? command.minimumSubMonths ?? 0) || 0,
          require_vip: command.require_vip === true || command.requiresVip === true,
          require_moderator: command.require_moderator === true || command.requiresModerator === true || command.requiresMod === true,
        })

        this.setMacroContent(
          String(data?.macro?.content ?? data.macroContent ?? this.defaultMacroContent(macroName)),
          macroName,
        )

        this.$nextTick(async () => {
          const importedAssetPayload = data?.asset?.content ?? data.assetPayload

          if (importedAssetPayload && typeof importedAssetPayload === 'object') {
            ;(this.$refs.assetAccordion as any)?.setAsset?.(importedAssetPayload)
          } else {
            await this.loadAsset(this.generatedAssetName)
          }
        })

        this.errorMessage = ''
      } catch (error: any) {
        this.handleImportError(error)
      }
    },

    expandImportedParams(params: any) {
      return this.toArray(params).map((param: any) => {
        if (!param || typeof param !== 'object') {
          return {
            name: String(param ?? ''),
            type: 'string',
            required: true,
            subcommandNames: [],
          }
        }

        return {
          ...param,
          subcommandNames: this.toArray(param.subcommands ?? param.subcommandNames)
            .map((sub: any) => (typeof sub === 'string' ? sub : sub?.name ?? ''))
            .filter(Boolean),
        }
      })
    },

    handleImportError(error: any) {
      this.errorMessage = error?.message
    },

    async save() {
      if (!this.canSave) return
      if (!(await this.ensureNameAvailable())) return

      this.errorMessage = ''
      this.savingInternal = true

      try {
        const payload = this.buildExportPayload()

        // Assets are stored independently from command config files.
        // Save the current asset first so an asset-only command can trigger
        // immediately after the command itself is reloaded.
        await (this.$refs.assetAccordion as any)?.save?.(this.generatedAssetName)

        this.$emit('save', {
          ...payload.command,
          path: payload.path,
          assetPayload: payload.assetPayload,
          macroContent: payload.macroContent,
        })
      } catch (error: any) {
        this.errorMessage = error?.message ?? 'failed to save command asset'
      } finally {
        // The parent switches its `loading` prop on synchronously when the
        // save event is emitted. This internal state covers the work that
        // happens before that event (notably saving the asset accordion), so
        // the button starts spinning immediately on click.
        this.savingInternal = false
      }
    },
  },
}
</script>

<style scoped>
.min-width-0 {
  min-width: 0;
}

.dialog-section {
  width: 100%;
  max-width: none;
}

.option-card-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}

.option-card {
  min-width: 0;
  height: 100%;
}

@media (min-width: 960px) {
  .option-card-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (min-width: 1920px) {
  .option-card-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}
</style>
